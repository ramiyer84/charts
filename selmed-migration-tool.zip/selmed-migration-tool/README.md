# ECM Migration Tool

The purpose of this tool is to process ECM export archives. It extracts metadata from the archives
and stores it in the migration database.
The tool is a native Windows application that should be periodically executed by the OS.
It scans the 'input' directory and tries to process any .zip file it can find. Once the archive
is processed it is moved to 'processed' directory. If any error occurs, the file is moved to the 'error'
directory.

## Configuration

The tool requires a .yaml or .json configuration file with the following structure. The root elements
ar as follows:

| Name       | Type    | Default Value | Description                                                                               |
|------------|---------|---------------|-------------------------------------------------------------------------------------------|
| debug      | Boolean | false         | Enables debug logging                                                                     |
| anonymize  | Boolean | false         | If set to `true` tool will replace the personal data in the extracts with the fake values |
| location   | Map     |               | Describes the locations of the input, processed and error files                           |
| encryption | Map     |               | Defines the encryption key and ZIP file password                                          |
| database   | Map     |               | Defines the database connection properties                                                |
| import     | Map     |               | Defines the rules related to which records should be imported                             |

### The `location` map
All paths could be either relative to the location of the tool, or absolute, e.g. c:\Apps\ECM\input

| Name      | Type   | Default Value | Description                                                                                                                                                                                                                     |
|-----------|--------|---------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| input     | String | input         | The name of the `input` directory                                                                                                                                                                                               |
| processed | String | processed     | The name of the `processed` directory                                                                                                                                                                                           |
| error     | String | error         | The name of the `error` directory                                                                                                                                                                                               |
| logs      | String | N/A           | The name of the `logs` directory. If omitted, logs will be written to the stdout. Otherwise, a new log file will be created for each run of the tool with the name using the following pattern ecm-migration-yyyymmddhhmiss.log |


### The `encryption` map
Name | Type | Default Value | Description
---|---|---|---
key | String | N/A | The base64 encoded AES256 secret key, used to encrypt personal data

### The `database` map
Name | Type | Default Value | Description
---|---|---|---
host | String | localhost | The database host
port | Integer | 5432 | The database port
name | String | N/A | The database name
username | String | N/A | The database username
password | String | N/A | The database password
ssl | Map | | The SSL settings

The SSL map keys are as follows
Name | Type | Default Value | Description
---|---|---|---
enabled | Boolean | false | Flag specifying if the database connection should use SSL
ca | String | N/A | The path to the CA certificate
key | String | N/A | THe path to the SSL key file
cert | String | N/A | The path to the SSL certificate file

### The `import` map
Name | Type | Default Value | Description
---|---|---|---
range | Map | N/A | Defines the start and end of the range of application creation dates which should be imported. Applications created outside of this range of dates will be ignored. 

The `range` map keys are as follows
Name | Type | Default Value | Description
---|---|---|---
start | Date (DD/MM/YYYY) | N/A | The start date for the range of application creation dates
end | Date  (DD/MM/YYYY) | N/A | The end date for the range of application creation dates

## Selmed Import Files

Selmed extract package contains 7 files. Each file is a plain text flat file with the fixed length records. 

Table Name | Record Length
---|---
F01 | 1143
F02 | 470
F05 | 250
F06 | 308
F10 | 290
F12 | 164
F13 | 257
F19 | 199
F21 | 220

## Starting the test database
In order to be able to start the test database run the following command:

```
docker run -d --name test-migration -p 5432:5432 clpregistrystaging.al.intraxa/dms-migration-db:1.0.0.129
```

Adjust local port if necessary, for example if you already have running Postgres instance listening on port 5432.