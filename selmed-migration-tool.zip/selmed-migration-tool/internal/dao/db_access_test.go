package dao

import (
	"context"
	"database/sql"
	"encoding/base64"
	"fmt"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/testutil"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/stretchr/testify/assert"
	"log"
	"os"
	"testing"
	"time"
)

var (
	cb        *db.ConnectionBuilder
	l         *logger.Logger
	secretKey []byte
)

func TestMain(m *testing.M) {
	l = logger.Create("db_access_test")

	dat, err := os.ReadFile("../../secret.key")
	if err != nil {
		log.Fatalf("cannot read AES key from file system: %v", err)
	}

	secretKey, err = base64.StdEncoding.DecodeString(string(dat))
	if err != nil {
		log.Fatalf("cannot read AES key: %v", err)
	}

	ctx := context.Background()
	pg, net, host, port := testutil.Init()
	defer func() {
		if err := net.Remove(ctx); err != nil {
			log.Fatalf("failed to remove network: %s", err)
		}
	}()

	defer pg.Terminate(ctx)

	cb = db.NewConnectionBuilder("pgx", host, port, "migrationdb").
		Username("migowner").
		Password("Password1")

	os.Exit(m.Run())
}

func TestCreateSession(t *testing.T) {
	session, err := cb.Build()
	assert.Nil(t, err)
	assert.NotNil(t, session)

	//if pgUseSSL {
	//	sslCACertPath := viper.GetString("database.ssl.caCertificatePath")
	//	sslPrivateKeyPath := viper.GetString("database.ssl.privateKeyPath")
	//	sslCertPath := viper.GetString("database.ssl.certificatePath")
	//	if sslCACertPath == "" || sslPrivateKeyPath == "" || sslCertPath == "" {
	//		logger.Fatalf("paths to SSL key, certificate and CA certificate are required when SSL is enabled")
	//	}
	//	databaseClient.AppendPropertyToDialInfo("sslmode", "require")
	//	databaseClient.AppendPropertyToDialInfo("sslrootcert", sslCACertPath)
	//	databaseClient.AppendPropertyToDialInfo("sslkey", sslPrivateKeyPath)
	//	databaseClient.AppendPropertyToDialInfo("sslcert", sslCertPath)
	//} else {
	//	databaseClient.AppendPropertyToDialInfo("sslmode", "disable")
	//}
}

func TestAddBatch(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if err != nil {
		fmt.Printf("cannot create DB Client: %v", err)
		t.Fail()
	}

	database := CreateClient(dbClient, l)
	session := database.GetConnection()
	//tx, err := session.BeginTx(ctx, txOptions)
	//assert.Nil(t, err)
	//assert.NotNil(t, tx)
	//
	//defer tx.Rollback()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)
	err = database.AddBatchIfNecessary(ctx, "202106301150", fileCreateTime)
	assert.Nil(t, err)
	//
	//err = tx.Commit()
	//assert.Nil(t, err)

	var (
		batchId       string
		status        string
		message       sql.NullString
		createdAt     time.Time
		lastUpdatedAt sql.NullTime
	)
	row := session.QueryRowContext(ctx, "SELECT BATCH_ID, STATUS, MESSAGE, CREATED_AT, LAST_UPDATED_AT FROM SELMED_BATCHES WHERE BATCH_ID = $1", "202106301150")
	err = row.Scan(&batchId, &status, &message, &createdAt, &lastUpdatedAt)
	if err != nil {
		assert.Fail(t, "cannot read SELMED batch record")
		return
	}

	assert.Equal(t, "202106301150", batchId)
	assert.Equal(t, "LOADING", status)
	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
	assert.False(t, message.Valid)
	assert.False(t, lastUpdatedAt.Valid)
}

func TestAddFile(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if !assert.Nil(t, err) {
		return
	}

	database := CreateClient(dbClient, l)
	session := database.GetConnection()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)
	err = database.AddBatchIfNecessary(ctx, "202106301149", fileCreateTime)
	assert.Nil(t, err)

	tx, err := database.BeginTransaction(ctx)
	assert.Nil(t, err)
	assert.NotNil(t, tx)

	defer tx.Rollback()
	fileId, err := database.AddFile(ctx, tx, "202106301149", "TEST_01", "FC01", fileCreateTime)
	assert.Nil(t, err)
	assert.Less(t, uint(0), fileId)

	err = tx.Commit()
	if !assert.Nil(t, err) {
		return
	}

	var (
		id              int
		name            string
		selmedTableName string
		status          string
		createdAt       time.Time
		lastUpdatedAt   sql.NullTime
	)
	row := session.QueryRowContext(ctx, "SELECT ID, NAME, SELMED_TABLE_NAME, STATUS, CREATED_AT, LAST_UPDATED_AT FROM SELMED_FILES WHERE ID = $1", fileId)
	err = row.Scan(&id, &name, &selmedTableName, &status, &createdAt, &lastUpdatedAt)
	if err != nil {
		assert.Fail(t, "cannot read SELMED file record")
	}

	assert.Equal(t, fileId, uint(id))
	assert.Equal(t, "TEST_01", name)
	assert.Equal(t, "FC01", selmedTableName)
	assert.Equal(t, "LOADING", status)
	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
	assert.False(t, lastUpdatedAt.Valid)
}

func TestLoadApplications(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if !assert.Nil(t, err) {
		return
	}
	database := CreateClient(dbClient, l)
	tx, err := database.BeginTransaction(ctx)
	if !assert.Nil(t, err) {
		return
	}

	apps, insured, agents, err := database.LoadApplications(ctx, tx, "2106110912")
	if !assert.Nil(t, err) {
		return
	}
	assert.NotNil(t, apps)
	assert.NotNil(t, insured)
	assert.NotNil(t, agents)
	assert.Equal(t, 3, len(apps))
	assert.True(t, apps["2020A045800"])
	assert.True(t, apps["2020A036085"])
	assert.True(t, apps["2020A051077"])
	assert.False(t, apps["2020A051078"])
	assert.Equal(t, 3, len(insured))
	assert.True(t, insured[int64(1152)])
	assert.True(t, insured[int64(11988)])
	assert.True(t, insured[int64(20542)])
	assert.False(t, insured[int64(13888)])
	assert.Equal(t, 2, len(agents))
	assert.True(t, agents[int64(0)])
	assert.True(t, agents[int64(86057)])
	assert.False(t, insured[int64(121566)])
}
