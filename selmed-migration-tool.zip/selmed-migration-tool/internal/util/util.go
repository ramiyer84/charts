package util

import (
	"database/sql"
	"encoding/csv"
	"errors"
	"fmt"
	"github.com/spf13/viper"
	"io"
	"strconv"
	"strings"
	"time"
)

const (
	DateTimeLayout          = "02/01/2006 15:04:05 MST"
	MacaoDateTimeLayout     = "2006-01-02-15.04.05.000000"
	DateLayout              = "02/01/2006"
	BatchCreationTimeLayout = "0601021504"
	AltDateLayout           = "2006-01-02"
	TimeZone                = "CEST"
	Delimiter               = ';'
)

func OptionalString(value string) *string {
	var result *string
	value = strings.TrimSpace(value)
	if value != "" {
		result = new(string)
		*result = value
	}

	return result
}

func OptionalTime(value string, zone *string) (*time.Time, error) {
	var result *time.Time
	value = strings.TrimSpace(value)
	if value != "" {
		result = new(time.Time)
		time, err := convertTime(value, zone)
		if err != nil {
			return nil, err
		}
		*result = time
	}

	return result, nil
}

func OptionalDate(value string) (*time.Time, error) {
	var result *time.Time
	value = strings.TrimSpace(value)
	if value != "" {
		result = new(time.Time)
		time, err := convertDate(value)
		if err != nil {
			return nil, err
		}
		*result = time
	}

	return result, nil
}

func convertTime(value string, zone *string) (time.Time, error) {
	value = strings.TrimSpace(value)
	if value == "" {
		return time.Time{}, errors.New("value is empty")
	}

	if zone != nil {
		value = value + " " + *zone
	} else {
		value = value + " " + TimeZone
	}

	result, err := time.Parse(DateTimeLayout, value)
	if err != nil {
		return time.Time{}, err
	}

	return result, nil
}

func convertDate(value string) (time.Time, error) {
	value = strings.TrimSpace(value)
	if value == "" {
		return time.Time{}, errors.New("value is empty")
	}

	result, err := time.Parse(DateLayout, value)
	if err != nil {
		return time.Time{}, err
	}

	return result, nil
}

// ReadCsv accepts a file and returns its content as a multi-dimensional type
// with lines and each column. Only parses to string type.
func ReadCsv(f io.ReadCloser) ([][]string, error) {

	// Read File into a Variable
	reader := csv.NewReader(f)
	reader.Comma = Delimiter
	reader.LazyQuotes = true
	//reader.FieldsPerRecord = -1

	lines, err := reader.ReadAll()
	if err != nil {
		return [][]string{}, err
	}

	return lines, nil
}

func ReadInt64(data string) (int64, error) {
	tmp := strings.TrimSpace(data)
	if tmp != "" {
		num, err := strconv.ParseInt(tmp, 10, 64)
		if err != nil {
			return 0, err
		}
		return num, nil
	}

	return 0, nil
}

func ReadNullInt64(data string) (sql.NullInt64, error) {
	var result sql.NullInt64
	tmp := strings.TrimSpace(data)
	if tmp != "" {
		num, err := strconv.ParseInt(tmp, 10, 64)
		if err != nil {
			return result, err
		}
		result.Valid = true
		result.Int64 = num
		return result, nil
	}

	return result, nil
}

func ReadNullFloat64(data string) (sql.NullFloat64, error) {
	var result sql.NullFloat64
	tmp := strings.TrimSpace(data)
	if tmp != "" {
		num, err := strconv.ParseFloat(tmp, 64)
		if err != nil {
			return result, err
		}
		result.Valid = true
		result.Float64 = num
		return result, nil
	}

	return result, nil
}

func ReadDB2NullDate(data string) (sql.NullTime, error) {
	var result sql.NullTime
	tmp := strings.TrimSpace(data)
	if tmp != "" {
		tm, err := time.Parse(AltDateLayout, tmp)
		if err != nil {
			return result, err
		}
		result.Valid = true
		result.Time = tm
		return result, nil
	}

	return result, nil
}

func ReadMacaoNullTimestamp(data string) (sql.NullTime, error) {
	var result sql.NullTime
	tmp := strings.TrimSpace(data)
	if tmp != "" && tmp != "0001-01-01-00.00.00.000001" {
		tm, err := time.Parse(MacaoDateTimeLayout, tmp)
		if err != nil {
			return result, err
		}
		result.Valid = true
		result.Time = tm
		return result, nil
	}

	return result, nil
}

func ReadNullString(data string) sql.NullString {
	var result sql.NullString
	tmp := strings.TrimSpace(data)
	if tmp != "" {
		if []byte(tmp)[0] == 0x00 {
			return result
		}
		//cr, _ := charset.NewReader(strings.NewReader(tmp), "ASCII")
		//br := bufio.NewReader(cr)
		//tmp, _ = br.ReadString('\n')
		result.Valid = true
		result.String = tmp
		return result
	}

	return result
}

func Substring(data []rune, begin int, end int) string {
	return string(data[begin:end])
}

func SubstringBeginning(data []rune, end int) string {
	return string(data[:end])
}

func SubstringEnd(data []rune, begin int) string {
	return string(data[begin:])
}

func ConvertBatchCreationDateTime(value string) (time.Time, error) {
	value = strings.TrimSpace(value)
	if value == "" {
		return time.Time{}, errors.New("value is empty")
	}

	result, err := time.Parse(BatchCreationTimeLayout, value)
	if err != nil {
		return time.Time{}, err
	}

	return result, nil
}

func ShouldImportInTheRange() (bool, *time.Time, *time.Time) {
	var (
		importDateRangeStart *time.Time
		importDateRangeEnd   *time.Time
		err                  error
		shouldimportInRange  bool = false
	)
	dateString := viper.GetString("import.range.start")
	if dateString != "" {
		importDateRangeStart, err = OptionalDate(dateString)
		if err != nil {
			panic(fmt.Sprintf("cannot read import range start date: %v", err))
		}
	}

	dateString = viper.GetString("import.range.end")
	if dateString != "" {
		importDateRangeEnd, err = OptionalDate(dateString)
		if err != nil {
			panic(fmt.Sprintf("cannot read import range start date: %v", err))
		}
		*importDateRangeEnd = importDateRangeEnd.AddDate(0, 0, 1)
		*importDateRangeEnd = importDateRangeEnd.Add(-1000000000)
	}

	if importDateRangeStart != nil && importDateRangeEnd != nil {
		shouldimportInRange = true
	}

	return shouldimportInRange, importDateRangeStart, importDateRangeEnd
}
