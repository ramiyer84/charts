package inputfile

import (
	"context"
	"database/sql"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"log"
	"os"
	"sync"
)

type Range struct {
	Loaded               bool
	applicationNumberMap map[string]bool
	insuredIdMap         map[int64]bool
	partnerIdMap         map[int64]bool
	mx                   sync.RWMutex
}

func (r *Range) Validate(ctx context.Context, database *dao.DB, tx *sql.Tx, batchId string) {
	if !r.Loaded && r.applicationNumberMap == nil && r.insuredIdMap == nil && r.partnerIdMap == nil {
		r.mx.Lock()
		defer r.mx.Unlock()
		var err error

		r.applicationNumberMap, r.insuredIdMap, r.partnerIdMap, err = database.LoadApplications(ctx, tx, batchId)
		if err != nil {
			log.Printf("cannot load imported application: %v", err.Error())
			os.Exit(1)
		}
		r.Loaded = true
	}
}

func (r *Range) ApplicationNumberExists(applicationNumber string) bool {
	r.mx.RLock()
	defer r.mx.RUnlock()
	shouldImportInRange, _, _ := util.ShouldImportInTheRange()
	if !shouldImportInRange {
		return true
	}

	if r.Loaded && r.applicationNumberMap != nil {
		if r, ok := r.applicationNumberMap[applicationNumber]; ok {
			if r {
				return true
			}
		}
	}

	return false
}

func (r *Range) InsuredIdExists(insuredId int64) bool {
	r.mx.RLock()
	defer r.mx.RUnlock()
	shouldImportInRange, _, _ := util.ShouldImportInTheRange()
	if !shouldImportInRange {
		return true
	}

	if r.Loaded && r.insuredIdMap != nil {
		if r, ok := r.insuredIdMap[insuredId]; ok {
			if r {
				return true
			}
		}
	}

	return false
}

func (r *Range) PartnerIdExists(partnerId int64) bool {
	r.mx.RLock()
	defer r.mx.RUnlock()
	shouldImportInRange, _, _ := util.ShouldImportInTheRange()
	if !shouldImportInRange {
		return true
	}

	if r.Loaded && r.partnerIdMap != nil {
		if r, ok := r.partnerIdMap[partnerId]; ok {
			if r {
				return true
			}
		}
	}

	return false
}
