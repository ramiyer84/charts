package fc01

import (
	"context"
	"database/sql"
	"fmt"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/mrt-shared/encryption"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/testutil"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/stretchr/testify/assert"
	"log"
	"os"
	"testing"
	"time"
)

var (
	cb        *db.ConnectionBuilder
	l         *logger.Logger
	secretKey string
)

func TestMain(m *testing.M) {
	l = logger.Create("db_access_test")

	dat, err := os.ReadFile("../../../secret.key")
	if err != nil {
		log.Fatalf("cannot read AES key from file system: %v", err)
	}

	secretKey = string(dat)

	ctx := context.Background()
	pg, net, host, port := testutil.Init()
	defer func() {
		if err := net.Remove(ctx); err != nil {
			log.Fatalf("failed to remove network: %s", err)
		}
	}()

	defer pg.Terminate(ctx)

	cb = db.NewConnectionBuilder("pgx", host, port, "migrationdb").
		Username("migowner").
		Password("Password1")

	os.Exit(m.Run())
}

func TestParseFC0100(t *testing.T) {
	line, err := parseFC01Content("2020A045800;002943361;000001152;99998;99999;99999;S847901     ;888888;0000441495;A.N.P DIRECT EMPRUNTEUR CI - MEI;A.N.P DIRECT EMPRUNTEUR CI - MEI;                                ;TECHNOPOLE DU MOULIN            ;10019 ROND POINT DU CANET CS    ;                                ;13590;MEYREUIL                  ;001;000000000;2872;8233;2020-10-19;REFUS NIV 1. DELEGUE NIV 2. TRS NIV 3                              SV, LE 14/10/2020 - REFUS 3E NIV 19/10/2020 EV                                                                                                                   ;               ;                                ;                                ;                                ;                                ;122 AVENUE FELIX FAURE          ;                                ;92000;NANTERRE                  ;001;                                ;                                ;                                ;                                ;                                ;     ;                          ;   ;RMED;2020-10-19-15.53.02.143941;2020-10-19-15.53.02.143941;     ;                                           ;00071")
	if err != nil {
		fmt.Printf("cannot parse F01 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "2020A045800", line.ApplicationNumber)
	assert.Equal(t, int64(2943361), line.TypeOfMethod)
	assert.Equal(t, int64(1152), line.InsuredID)
	assert.Equal(t, "99998", line.AgentBrokerNumber)
	assert.Equal(t, "99999", line.InspectorCode)
	assert.True(t, line.NotUsedCreditor.Valid)
	assert.Equal(t, "99999", line.NotUsedCreditor.String)
	assert.True(t, line.UserUpdateName.Valid)
	assert.Equal(t, "S847901", line.UserUpdateName.String)
	assert.True(t, line.UserCode.Valid)
	assert.Equal(t, "888888", line.UserCode.String)
	assert.True(t, line.PMID.Valid)
	assert.Equal(t, int64(441495), line.PMID.Int64)
	assert.True(t, line.AgentName.Valid)
	assert.Equal(t, "A.N.P DIRECT EMPRUNTEUR CI - MEI", line.AgentName.String)
	assert.True(t, line.BankName.Valid)
	assert.Equal(t, "A.N.P DIRECT EMPRUNTEUR CI - MEI", line.BankName.String)
	assert.False(t, line.AgentAddress2.Valid)
	assert.True(t, line.AgentAddress3.Valid)
	assert.Equal(t, "TECHNOPOLE DU MOULIN", line.AgentAddress3.String)
	assert.True(t, line.AgentAddress4.Valid)
	assert.Equal(t, "10019 ROND POINT DU CANET CS", line.AgentAddress4.String)
	assert.False(t, line.AgentAddress5.Valid)
	assert.True(t, line.AgentPostCode.Valid)
	assert.Equal(t, "13590", line.AgentPostCode.String)
	assert.True(t, line.AgentTown.Valid)
	assert.Equal(t, "MEYREUIL", line.AgentTown.String)
	assert.True(t, line.AgentCountryCode.Valid)
	assert.Equal(t, "001", line.AgentCountryCode.String)
	assert.True(t, line.AgentID.Valid)
	assert.Equal(t, int64(0), line.AgentID.Int64)
	assert.True(t, line.BusinessDepartmentCode.Valid)
	assert.Equal(t, "2872", line.BusinessDepartmentCode.String)
	assert.True(t, line.BusinessDepartmentCodeForInvoice.Valid)
	assert.Equal(t, "8233", line.BusinessDepartmentCodeForInvoice.String)
	tt, err := time.Parse(util.DateLayout, "19/10/2020")
	assert.Nil(t, err)
	assert.True(t, line.ApplicationLastUpdatedDate.Valid)
	assert.Equal(t, tt, line.ApplicationLastUpdatedDate.Time)
	assert.True(t, line.ApplicationNotes.Valid)
	assert.Equal(t, "REFUS NIV 1. DELEGUE NIV 2. TRS NIV 3                              SV, LE 14/10/2020 - REFUS 3E NIV 19/10/2020 EV", line.ApplicationNotes.String)
	assert.False(t, line.ContractReference.Valid)
	assert.False(t, line.ApplicantReference.Valid)
	assert.False(t, line.InsuredAddress1.Valid)
	assert.False(t, line.InsuredAddress2.Valid)
	assert.False(t, line.InsuredAddress3.Valid)
	assert.True(t, line.InsuredAddress4.Valid)
	assert.Equal(t, "122 AVENUE FELIX FAURE", line.InsuredAddress4.String)
	assert.False(t, line.InsuredAddress5.Valid)
	assert.True(t, line.InsuredPostCode.Valid)
	assert.Equal(t, "92000", line.InsuredPostCode.String)
	assert.True(t, line.InsuredTown.Valid)
	assert.Equal(t, "NANTERRE", line.InsuredTown.String)
	assert.True(t, line.InsuredCountry.Valid)
	assert.Equal(t, "001", line.InsuredCountry.String)
	assert.False(t, line.ThirdPartyFullName.Valid)
	assert.False(t, line.ThirdPartyAddress2.Valid)
	assert.False(t, line.ThirdPartyAddress3.Valid)
	assert.False(t, line.ThirdPartyAddress4.Valid)
	assert.False(t, line.ThirdPartyAddress5.Valid)
	assert.False(t, line.ThirdPartyPostCode.Valid)
	assert.False(t, line.ThirdPartyTown.Valid)
	assert.False(t, line.ThirdPartyCountryCode.Valid)
	assert.True(t, line.DecisionApplicationLevel.Valid)
	assert.Equal(t, "RMED", line.DecisionApplicationLevel.String)
	tt, err = time.Parse(util.MacaoDateTimeLayout, "2020-10-19-15.53.02.143941")
	assert.Nil(t, err)
	assert.True(t, line.DecisionCreatedAt.Valid)
	assert.Equal(t, tt, line.DecisionCreatedAt.Time)
	tt, err = time.Parse(util.MacaoDateTimeLayout, "2020-10-19-15.53.02.143941")
	assert.Nil(t, err)
	assert.True(t, line.DecisionUpdatedAt.Valid)
	assert.Equal(t, tt, line.DecisionUpdatedAt.Time)
	assert.False(t, line.LenderEmail.Valid)
	assert.True(t, line.CBPCountryCode.Valid)
	assert.Equal(t, "00071", line.CBPCountryCode.String)
}

func TestParseFC0101(t *testing.T) {
	line, err := parseFC01Content("2020A036085;002933646;000011988;62902;99999;99999;S851752     ;888888;0000127411;CAPITOLE FINANCE                ;CAPITOLE FINANCE                ;FAX : 05 61 39 97 64            ;                                ;2839 ROUTE DE BAZIEGE           ;BP 840                          ;31670;LABEGE                    ;001;000086057;2872;9888;2020-08-26;                                                                                                                                                                                                                                    ;               ;                                ;                                ;                                ;                                ;447 BD GAMBETTA                 ;                                ;69400;VILLEFRANCHE SUR SAONE    ;001;                                ;                                ;                                ;                                ;                                ;     ;                          ;   ;    ;0001-01-01-00.00.00.000001;2020-08-26-15.17.42.297665;     ;                                           ;00071")
	if err != nil {
		fmt.Printf("cannot parse F01 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "2020A036085", line.ApplicationNumber)
	assert.Equal(t, int64(2933646), line.TypeOfMethod)
	assert.Equal(t, int64(11988), line.InsuredID)
	assert.Equal(t, "62902", line.AgentBrokerNumber)
	assert.Equal(t, "99999", line.InspectorCode)
	assert.True(t, line.NotUsedCreditor.Valid)
	assert.Equal(t, "99999", line.NotUsedCreditor.String)
	assert.True(t, line.UserUpdateName.Valid)
	assert.Equal(t, "S851752", line.UserUpdateName.String)
	assert.True(t, line.UserCode.Valid)
	assert.Equal(t, "888888", line.UserCode.String)
	assert.True(t, line.PMID.Valid)
	assert.Equal(t, int64(127411), line.PMID.Int64)
	assert.True(t, line.AgentName.Valid)
	assert.Equal(t, "CAPITOLE FINANCE", line.AgentName.String)
	assert.True(t, line.BankName.Valid)
	assert.Equal(t, "CAPITOLE FINANCE", line.BankName.String)
	assert.True(t, line.AgentAddress2.Valid)
	assert.Equal(t, "FAX : 05 61 39 97 64", line.AgentAddress2.String)
	assert.False(t, line.AgentAddress3.Valid)
	assert.True(t, line.AgentAddress4.Valid)
	assert.Equal(t, "2839 ROUTE DE BAZIEGE", line.AgentAddress4.String)
	assert.True(t, line.AgentAddress5.Valid)
	assert.Equal(t, "BP 840", line.AgentAddress5.String)
	assert.True(t, line.AgentPostCode.Valid)
	assert.Equal(t, "31670", line.AgentPostCode.String)
	assert.True(t, line.AgentTown.Valid)
	assert.Equal(t, "LABEGE", line.AgentTown.String)
	assert.True(t, line.AgentCountryCode.Valid)
	assert.Equal(t, "001", line.AgentCountryCode.String)
	assert.True(t, line.AgentID.Valid)
	assert.Equal(t, int64(86057), line.AgentID.Int64)
	assert.True(t, line.BusinessDepartmentCode.Valid)
	assert.Equal(t, "2872", line.BusinessDepartmentCode.String)
	assert.True(t, line.BusinessDepartmentCodeForInvoice.Valid)
	assert.Equal(t, "9888", line.BusinessDepartmentCodeForInvoice.String)
	tt, err := time.Parse(util.DateLayout, "26/08/2020")
	assert.Nil(t, err)
	assert.True(t, line.ApplicationLastUpdatedDate.Valid)
	assert.Equal(t, tt, line.ApplicationLastUpdatedDate.Time)
	assert.False(t, line.ApplicationNotes.Valid)
	assert.False(t, line.ContractReference.Valid)
	assert.False(t, line.ApplicantReference.Valid)
	assert.False(t, line.InsuredAddress1.Valid)
	assert.False(t, line.InsuredAddress2.Valid)
	assert.False(t, line.InsuredAddress3.Valid)
	assert.True(t, line.InsuredAddress4.Valid)
	assert.Equal(t, "447 BD GAMBETTA", line.InsuredAddress4.String)
	assert.False(t, line.InsuredAddress5.Valid)
	assert.True(t, line.InsuredPostCode.Valid)
	assert.Equal(t, "69400", line.InsuredPostCode.String)
	assert.True(t, line.InsuredTown.Valid)
	assert.Equal(t, "VILLEFRANCHE SUR SAONE", line.InsuredTown.String)
	assert.True(t, line.InsuredCountry.Valid)
	assert.Equal(t, "001", line.InsuredCountry.String)
	assert.False(t, line.ThirdPartyFullName.Valid)
	assert.False(t, line.ThirdPartyAddress2.Valid)
	assert.False(t, line.ThirdPartyAddress3.Valid)
	assert.False(t, line.ThirdPartyAddress4.Valid)
	assert.False(t, line.ThirdPartyAddress5.Valid)
	assert.False(t, line.ThirdPartyPostCode.Valid)
	assert.False(t, line.ThirdPartyTown.Valid)
	assert.False(t, line.ThirdPartyCountryCode.Valid)
	assert.False(t, line.DecisionApplicationLevel.Valid)
	assert.False(t, line.DecisionCreatedAt.Valid)
	tt, err = time.Parse(util.MacaoDateTimeLayout, "2020-08-26-15.17.42.297665")
	if assert.Nil(t, err) {
		assert.Equal(t, tt, line.DecisionUpdatedAt.Time)
	}
	assert.True(t, line.DecisionUpdatedAt.Valid)
	assert.False(t, line.LenderEmail.Valid)
	assert.True(t, line.CBPCountryCode.Valid)
	assert.Equal(t, "00071", line.CBPCountryCode.String)
}

func TestAddFC01(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if err != nil {
		fmt.Printf("cannot create DB Client: %v", err)
		t.Fail()
	}

	database := dao.CreateClient(dbClient, l)
	session := database.GetConnection()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)
	err = database.AddBatchIfNecessary(ctx, "202106301150", fileCreateTime)
	assert.Nil(t, err)

	tx, err := database.BeginTransaction(ctx)
	assert.Nil(t, err)
	assert.NotNil(t, tx)

	defer tx.Rollback()

	fileId, err := database.AddFile(ctx, tx, "202106301150", "TEST_FC01", "FC01", fileCreateTime)
	assert.Nil(t, err)
	assert.Less(t, uint(0), fileId)
	var (
		id        int
		createdAt time.Time
	)

	record := FC01Record{
		ApplicationNumber:                "2020A045800",
		TypeOfMethod:                     int64(2943361),
		InsuredID:                        int64(1152),
		AgentBrokerNumber:                "99998",
		InspectorCode:                    "99999",
		NotUsedCreditor:                  testutil.GetNullString("99999"),
		UserUpdateName:                   testutil.GetNullString("S847901"),
		UserCode:                         testutil.GetNullString("888888"),
		PMID:                             testutil.GetNullInt64(441495),
		AgentName:                        testutil.GetNullString("A.N.P DIRECT EMPRUNTEUR CI - MEI"),
		BankName:                         testutil.GetNullString("A.N.P DIRECT EMPRUNTEUR CI - MEI"),
		AgentAddress3:                    testutil.GetNullString("TECHNOPOLE DU MOULIN"),
		AgentAddress4:                    testutil.GetNullString("10019 ROND POINT DU CANET CS"),
		AgentPostCode:                    testutil.GetNullString("13590"),
		AgentTown:                        testutil.GetNullString("MEYREUIL"),
		AgentCountryCode:                 testutil.GetNullString("001"),
		AgentID:                          testutil.GetNullInt64(0),
		BusinessDepartmentCode:           testutil.GetNullString("2872"),
		BusinessDepartmentCodeForInvoice: testutil.GetNullString("8233"),
		ApplicationLastUpdatedDate:       testutil.GetNullDate("2020-10-19"),
		ApplicationNotes:                 testutil.GetNullString("REFUS NIV 1. DELEGUE NIV 2. TRS NIV 3                              SV, LE 14/10/2020 - REFUS 3E NIV 19/10/2020 EV"),
		InsuredAddress4:                  testutil.GetNullString("122 AVENUE FELIX FAURE"),
		InsuredPostCode:                  testutil.GetNullString("92000"),
		InsuredTown:                      testutil.GetNullString("NANTERRE"),
		InsuredCountry:                   testutil.GetNullString("001"),
		DecisionApplicationLevel:         testutil.GetNullString("RMED"),
		DecisionCreatedAt:                testutil.GetNullTimestamp("2020-10-19-15.53.02.143941"),
		DecisionUpdatedAt:                testutil.GetNullTimestamp("2020-10-19-15.53.02.143941"),
		CBPCountryCode:                   testutil.GetNullString("00071"),
	}

	enc := encryption.New(secretKey, nil)
	err = addFC01Record(ctx, enc, tx, fileId, &record, fileCreateTime)
	if err != nil {
		assert.Fail(t, "cannot add FC01 record", err)
		return
	}

	err = tx.Commit()
	assert.Nil(t, err)

	var (
		ApplicationNumber                string
		TypeOfMethod                     int64
		InsuredID                        int64
		AgentBrokerNumber                string
		InspectorCode                    string
		NotUsedCreditor                  sql.NullString
		UserUpdateName                   sql.NullString
		UserCode                         sql.NullString
		PMID                             sql.NullInt64
		AgentName                        sql.NullString
		BankName                         sql.NullString
		AgentAddress2                    sql.NullString
		AgentAddress3                    sql.NullString
		AgentAddress4                    sql.NullString
		AgentAddress5                    sql.NullString
		AgentPostCode                    sql.NullString
		AgentTown                        sql.NullString
		AgentCountryCode                 sql.NullString
		AgentID                          sql.NullInt64
		BusinessDepartmentCode           sql.NullString
		BusinessDepartmentCodeForInvoice sql.NullString
		ApplicationLastUpdatedDate       sql.NullTime
		ApplicationNotes                 sql.NullString
		ContractReference                sql.NullString
		ApplicantReference               sql.NullString
		InsuredAddress1                  sql.NullString
		InsuredAddress2                  sql.NullString
		InsuredAddress3                  sql.NullString
		InsuredAddress4                  sql.NullString
		InsuredAddress5                  sql.NullString
		InsuredPostCode                  sql.NullString
		InsuredTown                      sql.NullString
		InsuredCountry                   sql.NullString
		ThirdPartyFullName               sql.NullString
		ThirdPartyAddress2               sql.NullString
		ThirdPartyAddress3               sql.NullString
		ThirdPartyAddress4               sql.NullString
		ThirdPartyAddress5               sql.NullString
		ThirdPartyPostCode               sql.NullString
		ThirdPartyTown                   sql.NullString
		ThirdPartyCountryCode            sql.NullString
		DecisionApplicationLevel         sql.NullString
		DecisionCreatedAt                sql.NullTime
		DecisionUpdatedAt                sql.NullTime
		CFFEditorNumber                  sql.NullString
		LenderEmail                      sql.NullString
		CBPCountryCode                   sql.NullString
		message                          sql.NullString
	)
	row := session.QueryRowContext(ctx, "SELECT ID, APPLICATION_NUMBER, TYPE_OF_METHOD, INSURED_ID, "+
		"AGENT_BROKER_NUMBER, INSPECTOR_CODE, NOT_USED_CREDITOR, USER_UPDATE_NAME, USER_CODE, PM_ID, AGENT_NAME, BANK_NAME, "+
		"AGENT_ADDRESS_2, AGENT_ADDRESS_3, AGENT_ADDRESS_4, AGENT_ADDRESS_5, AGENT_POST_CODE, AGENT_TOWN, AGENT_COUNTRY, "+
		"AGENT_ID, BUSINESS_DEPARTMENT_CODE, BUSINESS_DEPARTMENT_CODE_FOR_INVOICE, APPLICATION_LAST_UPDATED_DATE, "+
		"APPLICATION_NOTES, CONTRACT_REFERENCE, APPLICANT_REFERENCE, INSURED_ADDRESS_1, INSURED_ADDRESS_2, INSURED_ADDRESS_3, "+
		"INSURED_ADDRESS_4, INSURED_ADDRESS_5, INSURED_POST_CODE, INSURED_TOWN, INSURED_COUNTRY_CODE, THIRD_PARTY_FULL_NAME, "+
		"THIRD_PARTY_ADDRESS_2, THIRD_PARTY_ADDRESS_3, THIRD_PARTY_ADDRESS_4, THIRD_PARTY_ADDRESS_5, THIRD_PARTY_POST_CODE, "+
		"THIRD_PARTY_TOWN, THIRD_PARTY_COUNTRY_CODE, DECISION_APPLICATION_LEVEL, DECISION_CREATED_AT, DECISION_UPDATED_AT, "+
		"CFF_EDITOR_NUMBER, LENDER_EMAIL, CBP_COUNTRY_CODE, MESSAGE, CREATED_AT FROM FC01_RECORDS WHERE FILE_ID = $1", fileId)
	err = row.Scan(&id, &ApplicationNumber, &TypeOfMethod, &InsuredID, &AgentBrokerNumber, &InspectorCode, &NotUsedCreditor, &UserUpdateName, &UserCode, &PMID, &AgentName, &BankName, &AgentAddress2, &AgentAddress3, &AgentAddress4, &AgentAddress5, &AgentPostCode, &AgentTown, &AgentCountryCode, &AgentID, &BusinessDepartmentCode, &BusinessDepartmentCodeForInvoice, &ApplicationLastUpdatedDate, &ApplicationNotes, &ContractReference, &ApplicantReference, &InsuredAddress1, &InsuredAddress2, &InsuredAddress3, &InsuredAddress4, &InsuredAddress5, &InsuredPostCode, &InsuredTown, &InsuredCountry, &ThirdPartyFullName, &ThirdPartyAddress2, &ThirdPartyAddress3, &ThirdPartyAddress4, &ThirdPartyAddress5, &ThirdPartyPostCode, &ThirdPartyTown, &ThirdPartyCountryCode, &DecisionApplicationLevel, &DecisionCreatedAt, &DecisionUpdatedAt, &CFFEditorNumber, &LenderEmail, &CBPCountryCode, &message, &createdAt)
	if err != nil {
		assert.Fail(t, "cannot read FC01 record", err)
		return
	}

	if ApplicationNotes.Valid {
		ApplicationNotes.String, err = enc.Decrypt(ApplicationNotes.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if InsuredAddress1.Valid {
		InsuredAddress1.String, err = enc.Decrypt(InsuredAddress1.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if InsuredAddress2.Valid {
		InsuredAddress2.String, err = enc.Decrypt(InsuredAddress2.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if InsuredAddress3.Valid {
		InsuredAddress3.String, err = enc.Decrypt(InsuredAddress3.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if InsuredAddress4.Valid {
		InsuredAddress4.String, err = enc.Decrypt(InsuredAddress4.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if InsuredAddress5.Valid {
		InsuredAddress5.String, err = enc.Decrypt(InsuredAddress5.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if InsuredTown.Valid {
		InsuredTown.String, err = enc.Decrypt(InsuredTown.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if ThirdPartyFullName.Valid {
		ThirdPartyFullName.String, err = enc.Decrypt(ThirdPartyFullName.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if ThirdPartyAddress2.Valid {
		ThirdPartyAddress2.String, err = enc.Decrypt(ThirdPartyAddress2.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if ThirdPartyAddress3.Valid {
		ThirdPartyAddress3.String, err = enc.Decrypt(ThirdPartyAddress3.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if ThirdPartyAddress4.Valid {
		ThirdPartyAddress4.String, err = enc.Decrypt(ThirdPartyAddress4.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if ThirdPartyAddress5.Valid {
		ThirdPartyAddress5.String, err = enc.Decrypt(ThirdPartyAddress5.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if ThirdPartyTown.Valid {
		ThirdPartyTown.String, err = enc.Decrypt(ThirdPartyTown.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	assert.Less(t, 0, id)
	assert.Equal(t, "2020A045800", ApplicationNumber)
	assert.Equal(t, int64(2943361), TypeOfMethod)
	assert.Equal(t, int64(1152), InsuredID)
	assert.Equal(t, "99998", AgentBrokerNumber)
	assert.Equal(t, "99999", InspectorCode)
	assert.True(t, NotUsedCreditor.Valid)
	assert.Equal(t, "99999", NotUsedCreditor.String)
	assert.True(t, UserUpdateName.Valid)
	assert.Equal(t, "S847901", UserUpdateName.String)
	assert.True(t, UserCode.Valid)
	assert.Equal(t, "888888", UserCode.String)
	assert.True(t, PMID.Valid)
	assert.Equal(t, int64(441495), PMID.Int64)
	assert.True(t, AgentName.Valid)
	assert.Equal(t, "A.N.P DIRECT EMPRUNTEUR CI - MEI", AgentName.String)
	assert.True(t, BankName.Valid)
	assert.Equal(t, "A.N.P DIRECT EMPRUNTEUR CI - MEI", BankName.String)
	assert.False(t, AgentAddress2.Valid)
	assert.True(t, AgentAddress3.Valid)
	assert.Equal(t, "TECHNOPOLE DU MOULIN", AgentAddress3.String)
	assert.True(t, AgentAddress4.Valid)
	assert.Equal(t, "10019 ROND POINT DU CANET CS", AgentAddress4.String)
	assert.False(t, AgentAddress5.Valid)
	assert.True(t, AgentPostCode.Valid)
	assert.Equal(t, "13590", AgentPostCode.String)
	assert.True(t, AgentTown.Valid)
	assert.Equal(t, "MEYREUIL", AgentTown.String)
	assert.True(t, AgentCountryCode.Valid)
	assert.Equal(t, "001", AgentCountryCode.String)
	assert.True(t, AgentID.Valid)
	assert.Equal(t, int64(0), AgentID.Int64)
	assert.True(t, BusinessDepartmentCode.Valid)
	assert.Equal(t, "2872", BusinessDepartmentCode.String)
	assert.True(t, BusinessDepartmentCodeForInvoice.Valid)
	assert.Equal(t, "8233", BusinessDepartmentCodeForInvoice.String)
	tt, err := time.Parse(util.DateLayout, "19/10/2020")
	assert.Nil(t, err)
	assert.True(t, ApplicationLastUpdatedDate.Valid)
	assert.Equal(t, tt, ApplicationLastUpdatedDate.Time)
	assert.True(t, ApplicationNotes.Valid)
	assert.Equal(t, "REFUS NIV 1. DELEGUE NIV 2. TRS NIV 3                              SV, LE 14/10/2020 - REFUS 3E NIV 19/10/2020 EV", ApplicationNotes.String)
	assert.False(t, ContractReference.Valid)
	assert.False(t, ApplicantReference.Valid)
	assert.False(t, InsuredAddress1.Valid)
	assert.False(t, InsuredAddress2.Valid)
	assert.False(t, InsuredAddress3.Valid)
	assert.True(t, InsuredAddress4.Valid)
	assert.Equal(t, "122 AVENUE FELIX FAURE", InsuredAddress4.String)
	assert.False(t, InsuredAddress5.Valid)
	assert.True(t, InsuredPostCode.Valid)
	assert.Equal(t, "92000", InsuredPostCode.String)
	assert.True(t, InsuredTown.Valid)
	assert.Equal(t, "NANTERRE", InsuredTown.String)
	assert.True(t, InsuredCountry.Valid)
	assert.Equal(t, "001", InsuredCountry.String)
	assert.False(t, ThirdPartyFullName.Valid)
	assert.False(t, ThirdPartyAddress2.Valid)
	assert.False(t, ThirdPartyAddress3.Valid)
	assert.False(t, ThirdPartyAddress4.Valid)
	assert.False(t, ThirdPartyAddress5.Valid)
	assert.False(t, ThirdPartyPostCode.Valid)
	assert.False(t, ThirdPartyTown.Valid)
	assert.False(t, ThirdPartyCountryCode.Valid)
	assert.True(t, DecisionApplicationLevel.Valid)
	assert.Equal(t, "RMED", DecisionApplicationLevel.String)
	tt, err = time.Parse(util.MacaoDateTimeLayout, "2020-10-19-15.53.02.143941")
	assert.Nil(t, err)
	assert.True(t, DecisionCreatedAt.Valid)
	assert.Equal(t, tt, DecisionCreatedAt.Time)
	tt, err = time.Parse(util.MacaoDateTimeLayout, "2020-10-19-15.53.02.143941")
	assert.Nil(t, err)
	assert.True(t, DecisionUpdatedAt.Valid)
	assert.Equal(t, tt, DecisionUpdatedAt.Time)
	assert.False(t, LenderEmail.Valid)
	assert.True(t, CBPCountryCode.Valid)
	assert.Equal(t, "00071", CBPCountryCode.String)

	assert.False(t, message.Valid)
	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
	row = session.QueryRowContext(ctx, "SELECT MODIFIED_AT, STATUS, MESSAGE FROM FC01_RECORDS_HISTORY WHERE ID = $1", id)
	var status string
	err = row.Scan(&createdAt, &status, &message)
	if err != nil {
		assert.Fail(t, "cannot read FC01 record", err)
	}

	assert.Equal(t, "ADDED", status)
	assert.False(t, message.Valid)
	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
	err = database.CompleteBatchIfPossible(ctx, "202106301150")
	assert.Nil(t, err)
}
