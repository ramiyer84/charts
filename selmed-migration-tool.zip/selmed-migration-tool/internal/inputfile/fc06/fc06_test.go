package fc06

import (
	"context"
	"database/sql"
	"fmt"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/mrt-shared/encryption"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/testutil"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/stretchr/testify/assert"
	"log"
	"os"
	"testing"
	"time"
)

var (
	cb        *db.ConnectionBuilder
	l         *logger.Logger
	secretKey string
)

func TestMain(m *testing.M) {
	l = logger.Create("fc06_test")

	dat, err := os.ReadFile("../../../secret.key")
	if err != nil {
		log.Fatalf("cannot read AES key from file system: %v", err)
	}

	secretKey = string(dat)

	ctx := context.Background()
	pg, net, host, port := testutil.Init()
	defer func() {
		if err := net.Remove(ctx); err != nil {
			log.Fatalf("failed to remove network: %s", err)
		}
	}()

	defer pg.Terminate(ctx)

	cb = db.NewConnectionBuilder("pgx", host, port, "migrationdb").
		Username("migowner").
		Password("Password1")

	os.Exit(m.Run())
}

func TestParseFC0600(t *testing.T) {
	line, err := parseFC06Content("000001152;SME;2020-10-12-13.49.02.155039;                                ;                                ;                                ;122 AVENUE FELIX FAURE          ;                                ;92000;NANTERRE                  ;001;0607060784;          ;")
	if err != nil {
		fmt.Printf("cannot parse F01 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, int64(1152), line.InsuredID)
	assert.True(t, line.InsuredRole.Valid)
	assert.Equal(t, "SME", line.InsuredRole.String)
	tt, err := time.Parse(util.MacaoDateTimeLayout, "2020-10-12-13.49.02.155039")
	assert.Nil(t, err)
	assert.True(t, line.AddressCreationDate.Valid)
	assert.Equal(t, tt, line.AddressCreationDate.Time)
	assert.False(t, line.AddressLine1.Valid)
	assert.False(t, line.AddressLine2.Valid)
	assert.False(t, line.AddressLine3.Valid)
	assert.True(t, line.AddressLine4.Valid)
	assert.Equal(t, "122 AVENUE FELIX FAURE", line.AddressLine4.String)
	assert.False(t, line.AddressLine5.Valid)
	assert.True(t, line.PostCode.Valid)
	assert.Equal(t, "92000", line.PostCode.String)
	assert.True(t, line.Town.Valid)
	assert.Equal(t, "NANTERRE", line.Town.String)
	assert.True(t, line.CountryCode.Valid)
	assert.Equal(t, "001", line.CountryCode.String)
	assert.True(t, line.MobileNumber.Valid)
	assert.Equal(t, "0607060784", line.MobileNumber.String)
	assert.False(t, line.PhoneNumber.Valid)
	assert.False(t, line.Email.Valid)
}

func TestParseFC0601(t *testing.T) {
	line, err := parseFC06Content("000011988;SME;2020-08-26-12.29.55.714440;                                ;                                ;                                ;447 BD GAMBETTA                 ;                                ;69400;VILLEFRANCHE SUR SAONE    ;001;          ;          ;")
	if err != nil {
		fmt.Printf("cannot parse F01 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, int64(11988), line.InsuredID)
	assert.True(t, line.InsuredRole.Valid)
	assert.Equal(t, "SME", line.InsuredRole.String)
	tt, err := time.Parse(util.MacaoDateTimeLayout, "2020-08-26-12.29.55.714440")
	assert.Nil(t, err)
	assert.True(t, line.AddressCreationDate.Valid)
	assert.Equal(t, tt, line.AddressCreationDate.Time)
	assert.False(t, line.AddressLine1.Valid)
	assert.False(t, line.AddressLine2.Valid)
	assert.False(t, line.AddressLine3.Valid)
	assert.True(t, line.AddressLine4.Valid)
	assert.Equal(t, "447 BD GAMBETTA", line.AddressLine4.String)
	assert.False(t, line.AddressLine5.Valid)
	assert.True(t, line.PostCode.Valid)
	assert.Equal(t, "69400", line.PostCode.String)
	assert.True(t, line.Town.Valid)
	assert.Equal(t, "VILLEFRANCHE SUR SAONE", line.Town.String)
	assert.True(t, line.CountryCode.Valid)
	assert.Equal(t, "001", line.CountryCode.String)
	assert.False(t, line.MobileNumber.Valid)
	assert.False(t, line.PhoneNumber.Valid)
	assert.False(t, line.Email.Valid)
}

func TestAddFC06(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if err != nil {
		fmt.Printf("cannot create DB Client: %v", err)
		t.Fail()
	}

	database := dao.CreateClient(dbClient, l)
	session := database.GetConnection()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)

	err = database.AddBatchIfNecessary(ctx, "202106301150", fileCreateTime)
	assert.Nil(t, err)

	tx, err := database.BeginTransaction(ctx)
	assert.Nil(t, err)
	assert.NotNil(t, tx)

	defer tx.Rollback()

	fileId, err := database.AddFile(ctx, tx, "202106301150", "TEST_FC06", "FC06", fileCreateTime)
	assert.Nil(t, err)
	assert.Less(t, uint(0), fileId)
	var (
		id        int
		createdAt time.Time
	)

	record := FC06Record{
		InsuredID:           int64(1152),
		InsuredRole:         testutil.GetNullString("SME"),
		AddressCreationDate: testutil.GetNullTimestamp("2020-10-12-13.49.02.155039"),
		AddressLine4:        testutil.GetNullString("122 AVENUE FELIX FAURE"),
		PostCode:            testutil.GetNullString("92000"),
		Town:                testutil.GetNullString("NANTERRE"),
		CountryCode:         testutil.GetNullString("001"),
		MobileNumber:        testutil.GetNullString("0607060784"),
	}

	enc := encryption.New(secretKey, nil)
	err = addFC06Record(ctx, enc, tx, fileId, &record, fileCreateTime)
	if err != nil {
		assert.Fail(t, "cannot add FC06 record", err)
		return
	}

	err = tx.Commit()
	assert.Nil(t, err)

	var (
		InsuredID           int64
		InsuredRole         sql.NullString
		AddressCreationDate sql.NullTime
		AddressLine1        sql.NullString
		AddressLine2        sql.NullString
		AddressLine3        sql.NullString
		AddressLine4        sql.NullString
		AddressLine5        sql.NullString
		PostCode            sql.NullString
		Town                sql.NullString
		CountryCode         sql.NullString
		MobileNumber        sql.NullString
		PhoneNumber         sql.NullString
		Email               sql.NullString
	)
	row := session.QueryRowContext(ctx, "SELECT ID, INSURED_ID, INSURED_ROLE, ADDRESS_CREATION_DATE, "+
		"ADDRESS_LINE_1, ADDRESS_LINE_2, ADDRESS_LINE_3, ADDRESS_LINE_4, ADDRESS_LINE_5, POST_CODE, TOWN, COUNTRY_CODE, "+
		"MOBILE_NUMBER, TELEPHONE_NUMBER, EMAIL, CREATED_AT FROM FC06_RECORDS WHERE FILE_ID = $1", fileId)
	err = row.Scan(&id, &InsuredID, &InsuredRole, &AddressCreationDate, &AddressLine1, &AddressLine2, &AddressLine3,
		&AddressLine4, &AddressLine5, &PostCode, &Town, &CountryCode, &MobileNumber, &PhoneNumber, &Email, &createdAt)
	if err != nil {
		assert.Fail(t, "cannot read FC06 record", err)
		return
	}

	assert.Less(t, 0, id)

	if AddressLine1.Valid {
		AddressLine1.String, err = enc.Decrypt(AddressLine1.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if AddressLine2.Valid {
		AddressLine2.String, err = enc.Decrypt(AddressLine2.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if AddressLine3.Valid {
		AddressLine3.String, err = enc.Decrypt(AddressLine3.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if AddressLine4.Valid {
		AddressLine4.String, err = enc.Decrypt(AddressLine4.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if AddressLine5.Valid {
		AddressLine5.String, err = enc.Decrypt(AddressLine5.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if Town.Valid {
		Town.String, err = enc.Decrypt(Town.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if MobileNumber.Valid {
		MobileNumber.String, err = enc.Decrypt(MobileNumber.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if PhoneNumber.Valid {
		PhoneNumber.String, err = enc.Decrypt(PhoneNumber.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if Email.Valid {
		Email.String, err = enc.Decrypt(Email.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	assert.Equal(t, int64(1152), InsuredID)
	assert.True(t, InsuredRole.Valid)
	assert.Equal(t, "SME", InsuredRole.String)
	tt, err := time.Parse(util.MacaoDateTimeLayout, "2020-10-12-13.49.02.155039")
	assert.Nil(t, err)
	assert.True(t, AddressCreationDate.Valid)
	assert.Equal(t, tt, AddressCreationDate.Time)
	assert.False(t, AddressLine1.Valid)
	assert.False(t, AddressLine2.Valid)
	assert.False(t, AddressLine3.Valid)
	assert.True(t, AddressLine4.Valid)
	assert.Equal(t, "122 AVENUE FELIX FAURE", AddressLine4.String)
	assert.False(t, AddressLine5.Valid)
	assert.True(t, PostCode.Valid)
	assert.Equal(t, "92000", PostCode.String)
	assert.True(t, Town.Valid)
	assert.Equal(t, "NANTERRE", Town.String)
	assert.True(t, CountryCode.Valid)
	assert.Equal(t, "001", CountryCode.String)
	assert.True(t, MobileNumber.Valid)
	assert.Equal(t, "0607060784", MobileNumber.String)
	assert.False(t, PhoneNumber.Valid)
	assert.False(t, Email.Valid)

	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
}
