package inputfile

import (
	"context"
	"database/sql"
	"github.axa.com/axa-partners-clp/mrt-shared/encryption"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.com/spf13/viper"
	"os"
	"path/filepath"
	"sync"
)

var Version = "0.0.1-SNAPSHOT"

type SourceFile struct {
	BatchID          string
	Filepath         string
	Filename         string
	OriginalFileName string
	Encryption       encryption.Client
	Db               *dao.DB
	Tx               *sql.Tx
	Logger           *logger.Logger
	Range            *Range
	Wg               *sync.WaitGroup
}

type FC interface {
	AsyncProcessFile(ctx context.Context)
	ProcessFile(ctx context.Context) error
}

func (sf SourceFile) Process(ctx context.Context, processFile func(ctx2 context.Context) error) {
	var failed bool
	sf.Wg.Add(1)
	defer sf.Wg.Done()

	err := processFile(ctx)
	if err != nil {
		failed = true
		sf.Logger.Printf("cannot process file %s: %v", sf.Filepath, err)
	}
	ProcessResponse(failed, sf.Tx, sf.Filepath, sf.OriginalFileName, sf.Logger)
}

func ProcessResponse(failed bool, tx *sql.Tx, filePath string, fileName string, l *logger.Logger) {
	if failed {
		err := tx.Rollback()
		if err != nil {
			l.Printf("cannot rollback transaction: %v", err)
		}

		MoveToError(filePath, fileName, l)
	} else {
		err := tx.Commit()
		if err != nil {
			l.Printf("cannot commit transaction storing file '%s' content: %v", fileName, err)
			MoveToError(filePath, fileName, l)
		}

		MoveToProcessed(filePath, fileName, l)
	}
}

func MoveToProcessed(filePath string, name string, l *logger.Logger) {
	processedPath := filepath.Join(viper.GetString("location.processed"), name)
	err := os.Rename(filePath, processedPath)
	if err != nil {
		l.Printf("cannot move file '%s' to '%s': %v", filePath, processedPath, err)
		os.Exit(1)
	}
}

func MoveToError(filePath string, name string, l *logger.Logger) {
	errorPath := filepath.Join(viper.GetString("location.error"), name)
	err := os.Rename(filePath, errorPath)
	if err != nil {
		l.Printf("cannot move file '%s' to '%s': %v", filePath, errorPath, err)
		os.Exit(1)
	}
}
