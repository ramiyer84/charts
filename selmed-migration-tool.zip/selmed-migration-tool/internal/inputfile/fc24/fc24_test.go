package fc24

import (
	"context"
	"database/sql"
	"fmt"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/testutil"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/stretchr/testify/assert"
	"log"
	"os"
	"testing"
	"time"
)

var (
	cb *db.ConnectionBuilder
	l  *logger.Logger
)

func TestMain(m *testing.M) {
	l = logger.Create("fc24_test")

	ctx := context.Background()
	pg, net, host, port := testutil.Init()
	defer func() {
		if err := net.Remove(ctx); err != nil {
			log.Fatalf("failed to remove network: %s", err)
		}
	}()

	defer pg.Terminate(ctx)

	cb = db.NewConnectionBuilder("pgx", host, port, "migrationdb").
		Username("migowner").
		Password("Password1")

	os.Exit(m.Run())
}

func TestParse(t *testing.T) {
	line, err := parse("2021A015127;001320329;002040142;LDP;P;2021-07-30")
	if err != nil {
		fmt.Printf("cannot parse FC24 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "2021A015127", line.ApplicationNumber)
	assert.Equal(t, int64(1320329), line.MailEventID)
	assert.Equal(t, int64(2040142), line.LetterID)
	assert.Equal(t, "LDP", line.LetterTypeCode)
	assert.True(t, line.RecipientTypeCode.Valid)
	assert.Equal(t, "P", line.RecipientTypeCode.String)
	tt, err := time.Parse(util.AltDateLayout, "2021-07-30")
	if !assert.Nil(t, err) {
		return
	}
	assert.True(t, line.LetterCreationDate.Valid)
	assert.Equal(t, tt, line.LetterCreationDate.Time)
}

func TestAddRecord(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if err != nil {
		fmt.Printf("cannot create DB Client: %v", err)
		t.Fail()
	}

	database := dao.CreateClient(dbClient, l)
	session := database.GetConnection()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)

	err = database.AddBatchIfNecessary(ctx, "202106301150", fileCreateTime)
	assert.Nil(t, err)

	tx, err := database.BeginTransaction(ctx)
	assert.Nil(t, err)
	assert.NotNil(t, tx)

	defer tx.Rollback()

	fileId, err := database.AddFile(ctx, tx, "202106301150", "TEST_FC24", "FC24", fileCreateTime)
	assert.Nil(t, err)
	assert.Less(t, uint(0), fileId)
	var (
		id        int
		createdAt time.Time
	)

	record := FC24Record{
		ApplicationNumber:  "2020A045800",
		MailEventID:        int64(6414515),
		LetterID:           int64(7263495),
		LetterTypeCode:     "SS1",
		LetterCreationDate: testutil.GetNullDate("2020-09-17"),
		RecipientTypeCode:  testutil.GetNullString("P"),
	}

	err = addRecord(ctx, tx, fileId, &record, fileCreateTime)
	if err != nil {
		assert.Fail(t, "cannot add FC24 record", err)
		return
	}

	err = tx.Commit()
	assert.Nil(t, err)

	var (
		ApplicationNumber  string
		MaiEventID         int64
		LetterID           int64
		LetterTypeCode     string
		RecipientTypeCode  sql.NullString
		LetterCreationDate sql.NullTime
	)
	row := session.QueryRowContext(ctx, `SELECT ID, APPLICATION_NUMBER, MAIL_EVENT_ID, LETTER_ID, LETTER_TYPE_CODE,
		RECIPIENT_TYPE_CODE, LETTER_CREATION_DATE, CREATED_AT
		FROM FC24_RECORDS WHERE FILE_ID = $1`, fileId)
	err = row.Scan(&id, &ApplicationNumber, &MaiEventID, &LetterID, &LetterTypeCode, &RecipientTypeCode, &LetterCreationDate, &createdAt)
	if err != nil {
		assert.Fail(t, "cannot read FC24 record", err)
		return
	}

	assert.Less(t, 0, id)
	assert.Equal(t, "2020A045800", ApplicationNumber)
	assert.Equal(t, int64(6414515), MaiEventID)
	assert.Equal(t, int64(7263495), LetterID)
	assert.Equal(t, "SS1", LetterTypeCode)
	tt, err := time.Parse(util.AltDateLayout, "2020-09-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.True(t, LetterCreationDate.Valid)
	assert.Equal(t, tt, LetterCreationDate.Time)
	assert.True(t, RecipientTypeCode.Valid)
	assert.Equal(t, "P", RecipientTypeCode.String)

	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
}
