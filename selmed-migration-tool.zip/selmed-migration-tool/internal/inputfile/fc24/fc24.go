package fc24

import (
	"bufio"
	"context"
	"database/sql"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"os"
	"strings"
	"time"
)

type File struct {
	*inputfile.SourceFile
}

type FC24Record struct {
	ApplicationNumber  string         // line[0]
	MailEventID        int64          // line[1]
	LetterID           int64          // line[2]
	LetterTypeCode     string         // line[3]
	RecipientTypeCode  sql.NullString // line[4]
	LetterCreationDate sql.NullTime   // line[5]
}

func (fc File) AsyncProcessFile(ctx context.Context) {
	fc.Process(ctx, fc.ProcessFile)
}

func (fc File) ProcessFile(ctx context.Context) error {
	f, err := os.Open(fc.Filepath)
	if err != nil {
		return err
	}
	defer f.Close()

	addedAt := time.Now().UTC()
	id, err := fc.Db.AddFile(ctx, fc.Tx, fc.BatchID, fc.Filename, "FC24", addedAt)
	if err != nil {
		return err
	}

	r := bufio.NewScanner(f)
	// Skip the first line
	r.Scan()

	count := 0
	added := 0
	for r.Scan() {
		count++
		line := r.Text()
		applicationNumber := line[:11]
		if len(line) < 48 {
			fc.Logger.Printf("line %d: application '%s' has incorrect line length %d", count, applicationNumber, len(line))
			continue
		}

		if fc.Range.ApplicationNumberExists(applicationNumber) {
			record, err := parse(line)
			if err != nil {
				applicationNumber := line[:11]
				fc.Logger.Printf("line %d: line length %d, cannot parse FC24 line for application %s (%s): %v", count, len(line), applicationNumber, line, err)
				err = nil
				continue
			}

			err = addRecord(ctx, fc.Tx, id, record, addedAt)
			if err != nil {
				fc.Logger.Printf("cannot add FC24 record to Database from line %d (%s): %v", count, line, err)
				return err
			}
			added++
		}
	}

	err = fc.Db.UpdateFileStatus(ctx, fc.Tx, "IMPORTED", id, time.Now().UTC())
	if err != nil {
		return err
	}

	fc.Logger.Printf("completed processing '%s' file: loaded %d records", fc.Filename, added)
	return nil
}

func parse(line string) (*FC24Record, error) {
	var err error

	data := []rune(line)

	// Application Number
	tmp := strings.TrimSpace(util.SubstringBeginning(data, 11))
	record := FC24Record{
		ApplicationNumber: tmp,
	}

	// Mail Event ID
	record.MailEventID, err = util.ReadInt64(util.Substring(data, 12, 21))
	if err != nil {
		return nil, err
	}

	// Letter ID
	record.LetterID, err = util.ReadInt64(util.Substring(data, 22, 31))
	if err != nil {
		return nil, err
	}

	// Letter Type Code
	record.LetterTypeCode = util.Substring(data, 32, 35)

	// Recipient Type Code
	record.RecipientTypeCode = util.ReadNullString(util.Substring(data, 36, 37))

	// Letter Creation Date
	record.LetterCreationDate, err = util.ReadDB2NullDate(util.SubstringEnd(data, 38))
	if err != nil {
		return nil, err
	}

	return &record, nil
}

func addRecord(ctx context.Context, tx *sql.Tx, fileId uint, record *FC24Record, addedAt time.Time) error {
	var id uint

	err := tx.QueryRowContext(ctx, `INSERT INTO FC24_RECORDS (ID, FILE_ID, APPLICATION_NUMBER, MAIL_EVENT_ID, LETTER_ID, 
		LETTER_TYPE_CODE, LETTER_CREATION_DATE, RECIPIENT_TYPE_CODE, CREATED_AT) VALUES (NEXTVAL('FC24_SEQ'), $1, $2, $3,
		$4, $5, $6, $7, $8) RETURNING ID
		`,
		fileId, record.ApplicationNumber, record.MailEventID, record.LetterID, record.LetterTypeCode, record.LetterCreationDate,
		record.RecipientTypeCode, addedAt).Scan(&id)

	if err != nil {
		return err
	}

	return nil
}
