package fc27

import (
	"context"
	"database/sql"
	"fmt"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/testutil"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/stretchr/testify/assert"
	"log"
	"os"
	"testing"
	"time"
)

var (
	cb *db.ConnectionBuilder
	l  *logger.Logger
)

func TestMain(m *testing.M) {
	l = logger.Create("fc27_test")

	ctx := context.Background()
	pg, net, host, port := testutil.Init()
	defer func() {
		if err := net.Remove(ctx); err != nil {
			log.Fatalf("failed to remove network: %s", err)
		}
	}()

	defer pg.Terminate(ctx)

	cb = db.NewConnectionBuilder("pgx", host, port, "migrationdb").
		Username("migowner").
		Password("Password1")

	os.Exit(m.Run())
}

func TestParse(t *testing.T) {
	line, err := parse("2021A008758;001317077;002036167;000760286;C26;2021-02-17")
	if err != nil {
		fmt.Printf("cannot parse FC27 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "2021A008758", line.ApplicationNumber)
	assert.Equal(t, int64(1317077), line.MailEventID)
	assert.Equal(t, int64(2036167), line.LetterID)
	assert.Equal(t, int64(760286), line.ClauseID)
	assert.Equal(t, "C26", line.ClauseCode)
	assert.True(t, line.ClauseCreationDate.Valid)
	tt, err := time.Parse(util.AltDateLayout, "2021-02-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.Equal(t, tt, line.ClauseCreationDate.Time)
}

func TestAddRecord(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if err != nil {
		fmt.Printf("cannot create DB Client: %v", err)
		t.Fail()
	}

	database := dao.CreateClient(dbClient, l)
	session := database.GetConnection()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)

	err = database.AddBatchIfNecessary(ctx, "202106301150", fileCreateTime)
	assert.Nil(t, err)

	tx, err := database.BeginTransaction(ctx)
	assert.Nil(t, err)
	assert.NotNil(t, tx)

	defer tx.Rollback()

	fileId, err := database.AddFile(ctx, tx, "202106301150", "TEST_FC27", "FC27", fileCreateTime)
	assert.Nil(t, err)
	assert.Less(t, uint(0), fileId)
	var (
		id        int
		createdAt time.Time
	)

	record := FC27Record{
		ApplicationNumber:  "2020A045800",
		MailEventID:        int64(6414515),
		LetterID:           int64(1723),
		ClauseID:           int64(37),
		ClauseCode:         "VT1",
		ClauseCreationDate: testutil.GetNullDate("2020-09-17"),
	}

	err = addRecord(ctx, tx, fileId, &record, fileCreateTime)
	if err != nil {
		assert.Fail(t, "cannot add FC27 record", err)
		return
	}

	err = tx.Commit()
	assert.Nil(t, err)

	var (
		ApplicationNumber  string
		MaiEventID         int64
		LetterID           int64
		ClauseID           int64
		ClauseCode         string
		ClauseCreationDate sql.NullTime
	)
	row := session.QueryRowContext(ctx, `SELECT ID, APPLICATION_NUMBER, MAIL_EVENT_ID, LETTER_ID, CLAUSE_ID,
		CLAUSE_CODE, CLAUSE_CREATION_DATE, CREATED_AT
		FROM FC27_RECORDS WHERE FILE_ID = $1`, fileId)
	err = row.Scan(&id, &ApplicationNumber, &MaiEventID, &LetterID, &ClauseID, &ClauseCode,
		&ClauseCreationDate, &createdAt)
	if err != nil {
		assert.Fail(t, "cannot read FC27 record", err)
		return
	}

	assert.Less(t, 0, id)
	assert.Equal(t, "2020A045800", ApplicationNumber)
	assert.Equal(t, int64(6414515), MaiEventID)
	assert.Equal(t, int64(1723), LetterID)
	assert.Equal(t, int64(37), ClauseID)
	assert.Equal(t, "VT1", ClauseCode)
	tt, err := time.Parse(util.AltDateLayout, "2020-09-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.True(t, ClauseCreationDate.Valid)
	assert.Equal(t, tt, ClauseCreationDate.Time)

	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
}
