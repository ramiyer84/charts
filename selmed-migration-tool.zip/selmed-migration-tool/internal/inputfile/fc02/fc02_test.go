package fc02

import (
	"context"
	"database/sql"
	"fmt"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/testutil"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/stretchr/testify/assert"
	"log"
	"os"
	"testing"
	"time"
)

var (
	cb *db.ConnectionBuilder
	l  *logger.Logger
)

func TestMain(m *testing.M) {
	l = logger.Create("db_access_test")

	ctx := context.Background()
	pg, net, host, port := testutil.Init()
	defer func() {
		if err := net.Remove(ctx); err != nil {
			log.Fatalf("failed to remove network: %s", err)
		}
	}()

	defer pg.Terminate(ctx)

	cb = db.NewConnectionBuilder("pgx", host, port, "migrationdb").
		Username("migowner").
		Password("Password1")

	os.Exit(m.Run())
}

func TestParseFC0200(t *testing.T) {
	line, err := parseFC02Content("2020A045800;006414515;2020092800466-3 ; ;1404213000000;98;2020-09-17;   150000;120;100.00;IM;   ;  ;E; 0.000; 0.000; 0.000;                ;EUR;                ;        ; 0.000; 0.000; 0.000; 0.000; ; ;        0")
	if err != nil {
		fmt.Printf("cannot parse F01 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "2020A045800", line.ApplicationNumber)
	assert.Equal(t, int64(6414515), line.LoanID)
	assert.True(t, line.LoanNumber.Valid)
	assert.Equal(t, "2020092800466-3", line.LoanNumber.String)
	assert.False(t, line.LoanNumberKey.Valid)
	assert.True(t, line.RPP.Valid)
	assert.Equal(t, "1404213000000", line.RPP.String)
	assert.True(t, line.EmployeeTypeCode.Valid)
	assert.Equal(t, "98", line.EmployeeTypeCode.String)
	tt, err := time.Parse(util.AltDateLayout, "2020-09-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.True(t, line.AdhesionDate.Valid)
	assert.Equal(t, tt, line.AdhesionDate.Time)
	assert.True(t, line.LoanCapitalAmount.Valid)
	assert.Equal(t, int64(150000), line.LoanCapitalAmount.Int64)
	assert.True(t, line.LoanDurationMonths.Valid)
	assert.Equal(t, "120", line.LoanDurationMonths.String)
	assert.True(t, line.InsuredCapitaRate.Valid)
	assert.Equal(t, 100.0, line.InsuredCapitaRate.Float64)
	assert.True(t, line.LoanType.Valid)
	assert.Equal(t, "IM", line.LoanType.String)
	assert.False(t, line.ProfessionCode.Valid)
	assert.False(t, line.CFF.Valid)
	assert.True(t, line.BorrowerStatus.Valid)
	assert.Equal(t, "E", line.BorrowerStatus.String)
	assert.True(t, line.PremiumCalledRate.Valid)
	assert.Equal(t, 0.0, line.PremiumCalledRate.Float64)
	assert.True(t, line.NormalRate.Valid)
	assert.Equal(t, 0.0, line.NormalRate.Float64)
	assert.True(t, line.OverPremiumRate.Valid)
	assert.Equal(t, 0.0, line.OverPremiumRate.Float64)
	assert.False(t, line.LoanReferenceNumber.Valid)
	assert.True(t, line.CurrencyCode.Valid)
	assert.Equal(t, "EUR", line.CurrencyCode.String)
	assert.False(t, line.CFFLoanNumber.Valid)
	assert.False(t, line.ProductCode.Valid)
	assert.True(t, line.NormalDeathRate.Valid)
	assert.Equal(t, 0.0, line.NormalDeathRate.Float64)
	assert.True(t, line.NormalInvalidityRate.Valid)
	assert.Equal(t, 0.0, line.NormalInvalidityRate.Float64)
	assert.True(t, line.OverpremiumDeathRate.Valid)
	assert.Equal(t, 0.0, line.OverpremiumDeathRate.Float64)
	assert.True(t, line.OverpremiumInvalidityRate.Valid)
	assert.Equal(t, 0.0, line.OverpremiumInvalidityRate.Float64)
	assert.False(t, line.GISAerasCover.Valid)
	assert.False(t, line.AerasCapping.Valid)
	assert.True(t, line.OngoingAmount.Valid)
	assert.Equal(t, int64(0), line.OngoingAmount.Int64)
}

func TestParseFC0201(t *testing.T) {
	line, err := parseFC02Content("2020A036085;006378841;                ; ;2431323800080;98;2020-07-31;    24812;048;100.00;DI;   ;  ;E; 1.080; 0.540; 0.540;                ;EUR;                ;        ; 0.540; 0.000; 0.540; 0.000; ; ;        0")
	if err != nil {
		fmt.Printf("cannot parse F01 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "2020A036085", line.ApplicationNumber)
	assert.Equal(t, int64(6378841), line.LoanID)
	assert.False(t, line.LoanNumber.Valid)
	assert.False(t, line.LoanNumberKey.Valid)
	assert.True(t, line.RPP.Valid)
	assert.Equal(t, "2431323800080", line.RPP.String)
	assert.True(t, line.EmployeeTypeCode.Valid)
	assert.Equal(t, "98", line.EmployeeTypeCode.String)
	tt, err := time.Parse(util.AltDateLayout, "2020-07-31")
	assert.Nil(t, err)
	assert.True(t, line.AdhesionDate.Valid)
	assert.Equal(t, tt, line.AdhesionDate.Time)
	assert.True(t, line.LoanCapitalAmount.Valid)
	assert.Equal(t, int64(24812), line.LoanCapitalAmount.Int64)
	assert.True(t, line.LoanDurationMonths.Valid)
	assert.Equal(t, "048", line.LoanDurationMonths.String)
	assert.True(t, line.InsuredCapitaRate.Valid)
	assert.Equal(t, 100.0, line.InsuredCapitaRate.Float64)
	assert.True(t, line.LoanType.Valid)
	assert.Equal(t, "DI", line.LoanType.String)
	assert.False(t, line.ProfessionCode.Valid)
	assert.False(t, line.CFF.Valid)
	assert.True(t, line.BorrowerStatus.Valid)
	assert.Equal(t, "E", line.BorrowerStatus.String)
	assert.True(t, line.PremiumCalledRate.Valid)
	assert.Equal(t, 1.08, line.PremiumCalledRate.Float64)
	assert.True(t, line.NormalRate.Valid)
	assert.Equal(t, 0.54, line.NormalRate.Float64)
	assert.True(t, line.OverPremiumRate.Valid)
	assert.Equal(t, 0.54, line.OverPremiumRate.Float64)
	assert.False(t, line.LoanReferenceNumber.Valid)
	assert.True(t, line.CurrencyCode.Valid)
	assert.Equal(t, "EUR", line.CurrencyCode.String)
	assert.False(t, line.CFFLoanNumber.Valid)
	assert.False(t, line.ProductCode.Valid)
	assert.True(t, line.NormalDeathRate.Valid)
	assert.Equal(t, 0.54, line.NormalDeathRate.Float64)
	assert.True(t, line.NormalInvalidityRate.Valid)
	assert.Equal(t, 0.0, line.NormalInvalidityRate.Float64)
	assert.True(t, line.OverpremiumDeathRate.Valid)
	assert.Equal(t, 0.54, line.OverpremiumDeathRate.Float64)
	assert.True(t, line.OverpremiumInvalidityRate.Valid)
	assert.Equal(t, 0.0, line.OverpremiumInvalidityRate.Float64)
	assert.False(t, line.GISAerasCover.Valid)
	assert.False(t, line.AerasCapping.Valid)
	assert.True(t, line.OngoingAmount.Valid)
	assert.Equal(t, int64(0), line.OngoingAmount.Int64)
}

func TestParseFC0202(t *testing.T) {
	line, err := parseFC02Content("2021A008095;006492570;1113320         ; ;1497923000000;98;2021-01-22;   256534;240; 50.00;IM;   ;  ;E; 0.480; 0.480; 0.000;                ;EUR;1113320         ;        ; 0.336; 0.144; 0.000; 0.000; ; ;        221230")
	if err != nil {
		fmt.Printf("cannot parse F01 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "2021A008095", line.ApplicationNumber)
	assert.Equal(t, int64(6492570), line.LoanID)
	assert.True(t, line.LoanNumber.Valid)
	assert.Equal(t, "1113320", line.LoanNumber.String)
	assert.False(t, line.LoanNumberKey.Valid)
	assert.True(t, line.RPP.Valid)
	assert.Equal(t, "1497923000000", line.RPP.String)
	assert.True(t, line.EmployeeTypeCode.Valid)
	assert.Equal(t, "98", line.EmployeeTypeCode.String)
	tt, err := time.Parse(util.AltDateLayout, "2021-01-22")
	assert.Nil(t, err)
	assert.True(t, line.AdhesionDate.Valid)
	assert.Equal(t, tt, line.AdhesionDate.Time)
	assert.True(t, line.LoanCapitalAmount.Valid)
	assert.Equal(t, int64(256534), line.LoanCapitalAmount.Int64)
	assert.True(t, line.LoanDurationMonths.Valid)
	assert.Equal(t, "240", line.LoanDurationMonths.String)
	assert.True(t, line.InsuredCapitaRate.Valid)
	assert.Equal(t, 50.0, line.InsuredCapitaRate.Float64)
	assert.True(t, line.LoanType.Valid)
	assert.Equal(t, "IM", line.LoanType.String)
	assert.False(t, line.ProfessionCode.Valid)
	assert.False(t, line.CFF.Valid)
	assert.True(t, line.BorrowerStatus.Valid)
	assert.Equal(t, "E", line.BorrowerStatus.String)
	assert.True(t, line.PremiumCalledRate.Valid)
	assert.Equal(t, 0.48, line.PremiumCalledRate.Float64)
	assert.True(t, line.NormalRate.Valid)
	assert.Equal(t, 0.48, line.NormalRate.Float64)
	assert.True(t, line.OverPremiumRate.Valid)
	assert.Equal(t, 0.0, line.OverPremiumRate.Float64)
	assert.False(t, line.LoanReferenceNumber.Valid)
	assert.True(t, line.CurrencyCode.Valid)
	assert.Equal(t, "EUR", line.CurrencyCode.String)
	assert.True(t, line.CFFLoanNumber.Valid)
	assert.Equal(t, "1113320", line.CFFLoanNumber.String)
	assert.False(t, line.ProductCode.Valid)
	assert.True(t, line.NormalDeathRate.Valid)
	assert.Equal(t, 0.336, line.NormalDeathRate.Float64)
	assert.True(t, line.NormalInvalidityRate.Valid)
	assert.Equal(t, 0.144, line.NormalInvalidityRate.Float64)
	assert.True(t, line.OverpremiumDeathRate.Valid)
	assert.Equal(t, 0.0, line.OverpremiumDeathRate.Float64)
	assert.True(t, line.OverpremiumInvalidityRate.Valid)
	assert.Equal(t, 0.0, line.OverpremiumInvalidityRate.Float64)
	assert.False(t, line.GISAerasCover.Valid)
	assert.False(t, line.AerasCapping.Valid)
	assert.True(t, line.OngoingAmount.Valid)
	assert.Equal(t, int64(221230), line.OngoingAmount.Int64)
}

func TestAddFC02(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if err != nil {
		fmt.Printf("cannot create DB Client: %v", err)
		t.Fail()
	}

	database := dao.CreateClient(dbClient, l)
	session := database.GetConnection()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)

	err = database.AddBatchIfNecessary(ctx, "202106301150", fileCreateTime)
	assert.Nil(t, err)

	tx, err := database.BeginTransaction(ctx)
	assert.Nil(t, err)
	assert.NotNil(t, tx)

	defer tx.Rollback()

	fileId, err := database.AddFile(ctx, tx, "202106301150", "TEST_FC02", "FC02", fileCreateTime)
	assert.Nil(t, err)
	assert.Less(t, uint(0), fileId)
	var (
		id        int
		createdAt time.Time
	)

	record := FC02Record{
		ApplicationNumber:         "2020A045800",
		LoanID:                    int64(6414515),
		LoanNumber:                testutil.GetNullString("2020092800466-3"),
		RPP:                       testutil.GetNullString("1404213000000"),
		EmployeeTypeCode:          testutil.GetNullString("98"),
		AdhesionDate:              testutil.GetNullDate("2020-09-17"),
		LoanCapitalAmount:         testutil.GetNullInt64(150000),
		LoanDurationMonths:        testutil.GetNullString("120"),
		InsuredCapitaRate:         testutil.GetNullFloat64(100.0),
		LoanType:                  testutil.GetNullString("IM"),
		BorrowerStatus:            testutil.GetNullString("E"),
		PremiumCalledRate:         testutil.GetNullFloat64(0.48),
		NormalRate:                testutil.GetNullFloat64(0.48),
		OverPremiumRate:           testutil.GetNullFloat64(0.0),
		CurrencyCode:              testutil.GetNullString("EUR"),
		CFFLoanNumber:             testutil.GetNullString("1113320"),
		NormalDeathRate:           testutil.GetNullFloat64(0.336),
		NormalInvalidityRate:      testutil.GetNullFloat64(0.144),
		OverpremiumDeathRate:      testutil.GetNullFloat64(0.0),
		OverpremiumInvalidityRate: testutil.GetNullFloat64(0.0),
		OngoingAmount:             testutil.GetNullInt64(221230),
	}

	err = addFC02Record(ctx, tx, fileId, &record, fileCreateTime)
	if err != nil {
		assert.Fail(t, "cannot add FC02 record", err)
		return
	}

	err = tx.Commit()
	assert.Nil(t, err)

	var (
		ApplicationNumber         string
		LoanID                    int64
		LoanNumber                sql.NullString
		LoanNumberKey             sql.NullString
		RPP                       sql.NullString
		EmployeeTypeCode          sql.NullString
		AdhesionDate              sql.NullTime
		LoanCapitalAmount         sql.NullInt64
		LoanDurationMonths        sql.NullString
		InsuredCapitaRate         sql.NullFloat64
		LoanType                  sql.NullString
		ProfessionCode            sql.NullString
		CFF                       sql.NullString
		BorrowerStatus            sql.NullString
		PremiumCalledRate         sql.NullFloat64
		NormalRate                sql.NullFloat64
		OverPremiumRate           sql.NullFloat64
		LoanReferenceNumber       sql.NullString
		CurrencyCode              sql.NullString
		CFFLoanNumber             sql.NullString
		ProductCode               sql.NullString
		NormalDeathRate           sql.NullFloat64
		NormalInvalidityRate      sql.NullFloat64
		OverpremiumDeathRate      sql.NullFloat64
		OverpremiumInvalidityRate sql.NullFloat64
		GISAerasCover             sql.NullString
		AerasCapping              sql.NullString
		OngoingAmount             sql.NullInt64
	)
	row := session.QueryRowContext(ctx, "SELECT ID, APPLICATION_NUMBER, LOAN_ID, LOAN_NUMBER, "+
		"LOAN_NUMBER_KEY, RPP, EMPLOYEE_TYPE_CODE, ADHESION_DATE, "+
		"LOAN_CAPITAL_AMOUNT, LOAN_DURATION_MONTHS, INSURED_CAPITA_RATE, LOAN_TYPE, PROFESSION_CODE, CFF, "+
		"BORROWER_STATUS, PREMIUM_CALLED_RATE, NORMAL_RATE, OVERPREMIUM_RATE, LOAN_REF_NUMBER, CURRENCY_CODE, "+
		"CFF_LOAN_NUMBER, PRODUCT_CODE, NORMAL_DEATH_RATE, NORMAL_INVALIDITY_RATE, OVERPREMIUM_DEATH_RATE, "+
		"OVERPREMIUM_INVALIDITY_RATE, GIS_AERAS_COVER, AERAS_CAPPING, ONGOING_AMOUNT, CREATED_AT"+
		" FROM FC02_RECORDS WHERE FILE_ID = $1", fileId)
	err = row.Scan(&id, &ApplicationNumber, &LoanID, &LoanNumber, &LoanNumberKey, &RPP, &EmployeeTypeCode, &AdhesionDate, &LoanCapitalAmount, &LoanDurationMonths, &InsuredCapitaRate, &LoanType, &ProfessionCode, &CFF, &BorrowerStatus, &PremiumCalledRate, &NormalRate, &OverPremiumRate, &LoanReferenceNumber, &CurrencyCode, &CFFLoanNumber, &ProductCode, &NormalDeathRate, &NormalInvalidityRate, &OverpremiumDeathRate, &OverpremiumInvalidityRate, &GISAerasCover, &AerasCapping, &OngoingAmount, &createdAt)
	if err != nil {
		assert.Fail(t, "cannot read FC02 record", err)
		return
	}

	assert.Less(t, 0, id)
	assert.Equal(t, "2020A045800", ApplicationNumber)
	assert.Equal(t, "2020A045800", ApplicationNumber)
	assert.Equal(t, int64(6414515), LoanID)
	assert.True(t, LoanNumber.Valid)
	assert.Equal(t, "2020092800466-3", LoanNumber.String)
	assert.False(t, LoanNumberKey.Valid)
	assert.True(t, RPP.Valid)
	assert.Equal(t, "1404213000000", RPP.String)
	assert.True(t, EmployeeTypeCode.Valid)
	assert.Equal(t, "98", EmployeeTypeCode.String)
	tt, err := time.Parse(util.AltDateLayout, "2020-09-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.True(t, AdhesionDate.Valid)
	assert.Equal(t, tt, AdhesionDate.Time)
	assert.True(t, LoanCapitalAmount.Valid)
	assert.Equal(t, int64(150000), LoanCapitalAmount.Int64)
	assert.True(t, LoanDurationMonths.Valid)
	assert.Equal(t, "120", LoanDurationMonths.String)
	assert.True(t, InsuredCapitaRate.Valid)
	assert.Equal(t, 100.0, InsuredCapitaRate.Float64)
	assert.True(t, LoanType.Valid)
	assert.Equal(t, "IM", LoanType.String)
	assert.False(t, ProfessionCode.Valid)
	assert.False(t, CFF.Valid)
	assert.True(t, BorrowerStatus.Valid)
	assert.Equal(t, "E", BorrowerStatus.String)
	assert.True(t, PremiumCalledRate.Valid)
	assert.Equal(t, 0.48, PremiumCalledRate.Float64)
	assert.True(t, NormalRate.Valid)
	assert.Equal(t, 0.48, NormalRate.Float64)
	assert.True(t, OverPremiumRate.Valid)
	assert.Equal(t, 0.0, OverPremiumRate.Float64)
	assert.False(t, LoanReferenceNumber.Valid)
	assert.True(t, CurrencyCode.Valid)
	assert.Equal(t, "EUR", CurrencyCode.String)
	assert.True(t, CFFLoanNumber.Valid)
	assert.Equal(t, "1113320", CFFLoanNumber.String)
	assert.False(t, ProductCode.Valid)
	assert.True(t, NormalDeathRate.Valid)
	assert.Equal(t, 0.336, NormalDeathRate.Float64)
	assert.True(t, NormalInvalidityRate.Valid)
	assert.Equal(t, 0.144, NormalInvalidityRate.Float64)
	assert.True(t, OverpremiumDeathRate.Valid)
	assert.Equal(t, 0.0, OverpremiumDeathRate.Float64)
	assert.True(t, OverpremiumInvalidityRate.Valid)
	assert.Equal(t, 0.0, OverpremiumInvalidityRate.Float64)
	assert.False(t, GISAerasCover.Valid)
	assert.False(t, AerasCapping.Valid)
	assert.True(t, OngoingAmount.Valid)
	assert.Equal(t, int64(221230), OngoingAmount.Int64)

	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
}
