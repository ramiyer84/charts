package fc21

import (
	"context"
	"database/sql"
	"fmt"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/mrt-shared/encryption"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/testutil"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/stretchr/testify/assert"
	"log"
	"os"
	"testing"
	"time"
)

var (
	cb        *db.ConnectionBuilder
	l         *logger.Logger
	secretKey string
)

func TestMain(m *testing.M) {
	l = logger.Create("db_access_test")

	dat, err := os.ReadFile("../../../secret.key")
	if err != nil {
		log.Fatalf("cannot read AES key from file system: %v", err)
	}

	secretKey = string(dat)

	ctx := context.Background()
	pg, net, host, port := testutil.Init()
	defer func() {
		if err := net.Remove(ctx); err != nil {
			log.Fatalf("failed to remove network: %s", err)
		}
	}()

	defer pg.Terminate(ctx)

	cb = db.NewConnectionBuilder("pgx", host, port, "migrationdb").
		Username("migowner").
		Password("Password1")

	os.Exit(m.Run())
}

func TestParseFC2100(t *testing.T) {
	line, err := parseFC21Content("000001152;PIZAK                         ;M.  ;PIZAK                         ;                         ;1964-01-13;  ;          ;  ;ADH;E;         ;\n")
	if err != nil {
		fmt.Printf("cannot parse F21 content: %v", err)
		t.Fail()
		return
	}
	assert.Equal(t, int64(1152), line.InsuredID)
	assert.True(t, line.InsuredName.Valid)
	assert.Equal(t, "PIZAK", line.InsuredName.String)
	assert.True(t, line.Title.Valid)
	assert.Equal(t, "M.", line.Title.String)
	assert.True(t, line.LastName.Valid)
	assert.Equal(t, "PIZAK", line.LastName.String)
	assert.True(t, line.FirstName.Valid)
	assert.Equal(t, "XXXXXXXXXX", line.FirstName.String)
	tt, err := time.Parse(util.AltDateLayout, "1964-01-13")
	assert.Nil(t, err)
	assert.True(t, line.DateOfBirth.Valid)
	assert.Equal(t, tt, line.DateOfBirth.Time)
	assert.False(t, line.PersonalSituation.Valid)
	assert.False(t, line.SituationDate.Valid)
	assert.False(t, line.ProfessionalSituation.Valid)
	assert.True(t, line.InsuredRoleCode.Valid)
	assert.Equal(t, "ADH", line.InsuredRoleCode.String)
	assert.True(t, line.OriginOfInsured.Valid)
	assert.Equal(t, "E", line.OriginOfInsured.String)
	assert.False(t, line.CustomerID.Valid)
	assert.False(t, line.BesseLastName.Valid)
}

func TestParseFC2101(t *testing.T) {
	line, err := parseFC21Content("000043381;CAMILLE                       ;MME ;CAMILLE                       ;                         ;1975-08-20;  ;          ;90;E  ; ;999999999;\n")
	if err != nil {
		fmt.Printf("cannot parse F21 content: %v", err)
		t.Fail()
		return
	}
	assert.Equal(t, int64(43381), line.InsuredID)
	assert.True(t, line.InsuredName.Valid)
	assert.Equal(t, "CAMILLE", line.InsuredName.String)
	assert.True(t, line.Title.Valid)
	assert.Equal(t, "MME", line.Title.String)
	assert.True(t, line.LastName.Valid)
	assert.Equal(t, "CAMILLE", line.LastName.String)
	assert.True(t, line.FirstName.Valid)
	assert.Equal(t, "XXXXXXXXXX", line.FirstName.String)
	tt, err := time.Parse(util.AltDateLayout, "1975-08-20")
	assert.Nil(t, err)
	assert.True(t, line.DateOfBirth.Valid)
	assert.Equal(t, tt, line.DateOfBirth.Time)
	assert.False(t, line.PersonalSituation.Valid)
	assert.False(t, line.SituationDate.Valid)
	assert.True(t, line.ProfessionalSituation.Valid)
	assert.Equal(t, "90", line.ProfessionalSituation.String)
	assert.True(t, line.InsuredRoleCode.Valid)
	assert.Equal(t, "E", line.InsuredRoleCode.String)
	assert.False(t, line.OriginOfInsured.Valid)
	assert.True(t, line.CustomerID.Valid)
	assert.Equal(t, "999999999", line.CustomerID.String)
	assert.False(t, line.BesseLastName.Valid)
}

func TestAddFC21(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if err != nil {
		fmt.Printf("cannot create DB Client: %v", err)
		t.Fail()
	}

	database := dao.CreateClient(dbClient, l)
	session := database.GetConnection()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)

	err = database.AddBatchIfNecessary(ctx, "202106301150", fileCreateTime)
	assert.Nil(t, err)

	tx, err := database.BeginTransaction(ctx)
	assert.Nil(t, err)
	assert.NotNil(t, tx)

	defer tx.Rollback()

	fileId, err := database.AddFile(ctx, tx, "202106301150", "TEST_FC21", "FC21", fileCreateTime)
	assert.Nil(t, err)
	assert.Less(t, uint(0), fileId)
	var (
		id        int
		createdAt time.Time
	)

	record := FC21Record{
		InsuredID:             int64(43381),
		InsuredName:           testutil.GetNullString("CAMILLE"),
		Title:                 testutil.GetNullString("MME"),
		LastName:              testutil.GetNullString("CAMILLE"),
		DateOfBirth:           testutil.GetNullDate("1975-08-20"),
		ProfessionalSituation: testutil.GetNullString("90"),
		InsuredRoleCode:       testutil.GetNullString("E"),
		CustomerID:            testutil.GetNullString("999999999"),
	}

	enc := encryption.New(secretKey, nil)
	err = addFC21Record(ctx, enc, tx, fileId, &record, fileCreateTime)
	if err != nil {
		assert.Fail(t, "cannot add FC21 record", err)
		return
	}

	err = tx.Commit()
	assert.Nil(t, err)

	var (
		InsuredID             int64
		InsuredName           sql.NullString
		Title                 sql.NullString
		LastName              sql.NullString
		FirstName             sql.NullString
		DateOfBirth           sql.NullTime
		PersonalSituation     sql.NullString
		SituationDate         sql.NullTime
		ProfessionalSituation sql.NullString
		InsuredRoleCode       sql.NullString
		OriginOfInsured       sql.NullString
		CustomerID            sql.NullString
		BesseLastName         sql.NullString
	)

	row := session.QueryRowContext(ctx, "SELECT ID, INSURED_ID, INSURED_NAME, TITLE, LAST_NAME, FIRST_NAME, "+
		"DATE_OF_BIRTH, PERSONAL_SITUATION, SITUATION_DATE, PROFESSIONAL_SITUATION, INSURED_ROLE_CODE, ORIGIN_OF_INSURED, "+
		"CUSTOMER_ID, BESSE_LAST_NAME, CREATED_AT FROM FC21_RECORDS WHERE FILE_ID = $1", fileId)
	err = row.Scan(&id, &InsuredID, &InsuredName, &Title, &LastName, &FirstName, &DateOfBirth, &PersonalSituation,
		&SituationDate, &ProfessionalSituation, &InsuredRoleCode, &OriginOfInsured, &CustomerID, &BesseLastName, &createdAt)
	if err != nil {
		assert.Fail(t, "cannot read FC21 record", err)
		return
	}

	assert.Less(t, 0, id)

	if InsuredName.Valid {
		InsuredName.String, err = enc.Decrypt(InsuredName.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if Title.Valid {
		Title.String, err = enc.Decrypt(Title.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if LastName.Valid {
		LastName.String, err = enc.Decrypt(LastName.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if FirstName.Valid {
		FirstName.String, err = enc.Decrypt(FirstName.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	if BesseLastName.Valid {
		BesseLastName.String, err = enc.Decrypt(BesseLastName.String)
		if !assert.Nil(t, err) {
			return
		}
	}

	assert.Equal(t, int64(43381), InsuredID)
	assert.True(t, InsuredName.Valid)
	assert.Equal(t, "CAMILLE", InsuredName.String)
	assert.True(t, Title.Valid)
	assert.Equal(t, "MME", Title.String)
	assert.True(t, LastName.Valid)
	assert.Equal(t, "CAMILLE", LastName.String)
	assert.False(t, FirstName.Valid)
	tt, err := time.Parse(util.AltDateLayout, "1975-08-20")
	assert.Nil(t, err)
	assert.True(t, DateOfBirth.Valid)
	assert.Equal(t, tt, DateOfBirth.Time)
	assert.False(t, PersonalSituation.Valid)
	assert.False(t, SituationDate.Valid)
	assert.True(t, ProfessionalSituation.Valid)
	assert.Equal(t, "90", ProfessionalSituation.String)
	assert.True(t, InsuredRoleCode.Valid)
	assert.Equal(t, "E", InsuredRoleCode.String)
	assert.False(t, OriginOfInsured.Valid)
	assert.True(t, CustomerID.Valid)
	assert.Equal(t, "999999999", CustomerID.String)
	assert.False(t, BesseLastName.Valid)
	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))

	err = database.CompleteBatchIfPossible(ctx, "202106301150")
	assert.Nil(t, err)
}
