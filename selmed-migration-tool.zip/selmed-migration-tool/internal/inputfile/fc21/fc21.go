package fc21

import (
	"bufio"
	"context"
	"database/sql"
	"github.axa.com/axa-partners-clp/mrt-shared/encryption"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.com/spf13/viper"
	"os"
	"syreclabs.com/go/faker"
	"time"
)

type File struct {
	*inputfile.SourceFile
}

// Source table name: KJDTASS
type FC21Record struct {
	InsuredID             int64          // line[0]  (IDGMAS)
	InsuredName           sql.NullString // line[1]  (LCGMAS) - encrypt, anonymize
	Title                 sql.NullString // line[2]  (LTGMAD) - encrypt, anonymize
	LastName              sql.NullString // line[3]  (LNGMNA) - encrypt, anonymize
	FirstName             sql.NullString // line[4]  (LNGMPA) - encrypt, anonymize
	DateOfBirth           sql.NullTime   // line[5]  (LNGMPA)
	PersonalSituation     sql.NullString // line[6]  (CEGMAS)
	SituationDate         sql.NullTime   // line[7]  (DTGMSA)
	ProfessionalSituation sql.NullString // line[8]  (CDPAS2)
	InsuredRoleCode       sql.NullString // line[9]  (CYASRL)
	OriginOfInsured       sql.NullString // line[10] (CYASOR)
	CustomerID            sql.NullString // line[11] (IDSIEM)
	BesseLastName         sql.NullString // line[12] (LNGMPE) - encrypt, anonymize
}

func (fc File) AsyncProcessFile(ctx context.Context) {
	fc.Process(ctx, fc.ProcessFile)
}

func (fc File) ProcessFile(ctx context.Context) error {
	f, err := os.Open(fc.Filepath)
	if err != nil {
		return err
	}
	defer f.Close()

	addedAt := time.Now().UTC()
	id, err := fc.Db.AddFile(ctx, fc.Tx, fc.BatchID, fc.Filename, "FC21", addedAt)
	if err != nil {
		return err
	}

	r := bufio.NewScanner(f)
	// Skip the first line
	r.Scan()

	count := 0
	added := 0
	for r.Scan() {
		count++
		line := r.Text()
		insuredId, err := util.ReadInt64(util.SubstringBeginning([]rune(line), 9))
		if err != nil {
			fc.Logger.Printf("cannot parse the insuredId: %v", err)
		}

		if len(line) < 220 {
			fc.Logger.Printf("line %d: insured Id '%d' has incorrect line length %d", count, insuredId, len(line))
			continue
		}

		if fc.Range.InsuredIdExists(insuredId) {
			record, err := parseFC21Content(line)
			if err != nil {
				fc.Logger.Printf("cannot parse F21 line %d (%s): %v", count, line, err)
				return err
			}

			err = addFC21Record(ctx, fc.Encryption, fc.Tx, id, record, addedAt)
			if err != nil {
				fc.Logger.Printf("cannot add F19 record to Database from line %d (%s): %v", count, line, err)
				return err
			}
			added++
		}
	}

	err = fc.Db.UpdateFileStatus(ctx, fc.Tx, "IMPORTED", id, time.Now().UTC())
	if err != nil {
		return err
	}

	fc.Logger.Printf("completed processing '%s' file, loaded %d records", fc.Filename, added)
	return nil
}

func parseFC21Content(line string) (*FC21Record, error) {
	data := []rune(line)

	// Insured ID
	n, err := util.ReadInt64(util.SubstringBeginning(data, 9))
	if err != nil {
		return nil, err
	}
	record := FC21Record{
		InsuredID: n,
	}
	// Insured Name
	record.InsuredName = util.ReadNullString(util.Substring(data, 10, 40))
	// Title
	record.Title = util.ReadNullString(util.Substring(data, 41, 45))
	// Last Name
	record.LastName = util.ReadNullString(util.Substring(data, 46, 76))
	// First Name
	record.FirstName = util.ReadNullString(util.Substring(data, 77, 102))
	// Date Of Birth
	record.DateOfBirth, err = util.ReadDB2NullDate(util.Substring(data, 103, 113))
	if err != nil {
		return nil, err
	}
	// Personal Situation
	record.PersonalSituation = util.ReadNullString(util.Substring(data, 114, 116))
	// Situation Date
	record.SituationDate, err = util.ReadDB2NullDate(util.Substring(data, 117, 127))
	if err != nil {
		return nil, err
	}
	// Professional Situation
	record.ProfessionalSituation = util.ReadNullString(util.Substring(data, 128, 130))
	// Insured Role Code
	record.InsuredRoleCode = util.ReadNullString(util.Substring(data, 131, 134))
	// Origin Of Insured
	record.OriginOfInsured = util.ReadNullString(util.Substring(data, 135, 136))
	// Customer ID
	record.CustomerID = util.ReadNullString(util.Substring(data, 137, 146))
	// Besse Last Name
	record.BesseLastName = util.ReadNullString(util.SubstringEnd(data, 147))

	if viper.GetBool("anonymize") {
		if record.InsuredName.Valid {
			record.InsuredName.String = faker.Name().Name()
		}

		if record.Title.Valid {
			record.Title.String = faker.Name().Title()
		}

		if record.LastName.Valid {
			record.LastName.String = faker.Name().LastName()
		}

		if record.FirstName.Valid {
			record.FirstName.String = faker.Name().FirstName()
		}

		if record.BesseLastName.Valid {
			record.BesseLastName.String = faker.Name().LastName()
		}
	}

	if !record.LastName.Valid {
		record.LastName.Valid = true
		record.LastName.String = "XXXXXXXXXX"
	}
	if !record.FirstName.Valid {
		record.FirstName.Valid = true
		record.FirstName.String = "XXXXXXXXXX"
	}

	return &record, nil
}

func addFC21Record(ctx context.Context, enc encryption.Client, tx *sql.Tx, fileId uint, record *FC21Record, addedAt time.Time) error {
	var id uint
	var err error

	if record.InsuredName.Valid {
		record.InsuredName.String, err = enc.Encrypt(record.InsuredName.String)
		if err != nil {
			return err
		}
	}

	if record.Title.Valid {
		record.Title.String, err = enc.Encrypt(record.Title.String)
		if err != nil {
			return err
		}
	}

	if record.LastName.Valid {
		record.LastName.String, err = enc.Encrypt(record.LastName.String)
		if err != nil {
			return err
		}
	}

	if record.FirstName.Valid {
		record.FirstName.String, err = enc.Encrypt(record.FirstName.String)
		if err != nil {
			return err
		}
	}

	err = tx.QueryRowContext(ctx, "INSERT INTO FC21_RECORDS (ID, FILE_ID, INSURED_ID, INSURED_NAME, TITLE, LAST_NAME, "+
		"FIRST_NAME, DATE_OF_BIRTH, PERSONAL_SITUATION, SITUATION_DATE, PROFESSIONAL_SITUATION, INSURED_ROLE_CODE, "+
		"ORIGIN_OF_INSURED, CUSTOMER_ID, BESSE_LAST_NAME, CREATED_AT) VALUES (NEXTVAL('FC21_SEQ'), $1, $2, $3, "+
		"$4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15) RETURNING ID",
		fileId, record.InsuredID, record.InsuredName, record.Title, record.LastName, record.FirstName, record.DateOfBirth,
		record.PersonalSituation, record.SituationDate, record.ProfessionalSituation, record.InsuredRoleCode, record.OriginOfInsured,
		record.CustomerID, record.BesseLastName, addedAt).Scan(&id)

	if err != nil {
		return err
	}

	return nil
}
