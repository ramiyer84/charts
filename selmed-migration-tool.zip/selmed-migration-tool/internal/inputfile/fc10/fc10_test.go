package fc10

import (
	"context"
	"database/sql"
	"fmt"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/testutil"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/stretchr/testify/assert"
	"log"
	"os"
	"testing"
	"time"
)

var (
	cb *db.ConnectionBuilder
	l  *logger.Logger
)

func TestMain(m *testing.M) {
	l = logger.Create("db_access_test")

	ctx := context.Background()
	pg, net, host, port := testutil.Init()
	defer func() {
		if err := net.Remove(ctx); err != nil {
			log.Fatalf("failed to remove network: %s", err)
		}
	}()

	defer pg.Terminate(ctx)

	cb = db.NewConnectionBuilder("pgx", host, port, "migrationdb").
		Username("migowner").
		Password("Password1")

	os.Exit(m.Run())
}

func TestParseFC1000(t *testing.T) {
	line, err := parseFC10Content("2021A016588;006516830;006251020;    ;2021-05-25-17.02.03.208771;1;    ;    ;    ;20220601;        ;        ;")
	if err != nil {
		fmt.Printf("cannot parse F10 content: %v", err)
		t.Fail()
		return
	}
	assert.Equal(t, "2021A016588", line.ApplicationNumber)
	assert.Equal(t, int64(6516830), line.LoanID)
	assert.True(t, line.CoverNumber.Valid)
	assert.Equal(t, int64(6251020), line.CoverNumber.Int64)
	assert.False(t, line.DecisionType.Valid)
	tt, err := time.Parse(util.MacaoDateTimeLayout, "2021-05-25-17.02.03.208771")
	assert.Nil(t, err)
	assert.True(t, line.CreationDate.Valid)
	assert.Equal(t, tt, line.CreationDate.Time)
	assert.True(t, line.DecisionLevel.Valid)
	assert.Equal(t, "1", line.DecisionLevel.String)
	assert.False(t, line.BeneficiaryReasonCode.Valid)
	assert.False(t, line.ReasonCode.Valid)
	assert.False(t, line.SecondReasonCode.Valid)
	assert.True(t, line.AdjournmentDate.Valid)
	assert.Equal(t, "20220601", line.AdjournmentDate.String)
	assert.False(t, line.ReserveDate1.Valid)
	assert.False(t, line.ReserveDate2.Valid)
	assert.False(t, line.MedicalDecisionCode.Valid)
}

func TestParseFC1002(t *testing.T) {
	line, err := parseFC10Content("2020A045800;006412292;006207469;RBEL;2020-10-14-09.10.04.686991;1;    ;    ;    ;        ;        ;        ;\n")
	if err != nil {
		fmt.Printf("cannot parse F10 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "2020A045800", line.ApplicationNumber)
	assert.Equal(t, int64(6412292), line.LoanID)
	assert.True(t, line.CoverNumber.Valid)
	assert.Equal(t, int64(6207469), line.CoverNumber.Int64)
	assert.True(t, line.DecisionType.Valid)
	assert.Equal(t, "RBEL", line.DecisionType.String)
	tt, err := time.Parse(util.MacaoDateTimeLayout, "2020-10-14-09.10.04.686991")
	assert.Nil(t, err)
	assert.True(t, line.CreationDate.Valid)
	assert.Equal(t, tt, line.CreationDate.Time)
	assert.True(t, line.DecisionLevel.Valid)
	assert.Equal(t, "1", line.DecisionLevel.String)
	assert.False(t, line.BeneficiaryReasonCode.Valid)
	assert.False(t, line.ReasonCode.Valid)
	assert.False(t, line.SecondReasonCode.Valid)
	assert.False(t, line.AdjournmentDate.Valid)
	assert.False(t, line.ReserveDate1.Valid)
	assert.False(t, line.ReserveDate2.Valid)
	assert.False(t, line.MedicalDecisionCode.Valid)
}

func TestParseFC1001(t *testing.T) {
	line, err := parseFC10Content("2020A051077;006430252;006213132;AJ05;2020-11-06-16.04.30.249385;1;    ;    ;    ;   00000;        ;        ;")
	if err != nil {
		fmt.Printf("cannot parse F10 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "2020A051077", line.ApplicationNumber)
	assert.Equal(t, int64(6430252), line.LoanID)
	assert.True(t, line.CoverNumber.Valid)
	assert.Equal(t, int64(6213132), line.CoverNumber.Int64)
	assert.True(t, line.DecisionType.Valid)
	assert.Equal(t, "AJ05", line.DecisionType.String)
	tt, err := time.Parse(util.MacaoDateTimeLayout, "2020-11-06-16.04.30.249385")
	assert.Nil(t, err)
	assert.True(t, line.CreationDate.Valid)
	assert.Equal(t, tt, line.CreationDate.Time)
	assert.True(t, line.DecisionLevel.Valid)
	assert.Equal(t, "1", line.DecisionLevel.String)
	assert.False(t, line.BeneficiaryReasonCode.Valid)
	assert.False(t, line.ReasonCode.Valid)
	assert.False(t, line.SecondReasonCode.Valid)
	assert.True(t, line.AdjournmentDate.Valid)
	assert.Equal(t, "00000", line.AdjournmentDate.String)
	assert.False(t, line.ReserveDate1.Valid)
	assert.False(t, line.ReserveDate2.Valid)
	assert.False(t, line.MedicalDecisionCode.Valid)
}

func TestAddFC10(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if err != nil {
		fmt.Printf("cannot create DB Client: %v", err)
		t.Fail()
	}

	database := dao.CreateClient(dbClient, l)
	session := database.GetConnection()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)

	err = database.AddBatchIfNecessary(ctx, "202106301150", fileCreateTime)
	assert.Nil(t, err)

	tx, err := database.BeginTransaction(ctx)
	assert.Nil(t, err)
	assert.NotNil(t, tx)

	defer tx.Rollback()

	fileId, err := database.AddFile(ctx, tx, "202106301150", "TEST_FC10", "FC10", fileCreateTime)
	assert.Nil(t, err)
	assert.Less(t, uint(0), fileId)
	var (
		id        int
		createdAt time.Time
	)

	record := FC10Record{
		ApplicationNumber: "2021A016588",
		LoanID:            int64(6516830),
		CoverNumber:       testutil.GetNullInt64(6251020),
		CreationDate:      testutil.GetNullTimestamp("2021-05-25-17.02.03.208771"),
		DecisionLevel:     testutil.GetNullString("1"),
		AdjournmentDate:   testutil.GetNullString("20220601"),
	}

	err = addFC10Record(ctx, tx, fileId, &record, fileCreateTime)
	if err != nil {
		assert.Fail(t, "cannot add FC10 record", err)
		return
	}

	err = tx.Commit()
	assert.Nil(t, err)

	var (
		ApplicationNumber     string
		LoanID                int64
		CoverNumber           sql.NullInt64
		DecisionType          sql.NullString
		CreationDate          sql.NullTime
		DecisionLevel         sql.NullString
		BeneficiaryReasonCode sql.NullString
		ReasonCode            sql.NullString
		SecondReasonCode      sql.NullString
		AdjournmentDate       sql.NullString
		ReserveDate1          sql.NullString
		ReserveDate2          sql.NullString
		MedicalDecisionCode   sql.NullString
	)
	row := session.QueryRowContext(ctx, "SELECT ID, APPLICATION_NUMBER, LOAN_ID, COVER_NUMBER, DECISION_TYPE, "+
		"CREATION_DATE, DECISION_LEVEL, BENEFICIARY_REASON_CODE, REASON_CODE, SECOND_REASON_CODE, ADJOURNMENT_DATE, "+
		"RESERVE_DATE_1, RESERVE_DATE_2, MEDICAL_DECISION_CODE, CREATED_AT FROM FC10_RECORDS WHERE FILE_ID = $1", fileId)
	err = row.Scan(&id, &ApplicationNumber, &LoanID, &CoverNumber, &DecisionType, &CreationDate, &DecisionLevel,
		&BeneficiaryReasonCode, &ReasonCode, &SecondReasonCode, &AdjournmentDate, &ReserveDate1, &ReserveDate2,
		&MedicalDecisionCode, &createdAt)
	if err != nil {
		assert.Fail(t, "cannot read FC10 record", err)
		return
	}

	assert.Less(t, 0, id)

	assert.Equal(t, "2021A016588", ApplicationNumber)
	assert.Equal(t, int64(6516830), LoanID)
	assert.True(t, CoverNumber.Valid)
	assert.Equal(t, int64(6251020), CoverNumber.Int64)
	assert.False(t, DecisionType.Valid)
	tt, err := time.Parse(util.MacaoDateTimeLayout, "2021-05-25-17.02.03.208771")
	assert.Nil(t, err)
	assert.True(t, CreationDate.Valid)
	assert.Equal(t, tt, CreationDate.Time)
	assert.True(t, DecisionLevel.Valid)
	assert.Equal(t, "1", DecisionLevel.String)
	assert.False(t, BeneficiaryReasonCode.Valid)
	assert.False(t, ReasonCode.Valid)
	assert.False(t, SecondReasonCode.Valid)
	assert.True(t, AdjournmentDate.Valid)
	assert.Equal(t, "20220601", AdjournmentDate.String)
	assert.False(t, ReserveDate1.Valid)
	assert.False(t, ReserveDate2.Valid)
	assert.False(t, MedicalDecisionCode.Valid)
	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
}
