package fc26

import (
	"context"
	"database/sql"
	"fmt"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/mrt-shared/encryption"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/testutil"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/stretchr/testify/assert"
	"log"
	"os"
	"testing"
	"time"
)

var (
	cb        *db.ConnectionBuilder
	l         *logger.Logger
	secretKey string
)

func TestMain(m *testing.M) {
	l = logger.Create("fc26_test")

	dat, err := os.ReadFile("../../../secret.key")
	if err != nil {
		log.Fatalf("cannot read AES key from file system: %v", err)
	}

	secretKey = string(dat)

	ctx := context.Background()
	pg, net, host, port := testutil.Init()
	defer func() {
		if err := net.Remove(ctx); err != nil {
			log.Fatalf("failed to remove network: %s", err)
		}
	}()

	defer pg.Terminate(ctx)

	cb = db.NewConnectionBuilder("pgx", host, port, "migrationdb").
		Username("migowner").
		Password("Password1")

	os.Exit(m.Run())
}

func TestParse00(t *testing.T) {
	line, err := parse("2021A008758;001317077;002036167;000760286;V11;01;            ;         ;          ;Le compte rendu d'hospitalisation d'octobre 2019.                     ")
	if err != nil {
		fmt.Printf("cannot parse FC26 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "2021A008758", line.ApplicationNumber)
	assert.Equal(t, int64(1317077), line.MailEventID)
	assert.Equal(t, int64(2036167), line.LetterID)
	assert.Equal(t, int64(760286), line.ClauseID)
	assert.Equal(t, "V11", line.VariableTypeCode)
	assert.Equal(t, "01", line.VariableOrderNumber)
	assert.False(t, line.FloatValue.Valid)
	assert.False(t, line.IntValue.Valid)
	assert.False(t, line.DateValue.Valid)
	assert.True(t, line.StringValue.Valid)
	assert.Equal(t, "Le compte rendu d'hospitalisation d'octobre 2019.", line.StringValue.String)
}

func TestParse01(t *testing.T) {
	line, err := parse("1999A000013;000000012;000000026;000000021;V11;01;000000003.99;         ;          ;                                                                      ")
	if err != nil {
		fmt.Printf("cannot parse F26 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "1999A000013", line.ApplicationNumber)
	assert.Equal(t, int64(12), line.MailEventID)
	assert.Equal(t, int64(26), line.LetterID)
	assert.Equal(t, int64(21), line.ClauseID)
	assert.Equal(t, "V11", line.VariableTypeCode)
	assert.Equal(t, "01", line.VariableOrderNumber)
	assert.True(t, line.FloatValue.Valid)
	assert.Equal(t, float64(3.99), line.FloatValue.Float64)
	assert.False(t, line.IntValue.Valid)
	assert.False(t, line.DateValue.Valid)
	assert.False(t, line.StringValue.Valid)
}

func TestParse02(t *testing.T) {
	line, err := parse("1999A000013;000000012;000000026;000000021;V11;01;            ;000000235;          ;                                                                      ")
	if err != nil {
		fmt.Printf("cannot parse F26 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "1999A000013", line.ApplicationNumber)
	assert.Equal(t, int64(12), line.MailEventID)
	assert.Equal(t, int64(26), line.LetterID)
	assert.Equal(t, int64(21), line.ClauseID)
	assert.Equal(t, "V11", line.VariableTypeCode)
	assert.Equal(t, "01", line.VariableOrderNumber)
	assert.False(t, line.FloatValue.Valid)
	assert.True(t, line.IntValue.Valid)
	assert.Equal(t, int64(235), line.IntValue.Int64)
	assert.False(t, line.DateValue.Valid)
	assert.False(t, line.StringValue.Valid)
}

func TestParse03(t *testing.T) {
	line, err := parse("1999A000013;000000012;000000026;000000021;V11;01;            ;         ;2006-03-17;                                                                      ")
	if err != nil {
		fmt.Printf("cannot parse F26 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "1999A000013", line.ApplicationNumber)
	assert.Equal(t, int64(12), line.MailEventID)
	assert.Equal(t, int64(26), line.LetterID)
	assert.Equal(t, int64(21), line.ClauseID)
	assert.Equal(t, "V11", line.VariableTypeCode)
	assert.Equal(t, "01", line.VariableOrderNumber)
	assert.False(t, line.FloatValue.Valid)
	assert.False(t, line.IntValue.Valid)
	assert.True(t, line.DateValue.Valid)
	tt, err := time.Parse(util.AltDateLayout, "2006-03-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.Equal(t, tt, line.DateValue.Time)
	assert.False(t, line.StringValue.Valid)
}

func TestAddRecord(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if err != nil {
		fmt.Printf("cannot create DB Client: %v", err)
		t.Fail()
	}

	database := dao.CreateClient(dbClient, l)
	session := database.GetConnection()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)

	err = database.AddBatchIfNecessary(ctx, "202106301150", fileCreateTime)
	assert.Nil(t, err)

	tx, err := database.BeginTransaction(ctx)
	assert.Nil(t, err)
	assert.NotNil(t, tx)

	defer tx.Rollback()

	fileId, err := database.AddFile(ctx, tx, "202106301150", "TEST_FC26", "FC26", fileCreateTime)
	assert.Nil(t, err)
	assert.Less(t, uint(0), fileId)
	var (
		id        int
		createdAt time.Time
	)

	record := FC26Record{
		ApplicationNumber:   "2020A045800",
		MailEventID:         int64(6414515),
		LetterID:            int64(1723),
		ClauseID:            int64(37),
		VariableTypeCode:    "VT1",
		VariableOrderNumber: "01",
		FloatValue:          testutil.GetNullFloat64(3.21),
		IntValue:            testutil.GetNullInt64(150000),
		DateValue:           testutil.GetNullDate("2020-09-17"),
		StringValue:         testutil.GetNullString("Test String"),
	}

	enc := encryption.New(secretKey, nil)
	err = addRecord(ctx, enc, tx, fileId, &record, fileCreateTime)
	if err != nil {
		assert.Fail(t, "cannot add FC26 record", err)
		return
	}

	err = tx.Commit()
	assert.Nil(t, err)

	var (
		ApplicationNumber   string
		MaiEventID          int64
		LetterID            int64
		ClauseID            int64
		VariableTypeCode    string
		VariableOrderNumber string
		FloatValue          sql.NullFloat64
		IntValue            sql.NullInt64
		DateValue           sql.NullTime
		TextValue           sql.NullString
	)
	row := session.QueryRowContext(ctx, `SELECT ID, APPLICATION_NUMBER, MAIL_EVENT_ID, LETTER_ID, CLAUSE_ID,
		VARIABLE_TYPE_CODE, VARIABLE_ORDER_NUMBER, FLOAT_VALUE, INTEGER_VALUE, DATE_VALUE,
		TEXT_VALUE, CREATED_AT
		FROM FC26_RECORDS WHERE FILE_ID = $1`, fileId)
	err = row.Scan(&id, &ApplicationNumber, &MaiEventID, &LetterID, &ClauseID, &VariableTypeCode,
		&VariableOrderNumber, &FloatValue, &IntValue, &DateValue, &TextValue, &createdAt)
	if err != nil {
		assert.Fail(t, "cannot read FC26 record", err)
		return
	}

	assert.Less(t, 0, id)
	assert.Equal(t, "2020A045800", ApplicationNumber)
	assert.Equal(t, int64(6414515), MaiEventID)
	assert.Equal(t, int64(1723), LetterID)
	assert.Equal(t, int64(37), ClauseID)
	assert.Equal(t, "VT1", VariableTypeCode)
	assert.Equal(t, "01", VariableOrderNumber)
	assert.True(t, FloatValue.Valid)
	assert.Equal(t, float64(3.21), FloatValue.Float64)
	assert.True(t, IntValue.Valid)
	assert.Equal(t, int64(150000), IntValue.Int64)
	tt, err := time.Parse(util.AltDateLayout, "2020-09-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.True(t, DateValue.Valid)
	assert.Equal(t, tt, DateValue.Time)
	assert.True(t, TextValue.Valid)
	decrypted, err := enc.Decrypt(TextValue.String)
	if !assert.Nil(t, err) {
		return
	}
	assert.Equal(t, "Test String", decrypted)

	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
}
