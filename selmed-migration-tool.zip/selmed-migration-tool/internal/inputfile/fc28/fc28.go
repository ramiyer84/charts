package fc28

import (
	"bufio"
	"context"
	"database/sql"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"os"
	"strings"
	"time"
)

type File struct {
	*inputfile.SourceFile
}

type FC28Record struct {
	ApplicationNumber           string       // line[0]
	MailEventID                 int64        // line[1]
	LetterID                    int64        // line[2]
	ClauseID                    int64        // line[3]
	SupportingDocumentID        int64        // line[4]
	InsuredID                   int64        // line[5]
	DocumentTypeCode            string       // line[6]
	DocumentStatus              string       // line[7]
	DocumentReceivedDate        sql.NullTime // line[8]
	UserStatusUpdateDate        sql.NullTime // line[9]
	DocumentRequestCreationDate sql.NullTime // line[10]
}

func (fc File) AsyncProcessFile(ctx context.Context) {
	fc.Process(ctx, fc.ProcessFile)
}

func (fc File) ProcessFile(ctx context.Context) error {
	f, err := os.Open(fc.Filepath)
	if err != nil {
		return err
	}
	defer f.Close()

	addedAt := time.Now().UTC()
	id, err := fc.Db.AddFile(ctx, fc.Tx, fc.BatchID, fc.Filename, "FC28", addedAt)
	if err != nil {
		return err
	}

	r := bufio.NewScanner(f)
	// Skip the first line
	r.Scan()

	count := 0
	added := 0
	for r.Scan() {
		count++
		line := r.Text()
		applicationNumber := line[:11]
		if len(line) < 100 {
			fc.Logger.Printf("line %d: application '%s' has incorrect line length %d", count, applicationNumber, len(line))
			continue
		}

		if fc.Range.ApplicationNumberExists(applicationNumber) {
			record, err := parse(line)
			if err != nil {
				applicationNumber := line[:11]
				fc.Logger.Printf("line %d: line length %d, cannot parse FC28 line for application %s (%s): %v", count, len(line), applicationNumber, line, err)
				err = nil
				continue
			}

			err = addRecord(ctx, fc.Tx, id, record, addedAt)
			if err != nil {
				fc.Logger.Printf("cannot add F28 record to Database from line %d (%s): %v", count, line, err)
				return err
			}
			added++
		}
	}

	err = fc.Db.UpdateFileStatus(ctx, fc.Tx, "IMPORTED", id, time.Now().UTC())
	if err != nil {
		return err
	}

	fc.Logger.Printf("completed processing '%s' file: loaded %d records", fc.Filename, added)
	return nil
}

func parse(line string) (*FC28Record, error) {
	var err error

	data := []rune(line)

	// Application Number
	tmp := strings.TrimSpace(util.SubstringBeginning(data, 11))
	record := FC28Record{
		ApplicationNumber: tmp,
	}
	// Mail Event ID
	record.MailEventID, err = util.ReadInt64(util.Substring(data, 12, 21))
	if err != nil {
		return nil, err
	}

	// Letter ID
	record.LetterID, err = util.ReadInt64(util.Substring(data, 22, 31))
	if err != nil {
		return nil, err
	}

	// Clause ID
	record.ClauseID, err = util.ReadInt64(util.Substring(data, 32, 41))
	if err != nil {
		return nil, err
	}

	// Supporting Document ID
	record.SupportingDocumentID, err = util.ReadInt64(util.Substring(data, 42, 51))
	if err != nil {
		return nil, err
	}

	// Supporting Document ID
	record.InsuredID, err = util.ReadInt64(util.Substring(data, 52, 61))
	if err != nil {
		return nil, err
	}

	// Variable Type Code
	record.DocumentTypeCode = util.Substring(data, 62, 65)

	// Variable Order Number
	record.DocumentStatus = util.Substring(data, 66, 67)

	// Document Received Date
	record.DocumentReceivedDate, err = util.ReadDB2NullDate(util.Substring(data, 68, 78))
	if err != nil {
		return nil, err
	}

	// User Status Updated Date
	record.UserStatusUpdateDate, err = util.ReadDB2NullDate(util.Substring(data, 79, 89))
	if err != nil {
		return nil, err
	}

	// User Status Updated Date
	record.DocumentRequestCreationDate, err = util.ReadDB2NullDate(util.SubstringEnd(data, 90))
	if err != nil {
		return nil, err
	}

	return &record, nil
}

func addRecord(ctx context.Context, tx *sql.Tx, fileId uint, record *FC28Record, addedAt time.Time) error {
	var id uint

	err := tx.QueryRowContext(ctx, `INSERT INTO FC28_RECORDS (ID, FILE_ID, APPLICATION_NUMBER, MAIL_EVENT_ID, LETTER_ID, 
		CLAUSE_ID, SUPPORTING_DOCUMENT_ID, INSURED_ID, DOCUMENT_TYPE_CODE, DOCUMENT_STATUS, DOCUMENT_RECEIVED_DATE,
		USER_STATUS_UPDATE_DATE, DOCUMENT_REQUEST_CREATION_DATE, CREATED_AT) VALUES (NEXTVAL('FC28_SEQ'), $1, $2, $3,
		$4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING ID
		`,
		fileId, record.ApplicationNumber, record.MailEventID, record.LetterID, record.ClauseID, record.SupportingDocumentID,
		record.InsuredID, record.DocumentTypeCode, record.DocumentStatus, record.DocumentReceivedDate, record.UserStatusUpdateDate,
		record.DocumentRequestCreationDate, addedAt).Scan(&id)

	if err != nil {
		return err
	}

	return nil
}
