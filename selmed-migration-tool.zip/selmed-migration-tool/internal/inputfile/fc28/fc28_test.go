package fc28

import (
	"context"
	"database/sql"
	"fmt"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/testutil"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/stretchr/testify/assert"
	"log"
	"os"
	"testing"
	"time"
)

var (
	cb *db.ConnectionBuilder
	l  *logger.Logger
)

func TestMain(m *testing.M) {
	l = logger.Create("fc28_test")

	ctx := context.Background()
	pg, net, host, port := testutil.Init()
	defer func() {
		if err := net.Remove(ctx); err != nil {
			log.Fatalf("failed to remove network: %s", err)
		}
	}()

	defer pg.Terminate(ctx)

	cb = db.NewConnectionBuilder("pgx", host, port, "migrationdb").
		Username("migowner").
		Password("Password1")

	os.Exit(m.Run())
}

func TestParse(t *testing.T) {
	line, err := parse("2021A008758;001317077;002036167;000760286;000387295;002629880;P26;R;2021-03-08;2021-03-08;2021-02-17")
	if err != nil {
		fmt.Printf("cannot parse FC28 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "2021A008758", line.ApplicationNumber)
	assert.Equal(t, int64(1317077), line.MailEventID)
	assert.Equal(t, int64(2036167), line.LetterID)
	assert.Equal(t, int64(760286), line.ClauseID)
	assert.Equal(t, int64(387295), line.SupportingDocumentID)
	assert.Equal(t, int64(2629880), line.InsuredID)
	assert.Equal(t, "P26", line.DocumentTypeCode)
	assert.Equal(t, "R", line.DocumentStatus)
	assert.True(t, line.DocumentReceivedDate.Valid)
	tt, err := time.Parse(util.AltDateLayout, "2021-03-08")
	if !assert.Nil(t, err) {
		return
	}
	assert.Equal(t, tt, line.UserStatusUpdateDate.Time)
	assert.True(t, line.UserStatusUpdateDate.Valid)
	tt, err = time.Parse(util.AltDateLayout, "2021-03-08")
	if !assert.Nil(t, err) {
		return
	}
	assert.Equal(t, tt, line.UserStatusUpdateDate.Time)
	assert.True(t, line.DocumentRequestCreationDate.Valid)
	tt, err = time.Parse(util.AltDateLayout, "2021-02-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.Equal(t, tt, line.DocumentRequestCreationDate.Time)
}

func TestAddRecord(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if err != nil {
		fmt.Printf("cannot create DB Client: %v", err)
		t.Fail()
	}

	database := dao.CreateClient(dbClient, l)
	session := database.GetConnection()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)

	err = database.AddBatchIfNecessary(ctx, "202106301150", fileCreateTime)
	assert.Nil(t, err)

	tx, err := database.BeginTransaction(ctx)
	assert.Nil(t, err)
	assert.NotNil(t, tx)

	defer tx.Rollback()

	fileId, err := database.AddFile(ctx, tx, "202106301150", "TEST_FC27", "FC27", fileCreateTime)
	assert.Nil(t, err)
	assert.Less(t, uint(0), fileId)
	var (
		id        int
		createdAt time.Time
	)

	record := FC28Record{
		ApplicationNumber:           "2020A045800",
		MailEventID:                 int64(6414515),
		LetterID:                    int64(1723),
		ClauseID:                    int64(37),
		SupportingDocumentID:        int64(116),
		InsuredID:                   int64(716531),
		DocumentTypeCode:            "VT1",
		DocumentStatus:              "P",
		DocumentReceivedDate:        testutil.GetNullDate("2020-09-17"),
		UserStatusUpdateDate:        testutil.GetNullDate("2020-09-17"),
		DocumentRequestCreationDate: testutil.GetNullDate("2020-08-29"),
	}

	err = addRecord(ctx, tx, fileId, &record, fileCreateTime)
	if err != nil {
		assert.Fail(t, "cannot add FC28 record", err)
		return
	}

	err = tx.Commit()
	assert.Nil(t, err)

	var (
		ApplicationNumber           string
		MaiEventID                  int64
		LetterID                    int64
		ClauseID                    int64
		SupportingDocumentID        int64
		InsuredID                   int64
		DocumentTypeCode            string
		DocumentStatus              string
		DocumentReceivedDate        sql.NullTime
		UserStatusUpdateDate        sql.NullTime
		DocumentRequestCreationDate sql.NullTime
	)
	row := session.QueryRowContext(ctx, `SELECT ID, APPLICATION_NUMBER, MAIL_EVENT_ID, LETTER_ID, CLAUSE_ID,
		SUPPORTING_DOCUMENT_ID, INSURED_ID, DOCUMENT_TYPE_CODE, DOCUMENT_STATUS, DOCUMENT_RECEIVED_DATE,
		USER_STATUS_UPDATE_DATE, DOCUMENT_REQUEST_CREATION_DATE, CREATED_AT
		FROM FC28_RECORDS WHERE FILE_ID = $1`, fileId)
	err = row.Scan(&id, &ApplicationNumber, &MaiEventID, &LetterID, &ClauseID, &SupportingDocumentID, &InsuredID,
		&DocumentTypeCode, &DocumentStatus, &DocumentReceivedDate, &UserStatusUpdateDate, &DocumentRequestCreationDate,
		&createdAt)
	if err != nil {
		assert.Fail(t, "cannot read FC28 record", err)
		return
	}

	assert.Less(t, 0, id)
	assert.Equal(t, "2020A045800", ApplicationNumber)
	assert.Equal(t, int64(6414515), MaiEventID)
	assert.Equal(t, int64(1723), LetterID)
	assert.Equal(t, int64(37), ClauseID)
	assert.Equal(t, int64(116), SupportingDocumentID)
	assert.Equal(t, int64(716531), InsuredID)
	assert.Equal(t, "VT1", DocumentTypeCode)
	assert.Equal(t, "P", DocumentStatus)
	tt, err := time.Parse(util.AltDateLayout, "2020-09-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.True(t, DocumentReceivedDate.Valid)
	assert.Equal(t, tt, DocumentReceivedDate.Time)
	tt, err = time.Parse(util.AltDateLayout, "2020-09-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.True(t, UserStatusUpdateDate.Valid)
	assert.Equal(t, tt, UserStatusUpdateDate.Time)
	tt, err = time.Parse(util.AltDateLayout, "2020-08-29")
	if !assert.Nil(t, err) {
		return
	}
	assert.True(t, DocumentRequestCreationDate.Valid)
	assert.Equal(t, tt, DocumentRequestCreationDate.Time)

	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
}
