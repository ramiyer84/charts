package fc13

import (
	"bufio"
	"context"
	"database/sql"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"log"
	"os"
	"time"
)

type File struct {
	*inputfile.SourceFile
}

type FC13Record struct {
	PartnerID              int64          // line[0]
	PartnerLastUpdatedDate sql.NullTime   // line[1]
	PartnerLegalName       sql.NullString // line[2]
	PartnerName            sql.NullString // line[3]
	PartnerAddress1        sql.NullString // line[4]
	PartnerAddress2        sql.NullString // line[5]
	PartnerAddress3        sql.NullString // line[6]
	PartnerAddress4        sql.NullString // line[7]
	PartnerPostalCode      sql.NullString // line[8]
	PartnerTown            sql.NullString // line[9]
	PartnerCountry         sql.NullString // line[10]
}

func (fc File) AsyncProcessFile(ctx context.Context) {
	fc.Process(ctx, fc.ProcessFile)
}

func (fc File) ProcessFile(ctx context.Context) error {
	f, err := os.Open(fc.Filepath)
	if err != nil {
		return err
	}
	defer f.Close()

	addedAt := time.Now().UTC()
	id, err := fc.Db.AddFile(ctx, fc.Tx, fc.BatchID, fc.Filename, "FC13", addedAt)
	if err != nil {
		return err
	}

	r := bufio.NewScanner(f)
	// Skip the first line
	r.Scan()

	count := 0
	added := 0
	for r.Scan() {
		count++
		line := r.Text()
		partnerID, err := util.ReadInt64(util.SubstringBeginning([]rune(line), 9))
		if err != nil {
			fc.Logger.Printf("cannot parse the partnerId: %v", err)
		}

		if len(line) < 257 {
			fc.Logger.Printf("line %d: partner '%d' has incorrect line length %d", count, partnerID, len(line))
			continue
		}

		if fc.Range.PartnerIdExists(partnerID) {
			record, err := parse(line)
			if err != nil {
				partnerId := line[:11]
				fc.Logger.Printf("line %d: line length %d, cannot parse F13 line for partner %s (%s): %v", count, len(line), partnerId, line, err)
				err = nil
				continue
			}

			err = addRecord(ctx, fc.Tx, id, record, addedAt)
			if err != nil {
				log.Printf("error while processing %v", record)
				fc.Logger.Printf("cannot add F13 record to Database from line %d (%s): %v", count, line, err)
				return err
			}
			added++
		}
	}

	err = fc.Db.UpdateFileStatus(ctx, fc.Tx, "IMPORTED", id, time.Now().UTC())
	if err != nil {
		return err
	}

	fc.Logger.Printf("completed processing '%s' file: loaded %d records", fc.Filename, added)
	return nil
}

func parse(line string) (*FC13Record, error) {
	var err error

	data := []rune(line)

	// Partner ID
	n, err := util.ReadInt64(util.SubstringBeginning(data, 9))
	if err != nil {
		return nil, err
	}
	record := FC13Record{
		PartnerID: n,
	}

	// Partner Last Updated Date
	record.PartnerLastUpdatedDate, err = util.ReadDB2NullDate(util.Substring(data, 10, 20))
	if err != nil {
		return nil, err
	}

	// Partner Legal Name
	record.PartnerLegalName = util.ReadNullString(util.Substring(data, 21, 53))

	// Partner Name
	record.PartnerName = util.ReadNullString(util.Substring(data, 54, 86))
	record.PartnerAddress1 = util.ReadNullString(util.Substring(data, 87, 119))
	record.PartnerAddress2 = util.ReadNullString(util.Substring(data, 120, 152))
	record.PartnerAddress3 = util.ReadNullString(util.Substring(data, 153, 185))
	record.PartnerAddress4 = util.ReadNullString(util.Substring(data, 186, 218))
	record.PartnerPostalCode = util.ReadNullString(util.Substring(data, 219, 224))
	record.PartnerTown = util.ReadNullString(util.Substring(data, 225, 251))
	// String Value
	record.PartnerCountry = util.ReadNullString(util.SubstringEnd(data, 252))

	return &record, nil
}

func addRecord(ctx context.Context, tx *sql.Tx, fileId uint, record *FC13Record, addedAt time.Time) error {
	var id uint

	err := tx.QueryRowContext(ctx, `INSERT INTO FC13_RECORDS (ID, FILE_ID, PARTNER_ID, PARTNER_LAST_UPDATED_DATE, 
		PARTNER_LEGAL_NAME, PARTNER_NAME, PARTNER_ADDRESS_1, PARTNER_ADDRESS_2, PARTNER_ADDRESS_3, PARTNER_ADDRESS_4, 
        PARTNER_POSTAL_CODE, PARTNER_TOWN, PARTNER_COUNTRY, CREATED_AT) VALUES (NEXTVAL('FC13_SEQ'), $1, $2, $3,
		$4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING ID
		`,
		fileId, record.PartnerID, record.PartnerLastUpdatedDate, record.PartnerLegalName, record.PartnerName,
		record.PartnerAddress1, record.PartnerAddress2, record.PartnerAddress3, record.PartnerAddress4,
		record.PartnerPostalCode, record.PartnerTown, record.PartnerCountry, addedAt).Scan(&id)

	if err != nil {
		return err
	}

	return nil
}
