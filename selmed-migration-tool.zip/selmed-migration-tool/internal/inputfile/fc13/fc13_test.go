package fc13

import (
	"context"
	"database/sql"
	"fmt"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/testutil"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/stretchr/testify/assert"
	"log"
	"os"
	"testing"
	"time"
)

const sample = "000095091;2004-02-17;C.E ILE DE FRANCE NORD          ;C.E ILE DE FRANCE NORD          ;FAX 01 34 97 11 52              ;AGENCE DE GARGENVILLE           ;1 AVENUE MADEMOISELLE DOSNE     ;                                ;78440;GARGENVILLE               ;001"

var (
	cb *db.ConnectionBuilder
	l  *logger.Logger
)

func TestMain(m *testing.M) {
	l = logger.Create("fc13_test")

	ctx := context.Background()
	pg, net, host, port := testutil.Init()
	defer func() {
		if err := net.Remove(ctx); err != nil {
			log.Fatalf("failed to remove network: %s", err)
		}
	}()

	defer pg.Terminate(ctx)

	cb = db.NewConnectionBuilder("pgx", host, port, "migrationdb").
		Username("migowner").
		Password("Password1")

	os.Exit(m.Run())
}

func TestParse(t *testing.T) {
	line, err := parse(sample)
	if err != nil {
		fmt.Printf("cannot parse FC13 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, int64(95091), line.PartnerID)
	assert.True(t, line.PartnerLastUpdatedDate.Valid)
	tt, err := time.Parse(util.AltDateLayout, "2004-02-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.Equal(t, tt, line.PartnerLastUpdatedDate.Time)
	assert.True(t, line.PartnerLegalName.Valid)
	assert.Equal(t, "C.E ILE DE FRANCE NORD", line.PartnerLegalName.String)
	assert.True(t, line.PartnerName.Valid)
	assert.Equal(t, "C.E ILE DE FRANCE NORD", line.PartnerName.String)
	assert.True(t, line.PartnerAddress1.Valid)
	assert.Equal(t, "FAX 01 34 97 11 52", line.PartnerAddress1.String)
	assert.True(t, line.PartnerAddress2.Valid)
	assert.Equal(t, "AGENCE DE GARGENVILLE", line.PartnerAddress2.String)
	assert.True(t, line.PartnerAddress3.Valid)
	assert.Equal(t, "1 AVENUE MADEMOISELLE DOSNE", line.PartnerAddress3.String)
	assert.False(t, line.PartnerAddress4.Valid)
	assert.True(t, line.PartnerPostalCode.Valid)
	assert.Equal(t, "78440", line.PartnerPostalCode.String)
	assert.True(t, line.PartnerTown.Valid)
	assert.Equal(t, "GARGENVILLE", line.PartnerTown.String)
	assert.True(t, line.PartnerCountry.Valid)
	assert.Equal(t, "001", line.PartnerCountry.String)
}

func TestAddRecord(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if err != nil {
		fmt.Printf("cannot create DB Client: %v", err)
		t.Fail()
	}

	database := dao.CreateClient(dbClient, l)
	session := database.GetConnection()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)

	err = database.AddBatchIfNecessary(ctx, "202106301150", fileCreateTime)
	assert.Nil(t, err)

	tx, err := database.BeginTransaction(ctx)
	assert.Nil(t, err)
	assert.NotNil(t, tx)

	defer tx.Rollback()

	fileId, err := database.AddFile(ctx, tx, "202106301150", "TEST_FC13", "FC13", fileCreateTime)
	assert.Nil(t, err)
	assert.Less(t, uint(0), fileId)
	var (
		id        int
		createdAt time.Time
	)

	record := FC13Record{
		PartnerID:              int64(6414515),
		PartnerLastUpdatedDate: testutil.GetNullDate("2020-09-17"),
		PartnerLegalName:       testutil.GetNullString("C.E ILE DE FRANCE NORD"),
		PartnerName:            testutil.GetNullString("C.E ILE DE FRANCE NORD"),
		PartnerAddress1:        testutil.GetNullString("FAX 01 34 97 11 52"),
		PartnerAddress2:        testutil.GetNullString("AGENCE DE GARGENVILLE"),
		PartnerAddress3:        testutil.GetNullString("1 AVENUE MADEMOISELLE DOSNE"),
		PartnerPostalCode:      testutil.GetNullString("78440"),
		PartnerTown:            testutil.GetNullString("GARGENVILLE"),
		PartnerCountry:         testutil.GetNullString("001"),
	}

	err = addRecord(ctx, tx, fileId, &record, fileCreateTime)
	if err != nil {
		assert.Fail(t, "cannot add FC13 record", err)
		return
	}

	err = tx.Commit()
	assert.Nil(t, err)

	var (
		PartnerID              int64
		PartnerLastUpdatedDate sql.NullTime
		PartnerLegalName       sql.NullString
		PartnerName            sql.NullString
		PartnerAddress1        sql.NullString
		PartnerAddress2        sql.NullString
		PartnerAddress3        sql.NullString
		PartnerAddress4        sql.NullString
		PartnerPostalCode      sql.NullString
		PartnerTown            sql.NullString
		PartnerCountry         sql.NullString
	)
	row := session.QueryRowContext(ctx, `SELECT ID, PARTNER_ID, PARTNER_LAST_UPDATED_DATE, PARTNER_LEGAL_NAME, PARTNER_NAME,
		PARTNER_ADDRESS_1, PARTNER_ADDRESS_2, PARTNER_ADDRESS_3, PARTNER_ADDRESS_4, PARTNER_POSTAL_CODE, PARTNER_TOWN, 
		PARTNER_COUNTRY, CREATED_AT
		FROM FC13_RECORDS WHERE FILE_ID = $1`, fileId)
	err = row.Scan(&id, &PartnerID, &PartnerLastUpdatedDate, &PartnerLegalName, &PartnerName, &PartnerAddress1,
		&PartnerAddress2, &PartnerAddress3, &PartnerAddress4, &PartnerPostalCode, &PartnerTown, &PartnerCountry, &createdAt)
	if err != nil {
		assert.Fail(t, "cannot read FC13 record", err)
		return
	}

	assert.Less(t, 0, id)
	assert.Equal(t, int64(6414515), PartnerID)
	tt, err := time.Parse(util.AltDateLayout, "2020-09-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.True(t, PartnerLastUpdatedDate.Valid)
	assert.Equal(t, tt, PartnerLastUpdatedDate.Time)
	assert.True(t, PartnerLegalName.Valid)
	assert.Equal(t, "C.E ILE DE FRANCE NORD", PartnerLegalName.String)
	assert.True(t, PartnerName.Valid)
	assert.Equal(t, "C.E ILE DE FRANCE NORD", PartnerName.String)
	assert.True(t, PartnerAddress1.Valid)
	assert.Equal(t, "FAX 01 34 97 11 52", PartnerAddress1.String)
	assert.True(t, PartnerAddress2.Valid)
	assert.Equal(t, "AGENCE DE GARGENVILLE", PartnerAddress2.String)
	assert.True(t, PartnerAddress3.Valid)
	assert.Equal(t, "1 AVENUE MADEMOISELLE DOSNE", PartnerAddress3.String)
	assert.False(t, PartnerAddress4.Valid)
	assert.True(t, PartnerPostalCode.Valid)
	assert.Equal(t, "78440", PartnerPostalCode.String)
	assert.True(t, PartnerTown.Valid)
	assert.Equal(t, "GARGENVILLE", PartnerTown.String)
	assert.True(t, PartnerCountry.Valid)
	assert.Equal(t, "001", PartnerCountry.String)

	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
}
