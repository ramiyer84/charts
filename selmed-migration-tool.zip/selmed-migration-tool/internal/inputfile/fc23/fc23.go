package fc23

import (
	"bufio"
	"context"
	"database/sql"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"os"
	"strings"
	"time"
)

type File struct {
	*inputfile.SourceFile
}

type FC23Record struct {
	ApplicationNumber  string         // line[0]
	MailEventID        int64          // line[1]
	MailEventTypeCode  string         // line[2]
	MailEventDate      sql.NullTime   // line[3]
	RequestStatus      sql.NullString // line[4]
	ShouldBePrintedNow sql.NullString // line[5]
	WasPrinted         sql.NullString // line[6]
	PrintedOn          sql.NullTime   // line[7]
	CourierCode        sql.NullString // line[8]
	ManagementTeamCode sql.NullString // line[9]
	BillingTeamCode    sql.NullString // line[10]
}

func (fc File) AsyncProcessFile(ctx context.Context) {
	fc.Process(ctx, fc.ProcessFile)
}

func (fc File) ProcessFile(ctx context.Context) error {
	f, err := os.Open(fc.Filepath)
	if err != nil {
		return err
	}
	defer f.Close()

	addedAt := time.Now().UTC()
	id, err := fc.Db.AddFile(ctx, fc.Tx, fc.BatchID, fc.Filename, "FC23", addedAt)
	if err != nil {
		return err
	}

	r := bufio.NewScanner(f)
	// Skip the first line
	r.Scan()

	count := 0
	added := 0
	for r.Scan() {
		count++
		line := r.Text()
		applicationNumber := line[:11]
		if len(line) < 74 {
			fc.Logger.Printf("line %d: application '%s' has incorrect line length %d", count, applicationNumber, len(line))
			continue
		}

		if fc.Range.ApplicationNumberExists(applicationNumber) {
			record, err := parse(line)
			if err != nil {
				applicationNumber := line[:11]
				fc.Logger.Printf("line %d: line length %d, cannot parse FC23 line for application %s (%s): %v", count, len(line), applicationNumber, line, err)
				err = nil
				continue
			}

			err = addRecord(ctx, fc.Tx, id, record, addedAt)
			if err != nil {
				fc.Logger.Printf("cannot add FC23 record to Database from line %d (%s): %v", count, line, err)
				return err
			}
			added++
		}
	}

	err = fc.Db.UpdateFileStatus(ctx, fc.Tx, "IMPORTED", id, time.Now().UTC())
	if err != nil {
		return err
	}

	fc.Logger.Printf("completed processing '%s' file: loaded %d records", fc.Filename, added)
	return nil
}

func parse(line string) (*FC23Record, error) {
	var err error

	data := []rune(line)

	// Application Number
	tmp := strings.TrimSpace(util.SubstringBeginning(data, 11))
	record := FC23Record{
		ApplicationNumber: tmp,
	}
	// Mail Event ID
	record.MailEventID, err = util.ReadInt64(util.Substring(data, 12, 21))
	if err != nil {
		return nil, err
	}

	// Mail Event Type Code
	record.MailEventTypeCode = util.Substring(data, 22, 25)

	// Mail Event Date
	record.MailEventDate, err = util.ReadDB2NullDate(util.Substring(data, 26, 36))
	if err != nil {
		return nil, err
	}

	// Request Status
	record.RequestStatus = util.ReadNullString(util.Substring(data, 37, 47))

	// Should be printed now
	record.ShouldBePrintedNow = util.ReadNullString(util.Substring(data, 48, 49))

	// Was Letter Printed
	record.WasPrinted = util.ReadNullString(util.Substring(data, 50, 51))

	// Letter Printed On
	record.PrintedOn, err = util.ReadDB2NullDate(util.Substring(data, 52, 62))
	if err != nil {
		return nil, err
	}

	// Variable Order Number
	record.CourierCode = util.ReadNullString(util.Substring(data, 63, 64))

	// Variable Order Number
	record.ManagementTeamCode = util.ReadNullString(util.Substring(data, 65, 69))

	// String Value
	record.BillingTeamCode = util.ReadNullString(util.SubstringEnd(data, 70))

	return &record, nil
}

func addRecord(ctx context.Context, tx *sql.Tx, fileId uint, record *FC23Record, addedAt time.Time) error {
	var id uint

	err := tx.QueryRowContext(ctx, `INSERT INTO FC23_RECORDS (ID, FILE_ID, APPLICATION_NUMBER, MAIL_EVENT_ID, MAIL_CODE_TYPE, 
		MAIL_EVENT_DATE, STATUS_REQUEST, SHOULD_PRINT_NOW, WAS_PRINTED, MAIL_PRINTED_DATE, COURIER_CODE,
		MGMT_TEAM_CODE, BILLING_TEAM_CODE, CREATED_AT) VALUES (NEXTVAL('FC23_SEQ'), $1, $2, $3,
		$4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING ID
		`,
		fileId, record.ApplicationNumber, record.MailEventID, record.MailEventTypeCode, record.MailEventDate, record.RequestStatus,
		record.ShouldBePrintedNow, record.WasPrinted, record.PrintedOn, record.CourierCode, record.ManagementTeamCode,
		record.BillingTeamCode, addedAt).Scan(&id)

	if err != nil {
		return err
	}

	return nil
}
