package fc23

import (
	"context"
	"database/sql"
	"fmt"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/testutil"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/stretchr/testify/assert"
	"log"
	"os"
	"testing"
	"time"
)

var (
	cb *db.ConnectionBuilder
	l  *logger.Logger
)

func TestMain(m *testing.M) {
	l = logger.Create("fc23_test")

	ctx := context.Background()
	pg, net, host, port := testutil.Init()
	defer func() {
		if err := net.Remove(ctx); err != nil {
			log.Fatalf("failed to remove network: %s", err)
		}
	}()

	defer pg.Terminate(ctx)

	cb = db.NewConnectionBuilder("pgx", host, port, "migrationdb").
		Username("migowner").
		Password("Password1")

	os.Exit(m.Run())
}

func TestParse(t *testing.T) {
	line, err := parse("2021A016884;001319144;DRC;2021-05-27;SANS OBJET;O;O;2021-05-27;N;2872;8233")
	if err != nil {
		fmt.Printf("cannot parse FC23 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "2021A016884", line.ApplicationNumber)
	assert.Equal(t, int64(1319144), line.MailEventID)
	assert.Equal(t, "DRC", line.MailEventTypeCode)
	tt, err := time.Parse(util.AltDateLayout, "2021-05-27")
	if !assert.Nil(t, err) {
		return
	}
	assert.True(t, line.MailEventDate.Valid)
	assert.Equal(t, tt, line.MailEventDate.Time)
	assert.True(t, line.RequestStatus.Valid)
	assert.Equal(t, "SANS OBJET", line.RequestStatus.String)
	assert.True(t, line.ShouldBePrintedNow.Valid)
	assert.Equal(t, "O", line.ShouldBePrintedNow.String)
	assert.True(t, line.WasPrinted.Valid)
	assert.Equal(t, "O", line.WasPrinted.String)
	tt, err = time.Parse(util.AltDateLayout, "2021-05-27")
	if !assert.Nil(t, err) {
		return
	}
	assert.True(t, line.PrintedOn.Valid)
	assert.Equal(t, tt, line.PrintedOn.Time)
	assert.True(t, line.CourierCode.Valid)
	assert.Equal(t, "N", line.CourierCode.String)
	assert.True(t, line.ManagementTeamCode.Valid)
	assert.Equal(t, "2872", line.ManagementTeamCode.String)
	assert.True(t, line.BillingTeamCode.Valid)
	assert.Equal(t, "8233", line.BillingTeamCode.String)
}

func TestAddRecord(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if err != nil {
		fmt.Printf("cannot create DB Client: %v", err)
		t.Fail()
	}

	database := dao.CreateClient(dbClient, l)
	session := database.GetConnection()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)

	err = database.AddBatchIfNecessary(ctx, "202106301150", fileCreateTime)
	assert.Nil(t, err)

	tx, err := database.BeginTransaction(ctx)
	assert.Nil(t, err)
	assert.NotNil(t, tx)

	defer tx.Rollback()

	fileId, err := database.AddFile(ctx, tx, "202106301150", "TEST_FC23", "FC23", fileCreateTime)
	assert.Nil(t, err)
	assert.Less(t, uint(0), fileId)
	var (
		id        int
		createdAt time.Time
	)

	record := FC23Record{
		ApplicationNumber:  "2020A045800",
		MailEventID:        int64(6414515),
		MailEventTypeCode:  "DRV",
		MailEventDate:      testutil.GetNullDate("2020-09-17"),
		RequestStatus:      testutil.GetNullString("OK"),
		ShouldBePrintedNow: testutil.GetNullString("O"),
		WasPrinted:         testutil.GetNullString("O"),
		PrintedOn:          testutil.GetNullDate("2020-09-17"),
		CourierCode:        testutil.GetNullString("N"),
		ManagementTeamCode: testutil.GetNullString("8222"),
		BillingTeamCode:    testutil.GetNullString("8223"),
	}

	err = addRecord(ctx, tx, fileId, &record, fileCreateTime)
	if err != nil {
		assert.Fail(t, "cannot add FC23 record", err)
		return
	}

	err = tx.Commit()
	assert.Nil(t, err)

	var (
		ApplicationNumber  string
		MaiEventID         int64
		MailCodeType       string
		MailEventDate      sql.NullTime
		StatusRequest      sql.NullString
		ShouldPrintNow     sql.NullString
		WasPrinted         sql.NullString
		PrintedOn          sql.NullTime
		CourierCode        sql.NullString
		ManagementTeamCode sql.NullString
		BillingTeamCode    sql.NullString
	)
	row := session.QueryRowContext(ctx, `SELECT ID, APPLICATION_NUMBER, MAIL_EVENT_ID, MAIL_CODE_TYPE, MAIL_EVENT_DATE,
		STATUS_REQUEST, SHOULD_PRINT_NOW, WAS_PRINTED, MAIL_PRINTED_DATE, COURIER_CODE, MGMT_TEAM_CODE,
		BILLING_TEAM_CODE, CREATED_AT
		FROM FC23_RECORDS WHERE FILE_ID = $1`, fileId)
	err = row.Scan(&id, &ApplicationNumber, &MaiEventID, &MailCodeType, &MailEventDate, &StatusRequest, &ShouldPrintNow,
		&WasPrinted, &PrintedOn, &CourierCode, &ManagementTeamCode, &BillingTeamCode, &createdAt)
	if err != nil {
		assert.Fail(t, "cannot read FC23 record", err)
		return
	}

	assert.Less(t, 0, id)
	assert.Equal(t, "2020A045800", ApplicationNumber)
	assert.Equal(t, int64(6414515), MaiEventID)
	assert.Equal(t, "DRV", MailCodeType)
	tt, err := time.Parse(util.AltDateLayout, "2020-09-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.True(t, MailEventDate.Valid)
	assert.Equal(t, tt, MailEventDate.Time)
	assert.True(t, StatusRequest.Valid)
	assert.Equal(t, "OK", StatusRequest.String)
	assert.True(t, ShouldPrintNow.Valid)
	assert.Equal(t, "O", ShouldPrintNow.String)
	assert.True(t, WasPrinted.Valid)
	assert.Equal(t, "O", WasPrinted.String)
	tt, err = time.Parse(util.AltDateLayout, "2020-09-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.True(t, PrintedOn.Valid)
	assert.Equal(t, tt, PrintedOn.Time)
	assert.True(t, CourierCode.Valid)
	assert.Equal(t, "N", CourierCode.String)
	assert.True(t, ManagementTeamCode.Valid)
	assert.Equal(t, "8222", ManagementTeamCode.String)
	assert.True(t, BillingTeamCode.Valid)
	assert.Equal(t, "8223", BillingTeamCode.String)

	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
}
