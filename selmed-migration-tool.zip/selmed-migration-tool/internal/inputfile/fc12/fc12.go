package fc12

import (
	"bufio"
	"context"
	"database/sql"
	"github.axa.com/axa-partners-clp/mrt-shared/encryption"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"os"
	"strings"
	"time"
)

type File struct {
	*inputfile.SourceFile
}

type FC12Record struct {
	ApplicationNumber    string          // line[0]
	MailEventID          int64           // line[1]
	LetterID             int64           // line[2]
	ClauseID             int64           // line[3]
	SupportingDocumentID int64           // line[4]
	VariableTypeCode     string          // line[5]
	VariableOrderNumber  string          // line[6]
	FloatValue           sql.NullFloat64 // line[7]
	IntValue             sql.NullInt64   // line[8]
	DateValue            sql.NullTime    // line[9]
	StringValue          sql.NullString  // line[10]
}

func (fc File) AsyncProcessFile(ctx context.Context) {
	fc.Process(ctx, fc.ProcessFile)
}

func (fc File) ProcessFile(ctx context.Context) error {
	f, err := os.Open(fc.Filepath)
	if err != nil {
		return err
	}
	defer f.Close()

	addedAt := time.Now().UTC()
	id, err := fc.Db.AddFile(ctx, fc.Tx, fc.BatchID, fc.Filename, "FC12", addedAt)
	if err != nil {
		return err
	}

	r := bufio.NewScanner(f)
	// Skip the first line
	r.Scan()

	count := 0
	added := 0
	for r.Scan() {
		count++
		line := r.Text()
		applicationNumber := line[:11]
		if len(line) < 164 {
			fc.Logger.Printf("line %d: application '%s' has incorrect line length %d", count, applicationNumber, len(line))
			continue
		}

		if fc.Range.ApplicationNumberExists(applicationNumber) {
			record, err := parseFC12Content(line)
			if err != nil {
				applicationNumber := line[:11]
				fc.Logger.Printf("line %d: line length %d, cannot parse F12 line for application %s (%s): %v", count, len(line), applicationNumber, line, err)
				err = nil
				continue
			}

			err = addFC12Record(ctx, fc.Encryption, fc.Tx, id, record, addedAt)
			if err != nil {
				fc.Logger.Printf("cannot add F12 record to Database from line %d (%s): %v", count, line, err)
				return err
			}
			added++
		}
	}

	err = fc.Db.UpdateFileStatus(ctx, fc.Tx, "IMPORTED", id, time.Now().UTC())
	if err != nil {
		return err
	}

	fc.Logger.Printf("completed processing '%s' file: loaded %d records", fc.Filename, added)
	return nil
}

func parseFC12Content(line string) (*FC12Record, error) {
	var err error

	data := []rune(line)

	// Application Number
	tmp := strings.TrimSpace(util.SubstringBeginning(data, 11))
	record := FC12Record{
		ApplicationNumber: tmp,
	}
	// Mail Event ID
	record.MailEventID, err = util.ReadInt64(util.Substring(data, 12, 21))
	if err != nil {
		return nil, err
	}

	// Letter ID
	record.LetterID, err = util.ReadInt64(util.Substring(data, 22, 31))
	if err != nil {
		return nil, err
	}

	// Clause ID
	record.ClauseID, err = util.ReadInt64(util.Substring(data, 32, 41))
	if err != nil {
		return nil, err
	}

	// Supporting Document ID
	record.SupportingDocumentID, err = util.ReadInt64(util.Substring(data, 42, 51))
	if err != nil {
		return nil, err
	}

	// Variable Type Code
	record.VariableTypeCode = strings.TrimSpace(util.Substring(data, 52, 55))
	// Variable Order Number
	record.VariableOrderNumber = strings.TrimSpace(util.Substring(data, 56, 58))
	// Float Value
	record.FloatValue, err = util.ReadNullFloat64(util.Substring(data, 59, 71))
	if err != nil {
		return nil, err
	}

	// Integer Value
	record.IntValue, err = util.ReadNullInt64(util.Substring(data, 72, 81))
	if err != nil {
		return nil, err
	}

	// Date Value
	record.DateValue, err = util.ReadDB2NullDate(util.Substring(data, 82, 92))
	if err != nil {
		return nil, err
	}
	// String Value
	record.StringValue = util.ReadNullString(util.SubstringEnd(data, 93))

	return &record, nil
}

func addFC12Record(ctx context.Context, enc encryption.Client, tx *sql.Tx, fileId uint, record *FC12Record, addedAt time.Time) error {
	var id uint
	var err error

	if record.StringValue.Valid {
		record.StringValue.String, err = enc.Encrypt(record.StringValue.String)
		if err != nil {
			return err
		}
	}

	err = tx.QueryRowContext(ctx, `INSERT INTO FC12_RECORDS (ID, FILE_ID, APPLICATION_NUMBER, MAIL_EVENT_ID, LETTER_ID, 
		CLAUSE_ID, SUPPORTING_DOCUMENT_ID, VARIABLE_TYPE_CODE, VARIABLE_ORDER_NUMBER, FLOAT_VALUE, INTEGER_VALUE,
		DATE_VALUE, TEXT_VALUE, CREATED_AT) VALUES (NEXTVAL('FC12_SEQ'), $1, $2, $3,
		$4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING ID
		`,
		fileId, record.ApplicationNumber, record.MailEventID, record.LetterID, record.ClauseID, record.SupportingDocumentID,
		record.VariableTypeCode, record.VariableOrderNumber, record.FloatValue, record.IntValue, record.DateValue,
		record.StringValue, addedAt).Scan(&id)

	if err != nil {
		return err
	}

	return nil
}
