package fc12

import (
	"context"
	"database/sql"
	"fmt"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/mrt-shared/encryption"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/testutil"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/stretchr/testify/assert"
	"log"
	"os"
	"testing"
	"time"
)

var (
	cb        *db.ConnectionBuilder
	l         *logger.Logger
	secretKey string
)

func TestMain(m *testing.M) {
	l = logger.Create("fc12_test")

	dat, err := os.ReadFile("../../../secret.key")
	if err != nil {
		log.Fatalf("cannot read AES key from file system: %v", err)
	}

	secretKey = string(dat)

	ctx := context.Background()
	pg, net, host, port := testutil.Init()
	defer func() {
		if err := net.Remove(ctx); err != nil {
			log.Fatalf("failed to remove network: %s", err)
		}
	}()

	defer pg.Terminate(ctx)

	cb = db.NewConnectionBuilder("pgx", host, port, "migrationdb").
		Username("migowner").
		Password("Password1")

	os.Exit(m.Run())
}

func TestParse00(t *testing.T) {
	line, err := parseFC12Content("1999A000013;000000012;000000026;000000021;000000019;V11;01;            ;         ;          ;LE QUESTIONNAIRE MEDICAL CONFIDENTIEL CI-JOINT COMPLETE A TOUS LES    ")
	if err != nil {
		fmt.Printf("cannot parse FC12 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "1999A000013", line.ApplicationNumber)
	assert.Equal(t, int64(12), line.MailEventID)
	assert.Equal(t, int64(26), line.LetterID)
	assert.Equal(t, int64(21), line.ClauseID)
	assert.Equal(t, int64(19), line.SupportingDocumentID)
	assert.Equal(t, "V11", line.VariableTypeCode)
	assert.Equal(t, "01", line.VariableOrderNumber)
	assert.False(t, line.FloatValue.Valid)
	assert.False(t, line.IntValue.Valid)
	assert.False(t, line.DateValue.Valid)
	assert.True(t, line.StringValue.Valid)
	assert.Equal(t, "LE QUESTIONNAIRE MEDICAL CONFIDENTIEL CI-JOINT COMPLETE A TOUS LES", line.StringValue.String)
}

func TestParse01(t *testing.T) {
	line, err := parseFC12Content("1999A000013;000000012;000000026;000000021;000000019;V11;01;        3.99;         ;          ;                                                                      ")
	if err != nil {
		fmt.Printf("cannot parse FC12 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "1999A000013", line.ApplicationNumber)
	assert.Equal(t, int64(12), line.MailEventID)
	assert.Equal(t, int64(26), line.LetterID)
	assert.Equal(t, int64(21), line.ClauseID)
	assert.Equal(t, int64(19), line.SupportingDocumentID)
	assert.Equal(t, "V11", line.VariableTypeCode)
	assert.Equal(t, "01", line.VariableOrderNumber)
	assert.True(t, line.FloatValue.Valid)
	assert.Equal(t, float64(3.99), line.FloatValue.Float64)
	assert.False(t, line.IntValue.Valid)
	assert.False(t, line.DateValue.Valid)
	assert.False(t, line.StringValue.Valid)
}

func TestParse02(t *testing.T) {
	line, err := parseFC12Content("1999A000013;000000012;000000026;000000021;000000019;V11;01;            ;000000122;          ;                                                                      ")
	if err != nil {
		fmt.Printf("cannot parse FC12 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "1999A000013", line.ApplicationNumber)
	assert.Equal(t, int64(12), line.MailEventID)
	assert.Equal(t, int64(26), line.LetterID)
	assert.Equal(t, int64(21), line.ClauseID)
	assert.Equal(t, int64(19), line.SupportingDocumentID)
	assert.Equal(t, "V11", line.VariableTypeCode)
	assert.Equal(t, "01", line.VariableOrderNumber)
	assert.False(t, line.FloatValue.Valid)
	assert.True(t, line.IntValue.Valid)
	assert.Equal(t, int64(122), line.IntValue.Int64)
	assert.False(t, line.DateValue.Valid)
	assert.False(t, line.StringValue.Valid)
}

func TestParse03(t *testing.T) {
	line, err := parseFC12Content("1999A000013;000000012;000000026;000000021;000000019;V11;01;            ;         ;2006-03-17;                                                                      ")
	if err != nil {
		fmt.Printf("cannot parse FC12 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "1999A000013", line.ApplicationNumber)
	assert.Equal(t, int64(12), line.MailEventID)
	assert.Equal(t, int64(26), line.LetterID)
	assert.Equal(t, int64(21), line.ClauseID)
	assert.Equal(t, int64(19), line.SupportingDocumentID)
	assert.Equal(t, "V11", line.VariableTypeCode)
	assert.Equal(t, "01", line.VariableOrderNumber)
	assert.False(t, line.FloatValue.Valid)
	assert.False(t, line.IntValue.Valid)
	assert.True(t, line.DateValue.Valid)
	tt, err := time.Parse(util.AltDateLayout, "2006-03-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.Equal(t, tt, line.DateValue.Time)
	assert.False(t, line.StringValue.Valid)
}

func TestAddRecord(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if err != nil {
		fmt.Printf("cannot create DB Client: %v", err)
		t.Fail()
	}

	database := dao.CreateClient(dbClient, l)
	session := database.GetConnection()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)

	err = database.AddBatchIfNecessary(ctx, "202106301150", fileCreateTime)
	assert.Nil(t, err)

	tx, err := database.BeginTransaction(ctx)
	assert.Nil(t, err)
	assert.NotNil(t, tx)

	defer tx.Rollback()

	fileId, err := database.AddFile(ctx, tx, "202106301150", "TEST_FC12", "FC12", fileCreateTime)
	assert.Nil(t, err)
	assert.Less(t, uint(0), fileId)
	var (
		id        int
		createdAt time.Time
	)

	record := FC12Record{
		ApplicationNumber:    "2020A045800",
		MailEventID:          int64(6414515),
		LetterID:             int64(1723),
		ClauseID:             int64(37),
		SupportingDocumentID: int64(177234),
		VariableTypeCode:     "VT1",
		VariableOrderNumber:  "01",
		FloatValue:           testutil.GetNullFloat64(3.21),
		IntValue:             testutil.GetNullInt64(150000),
		DateValue:            testutil.GetNullDate("2020-09-17"),
		StringValue:          testutil.GetNullString("Test String"),
	}

	enc := encryption.New(secretKey, nil)
	err = addFC12Record(ctx, enc, tx, fileId, &record, fileCreateTime)
	if err != nil {
		assert.Fail(t, "cannot add FC12 record", err)
		return
	}

	err = tx.Commit()
	assert.Nil(t, err)

	var (
		ApplicationNumber    string
		MaiEventID           int64
		LetterID             int64
		ClauseID             int64
		SupportingDocumentID int64
		VariableTypeCode     string
		VariableOrderNumber  string
		FloatValue           sql.NullFloat64
		IntValue             sql.NullInt64
		DateValue            sql.NullTime
		TextValue            sql.NullString
	)
	row := session.QueryRowContext(ctx, `SELECT ID, APPLICATION_NUMBER, MAIL_EVENT_ID, LETTER_ID, CLAUSE_ID,
		SUPPORTING_DOCUMENT_ID, VARIABLE_TYPE_CODE, VARIABLE_ORDER_NUMBER, FLOAT_VALUE, INTEGER_VALUE, DATE_VALUE,
		TEXT_VALUE, CREATED_AT
		FROM FC12_RECORDS WHERE FILE_ID = $1`, fileId)
	err = row.Scan(&id, &ApplicationNumber, &MaiEventID, &LetterID, &ClauseID, &SupportingDocumentID, &VariableTypeCode,
		&VariableOrderNumber, &FloatValue, &IntValue, &DateValue, &TextValue, &createdAt)
	if err != nil {
		assert.Fail(t, "cannot read FC12 record", err)
		return
	}

	assert.Less(t, 0, id)
	assert.Equal(t, "2020A045800", ApplicationNumber)
	assert.Equal(t, int64(6414515), MaiEventID)
	assert.Equal(t, int64(1723), LetterID)
	assert.Equal(t, int64(37), ClauseID)
	assert.Equal(t, int64(177234), SupportingDocumentID)
	assert.Equal(t, "VT1", VariableTypeCode)
	assert.Equal(t, "01", VariableOrderNumber)
	assert.True(t, FloatValue.Valid)
	assert.Equal(t, float64(3.21), FloatValue.Float64)
	assert.True(t, IntValue.Valid)
	assert.Equal(t, int64(150000), IntValue.Int64)
	tt, err := time.Parse(util.AltDateLayout, "2020-09-17")
	if !assert.Nil(t, err) {
		return
	}
	assert.True(t, DateValue.Valid)
	assert.Equal(t, tt, DateValue.Time)
	assert.True(t, TextValue.Valid)
	decrypted, err := enc.Decrypt(TextValue.String)
	if !assert.Nil(t, err) {
		return
	}
	assert.Equal(t, "Test String", decrypted)

	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
}
