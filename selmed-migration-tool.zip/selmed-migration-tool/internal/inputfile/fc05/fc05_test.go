package fc05

import (
	"context"
	"database/sql"
	"fmt"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/testutil"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/stretchr/testify/assert"
	"log"
	"os"
	"testing"
	"time"
)

var (
	cb *db.ConnectionBuilder
	l  *logger.Logger
)

func TestMain(m *testing.M) {
	l = logger.Create("db_access_test")

	ctx := context.Background()
	pg, net, host, port := testutil.Init()
	defer func() {
		if err := net.Remove(ctx); err != nil {
			log.Fatalf("failed to remove network: %s", err)
		}
	}()

	defer pg.Terminate(ctx)

	cb = db.NewConnectionBuilder("pgx", host, port, "migrationdb").
		Username("migowner").
		Password("Password1")

	os.Exit(m.Run())
}

func TestParseFC0500(t *testing.T) {
	line, err := parseFC05Content("2020A045800;006414515;006208221;064;INVALIDITE PERMANENTE                             ;N;        0; ;   ;N;")
	if err != nil {
		fmt.Printf("cannot parse F05 content: %v", err)
		t.Fail()
		return
	}
	assert.Equal(t, "2020A045800", line.ApplicationNumber)
	assert.Equal(t, int64(6414515), line.LoanID)
	assert.True(t, line.CoverNumber.Valid)
	assert.Equal(t, int64(6208221), line.CoverNumber.Int64)
	assert.True(t, line.CoverType.Valid)
	assert.Equal(t, "064", line.CoverType.String)
	assert.True(t, line.CoverLabel.Valid)
	assert.Equal(t, "INVALIDITE PERMANENTE", line.CoverLabel.String)
	assert.True(t, line.OptionalCoverCode.Valid)
	assert.Equal(t, "N", line.OptionalCoverCode.String)
	assert.True(t, line.InsuredAmount.Valid)
	assert.Equal(t, int64(0), line.InsuredAmount.Int64)
	assert.False(t, line.DoubleEffectCode.Valid)
	assert.False(t, line.WaitingPeriodDays.Valid)
	assert.True(t, line.Submitted.Valid)
	assert.Equal(t, "N", line.Submitted.String)
	assert.False(t, line.CurrencyCode.Valid)
}

func TestParseFC0501(t *testing.T) {
	line, err := parseFC05Content("2020A045800;006414515;006208222;310;DECES                                             ;O;   150000; ;   ;O;EUR")
	if err != nil {
		fmt.Printf("cannot parse F05 content: %v", err)
		t.Fail()
		return
	}
	assert.Equal(t, "2020A045800", line.ApplicationNumber)
	assert.Equal(t, int64(6414515), line.LoanID)
	assert.True(t, line.CoverNumber.Valid)
	assert.Equal(t, int64(6208222), line.CoverNumber.Int64)
	assert.True(t, line.CoverType.Valid)
	assert.Equal(t, "310", line.CoverType.String)
	assert.True(t, line.CoverLabel.Valid)
	assert.Equal(t, "DECES", line.CoverLabel.String)
	assert.True(t, line.OptionalCoverCode.Valid)
	assert.Equal(t, "O", line.OptionalCoverCode.String)
	assert.True(t, line.InsuredAmount.Valid)
	assert.Equal(t, int64(150000), line.InsuredAmount.Int64)
	assert.False(t, line.DoubleEffectCode.Valid)
	assert.False(t, line.WaitingPeriodDays.Valid)
	assert.True(t, line.Submitted.Valid)
	assert.Equal(t, "O", line.Submitted.String)
	assert.True(t, line.CurrencyCode.Valid)
	assert.Equal(t, "EUR", line.CurrencyCode.String)
}
func TestAddFC05(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if err != nil {
		fmt.Printf("cannot create DB Client: %v", err)
		t.Fail()
	}

	database := dao.CreateClient(dbClient, l)
	session := database.GetConnection()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)

	err = database.AddBatchIfNecessary(ctx, "202106301150", fileCreateTime)
	assert.Nil(t, err)

	tx, err := database.BeginTransaction(ctx)
	assert.Nil(t, err)
	assert.NotNil(t, tx)

	defer tx.Rollback()

	fileId, err := database.AddFile(ctx, tx, "202106301150", "TEST_FC05", "FC05", fileCreateTime)
	assert.Nil(t, err)
	assert.Less(t, uint(0), fileId)
	var (
		id        int
		createdAt time.Time
	)

	record := FC05Record{
		ApplicationNumber: "2020A045800",
		LoanID:            int64(6414515),
		CoverNumber:       testutil.GetNullInt64(6208222),
		CoverType:         testutil.GetNullString("310"),
		CoverLabel:        testutil.GetNullString("DECES"),
		OptionalCoverCode: testutil.GetNullString("O"),
		InsuredAmount:     testutil.GetNullInt64(150000),
		Submitted:         testutil.GetNullString("O"),
		CurrencyCode:      testutil.GetNullString("EUR"),
	}

	err = addFC05Record(ctx, tx, fileId, &record, fileCreateTime)
	if err != nil {
		assert.Fail(t, "cannot add FC05 record", err)
		return
	}

	err = tx.Commit()
	assert.Nil(t, err)

	var (
		ApplicationNumber string
		LoanID            int64
		CoverNumber       sql.NullInt64
		CoverType         sql.NullString
		CoverLabel        sql.NullString
		OptionalCoverCode sql.NullString
		InsuredAmount     sql.NullInt64
		DoubleEffectCode  sql.NullString
		WaitingPeriodDays sql.NullString
		Submitted         sql.NullString
		CurrencyCode      sql.NullString
	)
	row := session.QueryRowContext(ctx, "SELECT ID, APPLICATION_NUMBER, LOAN_ID, COVER_NUMBER, COVER_TYPE, COVER_LABEL, "+
		"OPTIONAL_COVER_CODE, INSURED_AMOUNT, DOUBLE_EFFECT_COVER, WAITING_PERIOD_DAYS, SUBMITTED, CURRENCY_CODE, "+
		"CREATED_AT FROM FC05_RECORDS WHERE FILE_ID = $1", fileId)
	err = row.Scan(&id, &ApplicationNumber, &LoanID, &CoverNumber, &CoverType, &CoverLabel, &OptionalCoverCode,
		&InsuredAmount, &DoubleEffectCode, &WaitingPeriodDays, &Submitted, &CurrencyCode, &createdAt)
	if err != nil {
		assert.Fail(t, "cannot read FC05 record", err)
		return
	}

	assert.Less(t, 0, id)

	assert.Equal(t, "2020A045800", ApplicationNumber)
	assert.Equal(t, int64(6414515), LoanID)
	assert.True(t, CoverNumber.Valid)
	assert.Equal(t, int64(6208222), CoverNumber.Int64)
	assert.True(t, CoverType.Valid)
	assert.Equal(t, "310", CoverType.String)
	assert.True(t, CoverLabel.Valid)
	assert.Equal(t, "DECES", CoverLabel.String)
	assert.True(t, OptionalCoverCode.Valid)
	assert.Equal(t, "O", OptionalCoverCode.String)
	assert.True(t, InsuredAmount.Valid)
	assert.Equal(t, int64(150000), InsuredAmount.Int64)
	assert.False(t, DoubleEffectCode.Valid)
	assert.False(t, WaitingPeriodDays.Valid)
	assert.True(t, Submitted.Valid)
	assert.Equal(t, "O", Submitted.String)
	assert.True(t, CurrencyCode.Valid)
	assert.Equal(t, "EUR", CurrencyCode.String)
	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
}
