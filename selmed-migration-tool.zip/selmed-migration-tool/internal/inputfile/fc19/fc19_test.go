package fc19

import (
	"context"
	"database/sql"
	"fmt"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/testutil"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/stretchr/testify/assert"
	"log"
	"os"
	"testing"
	"time"
)

var (
	cb *db.ConnectionBuilder
	l  *logger.Logger
)

func TestMain(m *testing.M) {
	l = logger.Create("db_access_test")

	ctx := context.Background()
	pg, net, host, port := testutil.Init()
	defer func() {
		if err := net.Remove(ctx); err != nil {
			log.Fatalf("failed to remove network: %s", err)
		}
	}()

	defer pg.Terminate(ctx)

	cb = db.NewConnectionBuilder("pgx", host, port, "migrationdb").
		Username("migowner").
		Password("Password1")

	os.Exit(m.Run())
}

func TestParseFC1900(t *testing.T) {
	line, err := parseFC19Content("2020A045800;CRE;2020-10-12-13.49.02.155039;N; ; ;\n")
	if err != nil {
		fmt.Printf("cannot parse F01 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "2020A045800", line.ApplicationNumber)
	assert.True(t, line.ApplicationStatus.Valid)
	assert.Equal(t, "CRE", line.ApplicationStatus.String)
	tt, err := time.Parse(util.MacaoDateTimeLayout, "2020-10-12-13.49.02.155039")
	assert.Nil(t, err)
	assert.True(t, line.StatusCreationDate.Valid)
	assert.Equal(t, tt, line.StatusCreationDate.Time)
	assert.True(t, line.RemoteTransmission.Valid)
	assert.Equal(t, "N", line.RemoteTransmission.String)
	assert.False(t, line.RecipientCodeType.Valid)
	assert.False(t, line.ProtestorCodeType.Valid)
	assert.False(t, line.DecisionTypeCode.Valid)
}

func TestParseFC1901(t *testing.T) {
	line, err := parseFC19Content("2020A051077;SBP;2020-11-06-16.04.30.249385;N; ; ;AJ05")
	if err != nil {
		fmt.Printf("cannot parse F01 content: %v", err)
		t.Fail()
		return
	}

	assert.Equal(t, "2020A051077", line.ApplicationNumber)
	assert.True(t, line.ApplicationStatus.Valid)
	assert.Equal(t, "SBP", line.ApplicationStatus.String)
	tt, err := time.Parse(util.MacaoDateTimeLayout, "2020-11-06-16.04.30.249385")
	assert.Nil(t, err)
	assert.True(t, line.StatusCreationDate.Valid)
	assert.Equal(t, tt, line.StatusCreationDate.Time)
	assert.True(t, line.RemoteTransmission.Valid)
	assert.Equal(t, "N", line.RemoteTransmission.String)
	assert.False(t, line.RecipientCodeType.Valid)
	assert.False(t, line.ProtestorCodeType.Valid)
	assert.True(t, line.DecisionTypeCode.Valid)
	assert.Equal(t, "AJ05", line.DecisionTypeCode.String)
}

func TestAddFC19(t *testing.T) {
	ctx := context.Background()
	dbClient, err := cb.Build()
	if err != nil {
		fmt.Printf("cannot create DB Client: %v", err)
		t.Fail()
	}

	database := dao.CreateClient(dbClient, l)
	session := database.GetConnection()

	// utc life
	loc, _ := time.LoadLocation("UTC")

	fileCreateTime := time.Now().In(loc)

	err = database.AddBatchIfNecessary(ctx, "202106301150", fileCreateTime)
	assert.Nil(t, err)

	tx, err := database.BeginTransaction(ctx)
	assert.Nil(t, err)
	assert.NotNil(t, tx)

	defer tx.Rollback()

	fileId, err := database.AddFile(ctx, tx, "202106301150", "TEST_FC19", "FC19", fileCreateTime)
	assert.Nil(t, err)
	assert.Less(t, uint(0), fileId)
	var (
		id        int
		createdAt time.Time
	)

	record := FC19Record{
		ApplicationNumber:  "2020A051077",
		ApplicationStatus:  testutil.GetNullString("SBP"),
		StatusCreationDate: testutil.GetNullTimestamp("2020-11-06-16.04.30.249385"),
		RemoteTransmission: testutil.GetNullString("N"),
		DecisionTypeCode:   testutil.GetNullString("AJ05"),
	}

	err = addFC19Record(ctx, tx, fileId, &record, fileCreateTime)
	if err != nil {
		assert.Fail(t, "cannot add FC19 record", err)
		return
	}

	err = tx.Commit()
	assert.Nil(t, err)

	var (
		ApplicationNumber  string
		ApplicationStatus  sql.NullString
		StatusCreationDate sql.NullTime
		RemoteTransmission sql.NullString
		RecipientCodeType  sql.NullString
		ProtestorCodeType  sql.NullString
		DecisionTypeCode   sql.NullString
	)
	row := session.QueryRowContext(ctx, "SELECT ID, APPLICATION_NUMBER, APPLICATION_STATUS, STATUS_CREATION_DATE, "+
		"REMOTE_TRANSMISSION, RECIPIENT_CODE_TYPE, PROTESTOR_CODE_TYPE, DECISION_TYPE_CODE, CREATED_AT "+
		"FROM FC19_RECORDS WHERE FILE_ID = $1", fileId)
	err = row.Scan(&id, &ApplicationNumber, &ApplicationStatus, &StatusCreationDate, &RemoteTransmission, &RecipientCodeType, &ProtestorCodeType, &DecisionTypeCode, &createdAt)
	if err != nil {
		assert.Fail(t, "cannot read FC19 record", err)
		return
	}

	assert.Less(t, 0, id)

	assert.Equal(t, "2020A051077", ApplicationNumber)
	assert.True(t, ApplicationStatus.Valid)
	assert.Equal(t, "SBP", ApplicationStatus.String)
	tt, err := time.Parse(util.MacaoDateTimeLayout, "2020-11-06-16.04.30.249385")
	assert.Nil(t, err)
	assert.True(t, StatusCreationDate.Valid)
	assert.Equal(t, tt, StatusCreationDate.Time)
	assert.True(t, RemoteTransmission.Valid)
	assert.Equal(t, "N", RemoteTransmission.String)
	assert.False(t, RecipientCodeType.Valid)
	assert.False(t, ProtestorCodeType.Valid)
	assert.True(t, DecisionTypeCode.Valid)
	assert.Equal(t, "AJ05", DecisionTypeCode.String)
	assert.True(t, fileCreateTime.Round(time.Millisecond).Equal(createdAt.Round(time.Millisecond)))
}
