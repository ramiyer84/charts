package logger

import (
	"github.axa.com/axa-partners-clp/mrt-shared/fs_util"
	"github.com/spf13/viper"
	"log"
	"os"
	"path/filepath"
	"time"
)

const logNameLayout = "-20060102150405.log"

type Logger struct {
	Name             string
	logger           *log.Logger
	logDebugMessages bool
	f                *os.File
}

func Create(name string) *Logger {
	l := &Logger{
		Name: name,
	}

	l.init()

	return l
}

func (c *Logger) init() {
	c.logger = log.New(os.Stdout, c.Name+": ", log.LstdFlags)
	var (
		logDirPath string
		err        error
	)

	c.logDebugMessages = viper.GetBool("debug")
	logDirPath = viper.GetString("location.logs")
	if logDirPath != "" {
		err = fs_util.CreateOrCheckDirectory("logs", logDirPath, true)
		if err != nil {
			c.logger.Printf("logs directory '%s' is not available: %v", logDirPath, err)
		} else {
			t := time.Now()
			logFilePath := filepath.Join(logDirPath, t.Format(c.Name+logNameLayout))
			f, err := os.Create(logFilePath)
			if err != nil {
				c.logger.Printf("cannot create log file '%s': %v", logFilePath, err)
			} else {
				c.logger = log.New(f, c.Name+": ", log.LstdFlags)
			}
		}
	}
}

func (c Logger) Close() {
	if c.f != nil {
		c.f.Close()
	}
}

func (c Logger) Printf(format string, args ...interface{}) {
	c.logger.Printf(format, args...)
}

func (c Logger) Print(message string) {
	c.logger.Println(message)
}

func (c Logger) Debugf(format string, args ...interface{}) {
	if c.logDebugMessages {
		c.logger.Printf(format, args...)
	}
}

func (c Logger) Debug(message string) {
	if c.logDebugMessages {
		c.logger.Println(message)
	}
}
