package main

import (
	"context"
	"database/sql"
	"encoding/base64"
	"github.axa.com/axa-partners-clp/mrt-shared/db"
	"github.axa.com/axa-partners-clp/mrt-shared/encryption"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/dao"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile/fc01"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile/fc02"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile/fc05"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile/fc06"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile/fc10"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile/fc12"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile/fc13"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile/fc19"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile/fc21"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile/fc23"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile/fc24"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile/fc26"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile/fc27"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/inputfile/fc28"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/logger"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.com/fsnotify/fsnotify"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/spf13/viper"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

const (
	applicationName = "github.axa.com/axa-partners-clp/selmed-migration-tool.git"
	Driver          = "pgx"
	logNameLayout   = "selmed-migration-20060102150405.log"
)

var (
	l                    *logger.Logger
	database             *dao.DB
	secretKey            []byte
	Debug                bool
	importDateRangeStart *time.Time
	importDateRangeEnd   *time.Time
	shouldimportInRange  bool
	fakeCommentsCount    = 3
	fakeCommentIndex     = 0
	inputDirPath         string
	processedDirPath     string
	errorDirPath         string
	wg                   sync.WaitGroup
)

func main() {
	var (
		secretKeySource string
		err             error
		r               inputfile.Range
	)

	viper.AllowEmptyEnv(true)
	viper.SetDefault("debug", false)
	viper.SetDefault("anonymize", false)
	viper.SetDefault("database.port", 5432)
	viper.SetDefault("database.ssl.enabled", false)
	viper.SetDefault("location.input", "input")
	viper.SetDefault("location.processed", "processed")
	viper.SetDefault("location.error", "error")

	viper.SetConfigName("selmed-migration") // name of config file (without extension)
	viper.AddConfigPath("/etc/dms02")       // call multiple times to add many search paths
	viper.AddConfigPath("$HOME/.dms02")     // call multiple times to add many search paths
	viper.AddConfigPath(".")

	if err := viper.ReadInConfig(); err != nil {
		if _, ok := err.(viper.ConfigFileNotFoundError); ok {
			log.Println("application config not found, using defaults")
		} else {
			log.Fatalf("cannot read application config: %v", err)
		}
	}

	viper.WatchConfig()
	viper.OnConfigChange(func(e fsnotify.Event) {
		log.Println("config file changed:", e.Name)
	})

	_ = viper.BindEnv("debug", "DEBUG")
	_ = viper.BindEnv("anonymize", "ANONYMIZE")
	_ = viper.BindEnv("encryption.key", "DMS_SECRET_KEY")
	_ = viper.BindEnv("database.password", "DMS_MIGRATION_DB_PASSWORD")

	l = logger.Create(applicationName)
	l.Printf("selmed-migration-tool, version: %s", inputfile.Version)
	Debug = viper.GetBool("debug")
	inputDirPath = viper.GetString("location.input")
	processedDirPath = viper.GetString("location.processed")
	errorDirPath = viper.GetString("location.error")
	secretKeySource = viper.GetString("encryption.key")

	dateString := viper.GetString("import.range.start")
	if dateString != "" {
		importDateRangeStart, err = util.OptionalDate(dateString)
		if err != nil {
			l.Printf("cannot read import range start date: %v", err)
			os.Exit(1)
		}
	}

	dateString = viper.GetString("import.range.end")
	if dateString != "" {
		importDateRangeEnd, err = util.OptionalDate(dateString)
		if err != nil {
			l.Printf("cannot read import range start date: %v", err)
			os.Exit(1)
		}
		*importDateRangeEnd = importDateRangeEnd.AddDate(0, 0, 1)
		*importDateRangeEnd = importDateRangeEnd.Add(-1000000000)
	}

	if importDateRangeStart != nil && importDateRangeEnd != nil {
		shouldimportInRange = true
	}

	err = createOrCheckDirectory("input", inputDirPath, false)
	if err != nil {
		l.Printf("input directory is not available: %v", err)
	}

	err = createOrCheckDirectory("processed", processedDirPath, true)
	if err != nil {
		l.Printf("processed directory is not available: %v", err)
	}

	err = createOrCheckDirectory("error", errorDirPath, true)
	if err != nil {
		l.Printf("error directory is not available: %v", err)
	}

	dbClient, err := db.NewConnectionBuilder(Driver, viper.GetString("database.host"), viper.GetInt("database.port"), viper.GetString("database.name")).
		Username(viper.GetString("database.username")).
		Password(viper.GetString("database.password")).
		UseSSL(viper.GetBool("database.ssl.enabled")).
		CACertificatePath(viper.GetString("database.ssl.ca")).
		PrivateKeyPath(viper.GetString("database.ssl.key")).
		CertificatePath(viper.GetString("database.ssl.cert")).
		Debug(Debug).
		Build()

	if err != nil {
		panic("cannot build database client")
	}

	database = dao.CreateClient(dbClient, l)
	secretKey, err = base64.StdEncoding.DecodeString(secretKeySource)
	if err != nil {
		log.Fatalf("cannot read AES key: %v", err)
	}

	// Read content of the input directory
	files, err := os.ReadDir(inputDirPath)
	if err != nil {
		l.Printf("cannot read content of the input directory '%s': %v", inputDirPath, err)
		os.Exit(1)
	}

	ctx := context.Background()

	var batchId string

	l.Printf("starting the Selmed files migration run")
	l.Printf("dropping extra indexes")
	err = database.DropIndexes(ctx)
	if err != nil {
		l.Printf("cannot drop extra indexes: %v", err)
		os.Exit(1)
	}

	count := 0
	for _, file := range files {
		count++
		failed := false
		if !file.IsDir() && strings.HasSuffix(file.Name(), ".txt") {
			l.Printf("Processing '%s'", file.Name())

			filePath := filepath.Join(inputDirPath, file.Name())

			length := len(file.Name())
			fileType := strings.TrimPrefix(file.Name(), "SLMD_MACAO")[:length-25]
			fileName := strings.TrimSuffix(file.Name(), ".txt")
			batchId = file.Name()[length-14 : length-4]
			addedAt := time.Now().UTC()

			b, err := database.CheckIfThereAreIncompleteBatches(ctx, batchId)
			if err != nil {
				if e, ok := err.(*dao.OldBatchError); ok {
					l.Printf("%v", e)
					inputfile.MoveToError(filePath, fileName, l)
					continue
				} else {
					failed = true
					l.Printf("cannot check if there are incomplete batches: %v", err)
					break
				}
			}

			if len(b) > 0 {
				for _, batch := range b {
					err = database.CancelIncompleteBatch(ctx, batch)
					if err != nil {
						failed = true
						l.Printf("cannot cancel incomplete batches: %v", err)
						break
					}
				}
			}

			err = database.AddBatchIfNecessary(ctx, batchId, addedAt)
			if err != nil {
				failed = true
				l.Printf("cannot create batch '%s': %v", batchId, err)
				break
			}

			tx, err := database.BeginTransaction(ctx)
			if err != nil {
				failed = true
				l.Printf("cannot begin DB transaction: %v", err)
				break
			}
			defer tx.Rollback()

			if failed {
				inputfile.ProcessResponse(true, tx, filePath, file.Name(), l)
				continue
			}

			isLoaded, err := database.CheckIfFileLoaded(ctx, tx, batchId, fileType)
			if err != nil {
				l.Printf("cannot validate if the %s file has been already loaded for batch '%s': %v", fileType, batchId, err)
				os.Exit(1)
			}

			if isLoaded {
				l.Printf("file %s has been already processed for batch '%s' moving source file to processed directory", fileType, batchId)
				inputfile.MoveToProcessed(filePath, file.Name(), l)
				continue
			}

			if shouldimportInRange && fileType != "FC01" {
				isLoaded, err := database.CheckIfFileLoaded(ctx, tx, batchId, "FC01")
				if err != nil {
					l.Printf("cannot validate if the FC01 file has been loaded for batch '%s': %v", batchId, err)
					os.Exit(1)
				}

				if !isLoaded {
					l.Printf("file '%s' cannot be processed as FC01 is not imported yet", fileName)
					continue
				}

				r.Validate(ctx, database, tx, batchId)
			}

			selmedFile := CreateFile(database, tx, l, fileType, batchId, filePath, fileName, file.Name(), string(secretKey), &r, &wg)
			if selmedFile != nil {
				go (*selmedFile).AsyncProcessFile(ctx)
			}
		}
	}

	wg.Wait()
	l.Printf("completed the Selmed files migration run")
	l.Printf("check if all files are created and update batch status if necessary")
	if batchId != "" {
		err = database.CompleteBatchIfPossible(ctx, batchId)
		if err != nil {
			l.Printf("cannot complete batch: %v", err)
		}
	}
}

func createOrCheckDirectory(directoryType string, directory string, shouldCreate bool) error {
	f, err := os.Stat(directory)
	if err != nil {
		if os.IsNotExist(err) {
			if shouldCreate {
				err = os.MkdirAll(directory, 0755)
				if err != nil {
					log.Printf("cannot create %s '%s' directory: %v", directoryType, directory, err)
					return err
				}
			} else {
				log.Printf("%s directory '%s' does not exist", directoryType, directory)
				return err
			}
		} else {
			log.Printf("cannot get details of the %s directory '%s': %v", directoryType, directory, err)
			return err
		}
	} else {
		if !f.IsDir() {
			log.Printf("specified %s path '%s' is not a derictory", directoryType, directory)
			return err
		}
	}

	return nil
}

func CreateFile(db *dao.DB, tx *sql.Tx, logger *logger.Logger, filetype string, batchId string, filepath string, filename string, originalFileName string, secretKey string, r *inputfile.Range, wg *sync.WaitGroup) *inputfile.FC {
	var ss inputfile.FC

	sf := inputfile.SourceFile{
		BatchID:          batchId,
		Filepath:         filepath,
		Filename:         filename,
		OriginalFileName: originalFileName,
		Encryption:       encryption.New(secretKey, nil),
		Db:               db,
		Tx:               tx,
		Logger:           logger,
		Range:            r,
		Wg:               wg,
	}

	switch filetype {
	case "FC01":
		ss = fc01.File{&sf}
		return &ss
	case "FC02":
		ss = fc02.File{&sf}
		return &ss
	case "FC05":
		ss = fc05.File{&sf}
		return &ss
	case "FC06":
		ss = fc06.File{&sf}
		return &ss
	case "FC10":
		ss = fc10.File{&sf}
		return &ss
	case "KJDTPJV":
		ss = fc12.File{&sf}
		return &ss
	case "KJDTAGB":
		ss = fc13.File{&sf}
		return &ss
	case "FC19":
		ss = fc19.File{&sf}
		return &ss
	case "FC21":
		ss = fc21.File{&sf}
		return &ss
	case "KJDTCOE":
		ss = fc23.File{&sf}
		return &ss
	case "KJDTLEE":
		ss = fc24.File{&sf}
		return &ss
	case "KJDTLVC":
		ss = fc26.File{&sf}
		return &ss
	case "KJDTCLP":
		ss = fc27.File{&sf}
		return &ss
	case "KJDTPJE":
		ss = fc28.File{&sf}
		return &ss
	default:
		return nil
	}
}
