package testutil

import (
	"context"
	"database/sql"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"github.axa.com/axa-partners-clp/selmed-migration-tool/internal/util"
	"github.com/docker/docker/api/types/image"
	"github.com/docker/docker/api/types/registry"
	"github.com/docker/docker/client"
	"github.com/testcontainers/testcontainers-go"
	"github.com/testcontainers/testcontainers-go/network"
	"github.com/testcontainers/testcontainers-go/wait"
	"io"
	"log"
	"math/rand"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"
)

type StageArtifacts struct {
	Stage     string    `json:"stage"`
	Artifacts []Version `json:"artifacts"`
}

type Version struct {
	*Artifact
	Version string `json:"version"`
}

type Artifact struct {
	ArtifactName        string  `json:"artifact_name"`
	ArtifactDescription *string `json:"artifact_description,omitempty"`
	Type                string  `json:"type"`
	GroupId             *string `json:"group_id,omitempty"`
	ArtifactId          *string `json:"artifact_id,omitempty"`
}

var (
	httpClient *http.Client
)

func Init() (testcontainers.Container, *testcontainers.DockerNetwork, string, int) {
	readToken := os.Getenv("ARTIFACTZ_TOKEN")
	if readToken == "" {
		log.Fatalln("artifactz.io API token is not specified. Please define ARTIFACTZ_TOKEN environment variable")
	}

	proxyUrl := os.Getenv("HTTP_PROXY")

	dockerRegistryUsername := os.Getenv("DOCKER_REGISTRY_USERNAME")
	dockerRegistryPassword := os.Getenv("DOCKER_REGISTRY_PASSWORD")

	if dockerRegistryUsername == "" || dockerRegistryPassword == "" {
		log.Fatalln("docker registry credentials are not specified. Please define DOCKER_REGISTRY_USERNAME and DOCKER_REGISTRY_PASSWORD environment variables")
	}

	tr := &http.Transport{
		MaxIdleConns:       10,
		IdleConnTimeout:    30 * time.Second,
		DisableCompression: true,
	}

	httpClient = &http.Client{Transport: tr}

	versions, err := getImageVersions(proxyUrl, readToken)
	if err != nil {
		log.Fatal(err)
	}
	databaseImage := "clpregistrystaging.al.intraxa/dms-migration-db:" + versions["dms-migration-db"]
	log.Printf("loading DB image %s", databaseImage)

	ctx := context.Background()

	postgresContainerName := "db-" + randomString()

	net, err := network.New(ctx,
		network.WithCheckDuplicate(),
		network.WithAttachable(),
		// Makes the network internal only, meaning the host machine cannot access it.
		// Remove or use `network.WithDriver("bridge")` to change the network's mode.
		network.WithDriver("bridge"),
	)
	if err != nil {
		log.Fatalf("failed to create network: %s", err)
	}

	authConfig := registry.AuthConfig{
		Username: dockerRegistryUsername,
		Password: dockerRegistryPassword,
	}
	encodedJSON, err := json.Marshal(authConfig)
	if err != nil {
		panic(err)
	}
	credentials := base64.URLEncoding.EncodeToString(encodedJSON)

	dockerClient, err := client.NewClientWithOpts(client.FromEnv)
	if err != nil {
		log.Fatalf("cannot create docker client: %v", err)
	}

	dockerClient.NegotiateAPIVersion(ctx)
	pullDockerImage(ctx, dockerClient, databaseImage, credentials)

	env := make(map[string]string)
	env["POSTGRES_PASSWORD"] = "Password1"
	dbContainerRequest := testcontainers.ContainerRequest{
		Image:           databaseImage,
		Name:            postgresContainerName,
		ExposedPorts:    []string{"5432/tcp"},
		Env:             env,
		WaitingFor:      wait.ForListeningPort("5432/tcp"),
		Networks:        []string{net.Name},
		AlwaysPullImage: false,
	}

	gcr := testcontainers.GenericContainerRequest{
		ContainerRequest: dbContainerRequest,
		Started:          true,
	}

	postgres, err := testcontainers.GenericContainer(ctx, gcr)
	if err != nil {
		log.Fatalln(err)
	}

	host, err := postgres.Host(ctx)
	if err != nil {
		log.Fatalln("Cannot get PostgreSQL container hostname")
	}

	port, err := postgres.MappedPort(ctx, "5432")
	if err != nil {
		log.Fatalln("Cannot get mapped port for PostgreSQL container")
	}

	pgPort := strings.SplitN(string(port), "/", -1)

	portInt, err := strconv.Atoi(pgPort[0])
	if err != nil {
		log.Fatalln("cannot convert port number to int")
	}

	return postgres, net, host, portInt
}

func getImageVersions(proxyUrl, readToken string) (map[string]string, error) {
	tr := &http.Transport{
		MaxIdleConns:       10,
		IdleConnTimeout:    30 * time.Second,
		DisableCompression: true,
	}

	if proxyUrl != "" {
		proxy, err := url.Parse(proxyUrl)
		if err != nil {
			return nil, err
		}
		tr.Proxy = http.ProxyURL(proxy)
	}

	proxiedHttpClient := &http.Client{Transport: tr}

	request, err := http.NewRequest("GET", "https://artifactor.artifactz.io/stages/Development/list?artifact=dms-migration-db", nil)
	if err != nil {
		log.Fatalf("failed to build new request to https://artifactor.artifactz.io: %v", err)
	}

	request.Header.Add("Authorization", "Bearer "+readToken)
	request.Header.Add("Accept", "application/json")
	request.Header.Add("X-ClientId", "Integration Test")

	resp, err := proxiedHttpClient.Do(request)
	if err != nil {
		return nil, errors.New(fmt.Sprintf("Error running request: %v", err))
	}

	var (
		body      []byte
		artifacts StageArtifacts
		result    map[string]string
	)

	body, err = io.ReadAll(resp.Body)
	if err != nil {
		return nil, errors.New(fmt.Sprintf("cannot read response body: %v", err))
	}

	err = json.Unmarshal(body, &artifacts)
	if err != nil {
		return nil, errors.New(fmt.Sprintf("cannot handle response: %v", err))
	}

	result = make(map[string]string)
	for _, version := range artifacts.Artifacts {
		result[version.ArtifactName] = version.Version
	}

	return result, nil
}

func pullDockerImage(ctx context.Context, dockerClient *client.Client, imageName, credentials string) {
	log.Printf("pulling image %s", imageName)
	options := image.PullOptions{}
	if credentials != "" {
		options.RegistryAuth = credentials
	}

	// Pull the Docker image
	reader, err := dockerClient.ImagePull(ctx, imageName, options)
	if err != nil {
		log.Fatalf("cannot pull docker image '%s' from container registry: %v", imageName, err)
	}

	defer reader.Close()
	_, _ = io.Copy(os.Stdout, reader)
}

func randomString() string {
	rand.Seed(time.Now().UnixNano())
	chars := []rune("ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
		"abcdefghijklmnopqrstuvwxyz" +
		"0123456789")
	length := 8
	var b strings.Builder
	for i := 0; i < length; i++ {
		b.WriteRune(chars[rand.Intn(len(chars))])
	}
	return b.String()
}

func GetNullString(value string) sql.NullString {
	return sql.NullString{
		Valid:  true,
		String: value,
	}
}

func GetNullInt64(value int) sql.NullInt64 {
	return sql.NullInt64{
		Valid: true,
		Int64: int64(value),
	}
}

func GetNullFloat64(value float64) sql.NullFloat64 {
	return sql.NullFloat64{
		Valid:   true,
		Float64: value,
	}
}

func GetNullDate(value string) sql.NullTime {
	tt, _ := time.Parse(util.AltDateLayout, value)
	return sql.NullTime{
		Valid: true,
		Time:  tt,
	}
}

func GetNullTimestamp(value string) sql.NullTime {
	tt, _ := time.Parse(util.MacaoDateTimeLayout, value)
	return sql.NullTime{
		Valid: true,
		Time:  tt,
	}
}
